
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import {
  BarChart3,
  ShoppingCart,
  Users,
  Coffee,
  ChefHat,
  CreditCard,
  DollarSign,
  UserCheck,
  Settings,
  Package,
  FileText,
  Activity,
  Printer
} from 'lucide-react';
import { MainNav } from '@/components/main-nav';
import { SiteHeader } from '@/components/site-header';
import OrderSystem from '@/components/OrderSystem';
import TableManagement from '@/components/TableManagement';
import MenuManagement from '@/components/MenuManagement';
import KitchenSystem from '@/components/KitchenSystem';
import PaymentSystemWrapper from '@/components/PaymentSystemWrapper';
import CashDrawerSystem from '@/components/CashDrawerSystem';
import StaffManagementTabs from '@/components/StaffManagementTabs';
import UserAccountsList from '@/components/UserAccountsList';
import UserAccountManagement from '@/components/UserAccountManagement';
import StockManagement from '@/components/StockManagement';
import SalesReport from '@/components/SalesReport';
import ActivityLog from '@/components/ActivityLog';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useIsMobile } from '@/hooks/use-mobile';
import MobileServiceInterface from '@/components/MobileServiceInterface';
import MobileKitchenInterface from '@/components/MobileKitchenInterface';
import PrinterSystemPage from '@/components/PrinterSystemPage';

interface NavItem {
  id: string;
  label: string;
  icon: any;
}

const Dashboard = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const { user } = useAuth();
  const navigate = useNavigate();
  const isMobile = useIsMobile();

  console.log('Dashboard render - user:', user);

  const { data: profile, isLoading: profileLoading } = useQuery({
    queryKey: ['profile'],
    queryFn: async () => {
      if (!user?.id) return null;

      console.log('Fetching profile for user:', user.id);

      // Use user_accounts table instead of profiles
      const { data, error } = await supabase
        .from('user_accounts')
        .select('*')
        .eq('id', user.id)
        .single();

      if (error) {
        console.error('Error fetching user account:', error);
        return null;
      }

      console.log('Profile data fetched:', data);
      return data;
    },
    enabled: !!user?.id,
  });

  useEffect(() => {
    console.log('Dashboard useEffect - user:', user);
    if (!user) {
      console.log('No user found, redirecting to login');
      navigate('/login');
    }
  }, [user, navigate]);

  // If user is not logged in, don't render anything (will redirect)
  if (!user) {
    console.log('No user, rendering null');
    return null;
  }

  const adminTabs = [
    { id: 'overview', label: 'ภาพรวม', icon: BarChart3 },
    { id: 'orders', label: 'จัดการออเดอร์', icon: ShoppingCart },
    { id: 'tables', label: 'จัดการโต๊ะ', icon: Users },
    { id: 'menu', label: 'จัดการเมนู', icon: Coffee },
    { id: 'kitchen', label: 'ระบบครัว', icon: ChefHat },
    { id: 'payment', label: 'ระบบชำระเงิน', icon: CreditCard },
    { id: 'printer', label: 'ระบบปริ้นเตอร์', icon: Printer },
    { id: 'cash-drawer', label: 'ลิ้นชักเงินสด', icon: DollarSign },
    { id: 'staff-data', label: 'จัดการพนักงาน', icon: UserCheck },
    { id: 'user-accounts', label: 'รายการบัญชีผู้ใช้', icon: UserCheck },
    { id: 'accounts', label: 'ตั้งค่าบัญชี', icon: Settings },
    { id: 'inventory', label: 'คลังสินค้า', icon: Package },
    { id: 'reports', label: 'รายงานการขาย', icon: FileText },
    { id: 'activity', label: 'บันทึกกิจกรรม', icon: Activity }
  ];

  const managerTabs = [
    { id: 'overview', label: 'ภาพรวม', icon: BarChart3 },
    { id: 'orders', label: 'จัดการออเดอร์', icon: ShoppingCart },
    { id: 'tables', label: 'จัดการโต๊ะ', icon: Users },
    { id: 'kitchen', label: 'ระบบครัว', icon: ChefHat },
    { id: 'payment', label: 'ระบบชำระเงิน', icon: CreditCard },
    { id: 'printer', label: 'ระบบปริ้นเตอร์', icon: Printer },
    { id: 'cash-drawer', label: 'ลิ้นชักเงินสด', icon: DollarSign },
    { id: 'inventory', label: 'คลังสินค้า', icon: Package },
    { id: 'reports', label: 'รายงานการขาย', icon: FileText }
  ];

  const kitchenTabs = [
    { id: 'kitchen', label: 'ระบบครัว', icon: ChefHat },
    { id: 'inventory', label: 'คลังสินค้า', icon: Package },
    { id: 'accounts', label: 'ตั้งค่าบัญชี', icon: Settings }
  ];

  const serviceTabs = [
    { id: 'orders', label: 'จัดการออเดอร์', icon: ShoppingCart },
    { id: 'tables', label: 'จัดการโต๊ะ', icon: Users },
    { id: 'payment', label: 'ระบบชำระเงิน', icon: CreditCard },
    { id: 'accounts', label: 'ตั้งค่าบัญชี', icon: Settings }
  ];

  let navItems: NavItem[] = [];

  if (user?.role === 'admin') {
    navItems = adminTabs;
  } else if (user?.role === 'manager') {
    navItems = managerTabs;
  } else if (user?.role === 'kitchen_staff') {
    navItems = kitchenTabs;
  } else if (user?.role === 'service_staff') {
    navItems = serviceTabs;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
        return <SalesReport />;
      case 'orders':
        return <OrderSystem />;
      case 'tables':
        return <TableManagement />;
      case 'menu':
        return <MenuManagement />;
      case 'kitchen':
        if (user?.role === 'kitchen_staff') {
          return <MobileKitchenInterface />;
        }
        return <KitchenSystem />;
      case 'payment':
        return <PaymentSystemWrapper />;
      case 'printer':
        return <PrinterSystemPage />;
      case 'cash-drawer':
        return <CashDrawerSystem />;
      case 'staff-data':
        return <StaffManagementTabs />;
      case 'user-accounts':
        return <UserAccountsList />;
      case 'accounts':
        return <UserAccountManagement />;
      case 'inventory':
        return <StockManagement />;
      case 'reports':
        return <SalesReport />;
      case 'activity':
        return <ActivityLog />;
      default:
        return <SalesReport />;
    }
  };

  // Mobile interface for service staff
  if (user?.role === 'service_staff' && isMobile) {
    return <MobileServiceInterface />;
  }

  // Mobile interface for kitchen staff
  if (user?.role === 'kitchen_staff' && isMobile) {
    return <MobileKitchenInterface />;
  }

  console.log('Rendering Dashboard with user:', user.username, 'role:', user.role);

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader
        profile={profile}
        profileLoading={profileLoading}
      />
      <div className="container mx-auto md:px-10">
        <div className="flex flex-1 space-x-4 py-4 md:py-8">
          <aside className="hidden w-80 flex-none md:block">
            <MainNav
              className="mt-6"
              items={navItems}
              activeTab={activeTab}
              setActiveTab={setActiveTab}
            />
          </aside>
          <main className="flex-1 rounded-md bg-muted p-8">
            {renderContent()}
          </main>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
