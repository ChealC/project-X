import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/components/ui/use-toast';

interface User {
  id: string;
  staff_id: string;
  username: string;
  role: 'admin' | 'manager' | 'kitchen_staff' | 'service_staff';
  staff_name: string;
  staff_position: string;
}

interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  hasPermission: (page: string, permissionType: 'view' | 'edit' | 'delete') => boolean;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Simple and consistent hash function
const hashPassword = (password: string): string => {
  return btoa(password);
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for stored user session
    const storedUser = localStorage.getItem('restaurant_user');
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (error) {
        localStorage.removeItem('restaurant_user');
      }
    }
    setIsLoading(false);
  }, []);

  const login = async (username: string, password: string): Promise<boolean> => {
    try {
      setIsLoading(true);
      
      console.log('=== LOGIN ATTEMPT ===');
      console.log('Username:', username);
      console.log('Password:', password);
      
      // Hash the password using the same method
      const passwordHash = hashPassword(password);
      console.log('Generated hash:', passwordHash);

      // Try to find the user account
      const { data: userAccounts, error: userError } = await supabase
        .from('user_accounts')
        .select(`
          id,
          username,
          password_hash,
          role,
          staff_id,
          is_active,
          staff (
            name,
            position
          )
        `)
        .eq('username', username)
        .eq('is_active', true);

      console.log('Database query result:', { userAccounts, userError });

      if (userError) {
        console.error('Database error:', userError);
        toast({
          title: "เกิดข้อผิดพลาดในการเชื่อมต่อ",
          description: "กรุณาลองอีกครั้ง",
          variant: "destructive"
        });
        return false;
      }

      if (!userAccounts || userAccounts.length === 0) {
        console.log('No user account found');
        toast({
          title: "เข้าสู่ระบบไม่สำเร็จ",
          description: "ไม่พบชื่อผู้ใช้นี้ในระบบ",
          variant: "destructive"
        });
        return false;
      }

      const userAccount = userAccounts[0];
      console.log('Found user account:', userAccount);
      console.log('Stored password hash:', userAccount.password_hash);
      
      // Simple password comparison
      if (userAccount.password_hash !== passwordHash) {
        console.log('Password hash mismatch');
        console.log('Expected:', passwordHash);
        console.log('Stored:', userAccount.password_hash);
        
        toast({
          title: "เข้าสู่ระบบไม่สำเร็จ",
          description: "รหัสผ่านไม่ถูกต้อง",
          variant: "destructive"
        });
        return false;
      }

      console.log('Password verified successfully');

      // Create user object
      const userObj: User = {
        id: userAccount.id,
        staff_id: userAccount.staff_id || '',
        username: userAccount.username,
        role: userAccount.role,
        staff_name: userAccount.staff?.name || 'ผู้ดูแลระบบ',
        staff_position: userAccount.staff?.position || 'ระบบ'
      };
      
      setUser(userObj);
      localStorage.setItem('restaurant_user', JSON.stringify(userObj));
      
      console.log('Login successful for user:', userObj);
      
      toast({
        title: "เข้าสู่ระบบสำเร็จ",
        description: `ยินดีต้อนรับ คุณ${userObj.staff_name}`
      });
      
      return true;
    } catch (error) {
      console.error('Login error:', error);
      toast({
        title: "เกิดข้อผิดพลาด",
        description: "ไม่สามารถเข้าสู่ระบบได้ กรุณาลองอีกครั้ง",
        variant: "destructive"
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('restaurant_user');
    toast({
      title: "ออกจากระบบสำเร็จ",
      description: "แล้วพบกันใหม่"
    });
  };

  const hasPermission = (page: string, permissionType: 'view' | 'edit' | 'delete'): boolean => {
    if (!user) return false;
    
    // Define permissions based on role - Updated permissions
    const permissions = {
      admin: {
        tables: { view: true, edit: true, delete: true },
        orders: { view: true, edit: true, delete: true },
        menu: { view: true, edit: true, delete: true },
        kitchen: { view: true, edit: true, delete: true },
        payment: { view: true, edit: true, delete: true },
        'cash-drawer': { view: true, edit: true, delete: true },
        stock: { view: true, edit: true, delete: true },
        staff: { view: true, edit: true, delete: true },
        reports: { view: true, edit: true, delete: true },
        activity: { view: true, edit: true, delete: true },
        security: { view: true, edit: true, delete: true },
        mobile: { view: true, edit: true, delete: true },
        checkin: { view: true, edit: true, delete: true }
      },
      manager: {
        tables: { view: true, edit: true, delete: true },
        orders: { view: true, edit: true, delete: true },
        menu: { view: true, edit: true, delete: false },
        kitchen: { view: true, edit: true, delete: false },
        payment: { view: true, edit: true, delete: false },
        'cash-drawer': { view: true, edit: true, delete: false },
        stock: { view: true, edit: true, delete: true },
        staff: { view: true, edit: true, delete: false },
        reports: { view: true, edit: false, delete: false },
        activity: { view: true, edit: false, delete: false },
        security: { view: true, edit: false, delete: false },
        mobile: { view: true, edit: true, delete: false },
        checkin: { view: true, edit: true, delete: false }
      },
      kitchen_staff: {
        // Kitchen staff permissions - Updated
        tables: { view: false, edit: false, delete: false }, // Cannot access tables
        orders: { view: true, edit: false, delete: false }, // Can only view orders
        menu: { view: true, edit: false, delete: false }, // Read-only menu access
        kitchen: { view: true, edit: true, delete: false }, // Kitchen operations only
        payment: { view: false, edit: false, delete: false }, // No payment access
        'cash-drawer': { view: false, edit: false, delete: false }, // No cash drawer access
        stock: { view: true, edit: false, delete: false }, // Can view stock
        staff: { view: false, edit: false, delete: false }, // No staff management
        reports: { view: false, edit: false, delete: false }, // No reports
        activity: { view: false, edit: false, delete: false }, // No activity logs
        security: { view: false, edit: false, delete: false }, // No security
        mobile: { view: true, edit: true, delete: false }, // Mobile kitchen interface
        checkin: { view: true, edit: true, delete: false } // Can check in/out
      },
      service_staff: {
        // Service staff permissions - Updated
        tables: { view: true, edit: true, delete: false }, // Can manage tables but not delete
        orders: { view: true, edit: true, delete: false }, // Can create and manage orders
        menu: { view: true, edit: false, delete: false }, // Read-only menu
        kitchen: { view: true, edit: false, delete: false }, // Read-only kitchen view
        payment: { view: true, edit: true, delete: false }, // Can process payments
        'cash-drawer': { view: false, edit: false, delete: false }, // No cash drawer access
        stock: { view: false, edit: false, delete: false }, // No stock access
        staff: { view: false, edit: false, delete: false }, // No staff management
        reports: { view: false, edit: false, delete: false }, // No reports
        activity: { view: false, edit: false, delete: false }, // No activity logs
        security: { view: false, edit: false, delete: false }, // No security
        mobile: { view: true, edit: true, delete: false }, // Mobile service interface
        checkin: { view: true, edit: true, delete: false } // Can check in/out
      }
    };

    const rolePermissions = permissions[user.role];
    const pagePermissions = rolePermissions?.[page as keyof typeof rolePermissions];
    
    return pagePermissions?.[permissionType] || false;
  };

  const value: AuthContextType = {
    user,
    login,
    logout,
    hasPermission,
    isLoading
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};
