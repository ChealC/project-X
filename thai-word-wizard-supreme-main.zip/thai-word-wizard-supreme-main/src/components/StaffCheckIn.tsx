
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Camera, Clock, CheckCircle, X, Upload } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';

const StaffCheckIn = () => {
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isCheckInDialogOpen, setIsCheckInDialogOpen] = useState(false);
  const [isCheckOutDialogOpen, setIsCheckOutDialogOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();

  const { data: todayShift } = useQuery({
    queryKey: ['today-shift', user?.staff_id],
    queryFn: async () => {
      const today = new Date().toISOString().split('T')[0];
      const { data, error } = await supabase
        .from('staff_shifts')
        .select('*')
        .eq('staff_id', user?.staff_id)
        .eq('shift_date', today)
        .single();
      
      if (error && error.code !== 'PGRST116') throw error;
      return data;
    },
    enabled: !!user?.staff_id
  });

  const { data: recentShifts } = useQuery({
    queryKey: ['recent-shifts', user?.staff_id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('staff_shifts')
        .select('*')
        .eq('staff_id', user?.staff_id)
        .order('shift_date', { ascending: false })
        .limit(7);
      
      if (error) throw error;
      return data;
    },
    enabled: !!user?.staff_id
  });

  const checkInMutation = useMutation({
    mutationFn: async ({ image }: { image: File }) => {
      // Upload image to storage
      const fileName = `checkin-${user?.staff_id}-${Date.now()}.jpg`;
      const { error: uploadError } = await supabase.storage
        .from('staff-photos')
        .upload(fileName, image);

      if (uploadError) throw uploadError;

      // Create shift record
      const today = new Date().toISOString().split('T')[0];
      const { error } = await supabase
        .from('staff_shifts')
        .insert({
          staff_id: user?.staff_id,
          shift_date: today,
          clock_in: new Date().toISOString(),
          notes: `เช็คอินด้วยรูปภาพ: ${fileName}`
        });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['today-shift'] });
      queryClient.invalidateQueries({ queryKey: ['recent-shifts'] });
      setSelectedImage(null);
      setImagePreview(null);
      setIsCheckInDialogOpen(false);
      toast({
        title: "เช็คอินสำเร็จ",
        description: "บันทึกเวลาเข้างานเรียบร้อยแล้ว"
      });
    }
  });

  const checkOutMutation = useMutation({
    mutationFn: async ({ image }: { image: File }) => {
      // Upload image to storage
      const fileName = `checkout-${user?.staff_id}-${Date.now()}.jpg`;
      const { error: uploadError } = await supabase.storage
        .from('staff-photos')
        .upload(fileName, image);

      if (uploadError) throw uploadError;

      // Update shift record
      const { error } = await supabase
        .from('staff_shifts')
        .update({
          clock_out: new Date().toISOString(),
          notes: (todayShift?.notes || '') + ` | เช็คเอาท์ด้วยรูปภาพ: ${fileName}`
        })
        .eq('id', todayShift?.id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['today-shift'] });
      queryClient.invalidateQueries({ queryKey: ['recent-shifts'] });
      setSelectedImage(null);
      setImagePreview(null);
      setIsCheckOutDialogOpen(false);
      toast({
        title: "เช็คเอาท์สำเร็จ",
        description: "บันทึกเวลาออกงานเรียบร้อยแล้ว"
      });
    }
  });

  const handleImageSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const formatTime = (dateString: string | null) => {
    if (!dateString) return '-';
    return new Date(dateString).toLocaleTimeString('th-TH', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('th-TH', {
      weekday: 'short',
      day: 'numeric',
      month: 'short'
    });
  };

  const canCheckIn = !todayShift;
  const canCheckOut = todayShift && todayShift.clock_in && !todayShift.clock_out;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header - Fixed */}
      <div className="bg-white border-b border-gray-200 p-4 sticky top-0 z-10 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Clock className="h-6 w-6 text-blue-500" />
            <div>
              <h1 className="text-lg font-bold">ระบบเช็คชื่อ</h1>
              <p className="text-sm text-gray-600">{user?.staff_name}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {/* Today's Status */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              สถานะวันนี้
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <p className="text-sm text-gray-600">เข้างาน</p>
                <p className="text-xl font-bold text-green-600">
                  {formatTime(todayShift?.clock_in)}
                </p>
              </div>
              <div className="text-center">
                <p className="text-sm text-gray-600">ออกงาน</p>
                <p className="text-xl font-bold text-red-600">
                  {formatTime(todayShift?.clock_out)}
                </p>
              </div>
            </div>

            <div className="flex gap-2">
              {canCheckIn && (
                <Dialog open={isCheckInDialogOpen} onOpenChange={setIsCheckInDialogOpen}>
                  <DialogTrigger asChild>
                    <Button className="flex-1 bg-green-600 hover:bg-green-700">
                      <CheckCircle className="h-4 w-4 mr-2" />
                      เช็คอิน
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-sm mx-4">
                    <DialogHeader>
                      <DialogTitle>เช็คอิน - ถ่ายรูปยืนยัน</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="text-center">
                        <label htmlFor="checkin-photo" className="cursor-pointer">
                          <div className="w-full h-48 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center bg-gray-50">
                            {imagePreview ? (
                              <img src={imagePreview} alt="Preview" className="w-full h-full object-cover rounded-lg" />
                            ) : (
                              <div className="text-center">
                                <Camera className="h-12 w-12 mx-auto text-gray-400 mb-2" />
                                <p className="text-gray-600">แตะเพื่อถ่ายรูป</p>
                              </div>
                            )}
                          </div>
                        </label>
                        <input
                          id="checkin-photo"
                          type="file"
                          accept="image/*"
                          capture="user"
                          onChange={handleImageSelect}
                          className="hidden"
                        />
                      </div>
                      <Button
                        className="w-full"
                        onClick={() => checkInMutation.mutate({ image: selectedImage! })}
                        disabled={!selectedImage || checkInMutation.isPending}
                      >
                        {checkInMutation.isPending ? 'กำลังบันทึก...' : 'ยืนยันเช็คอิน'}
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              )}

              {canCheckOut && (
                <Dialog open={isCheckOutDialogOpen} onOpenChange={setIsCheckOutDialogOpen}>
                  <DialogTrigger asChild>
                    <Button className="flex-1 bg-red-600 hover:bg-red-700">
                      <X className="h-4 w-4 mr-2" />
                      เช็คเอาท์
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-sm mx-4">
                    <DialogHeader>
                      <DialogTitle>เช็คเอาท์ - ถ่ายรูปยืนยัน</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="text-center">
                        <label htmlFor="checkout-photo" className="cursor-pointer">
                          <div className="w-full h-48 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center bg-gray-50">
                            {imagePreview ? (
                              <img src={imagePreview} alt="Preview" className="w-full h-full object-cover rounded-lg" />
                            ) : (
                              <div className="text-center">
                                <Camera className="h-12 w-12 mx-auto text-gray-400 mb-2" />
                                <p className="text-gray-600">แตะเพื่อถ่ายรูป</p>
                              </div>
                            )}
                          </div>
                        </label>
                        <input
                          id="checkout-photo"
                          type="file"
                          accept="image/*"
                          capture="user"
                          onChange={handleImageSelect}
                          className="hidden"
                        />
                      </div>
                      <Button
                        className="w-full"
                        onClick={() => checkOutMutation.mutate({ image: selectedImage! })}
                        disabled={!selectedImage || checkOutMutation.isPending}
                      >
                        {checkOutMutation.isPending ? 'กำลังบันทึก...' : 'ยืนยันเช็คเอาท์'}
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Recent History */}
        <Card>
          <CardHeader>
            <CardTitle>ประวัติเช็คชื่อ</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentShifts?.map((shift) => (
                <div key={shift.id} className="flex justify-between items-center p-3 border rounded">
                  <div>
                    <p className="font-medium">{formatDate(shift.shift_date)}</p>
                    <div className="flex gap-4 text-sm text-gray-600">
                      <span>เข้า: {formatTime(shift.clock_in)}</span>
                      <span>ออก: {formatTime(shift.clock_out)}</span>
                    </div>
                  </div>
                  <Badge variant={shift.clock_out ? 'default' : 'secondary'}>
                    {shift.clock_out ? 'เสร็จสมบูรณ์' : 'ยังไม่ออกงาน'}
                  </Badge>
                </div>
              ))}

              {!recentShifts?.length && (
                <p className="text-center text-gray-500 py-8">ไม่มีประวัติเช็คชื่อ</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default StaffCheckIn;
