

import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase } from '@/integrations/supabase/client';
import ImprovedPaymentSystem from './ImprovedPaymentSystem';
import { useAuth } from '@/contexts/AuthContext';
import { Receipt, Clock, CreditCard, Banknote, Smartphone, Bell, AlertCircle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface PaymentSystemWrapperProps {
  selectedTable?: any;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}

const PaymentSystemWrapper = ({ selectedTable, open, onOpenChange }: PaymentSystemWrapperProps) => {
  const [selectedOrder, setSelectedOrder] = useState<any>(null);
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false);
  const [pendingQRPayments, setPendingQRPayments] = useState<any>({});
  const { user } = useAuth();

  // Check if user can approve payments (admin or manager)
  const canApprovePayments = user?.role === 'admin' || user?.role === 'manager';

  // Load pending QR payments from localStorage
  const loadPendingQRPayments = () => {
    const stored = localStorage.getItem('pendingQRPayments');
    if (stored) {
      const parsed = JSON.parse(stored);
      setPendingQRPayments(parsed);
      return parsed;
    }
    return {};
  };

  // ดึงข้อมูลออเดอร์ที่รอชำระเงินทั้งหมด
  const { data: orders = [], isLoading, refetch } = useQuery({
    queryKey: ['orders-ready-for-payment'],
    queryFn: async () => {
      console.log('Fetching all orders ready for payment...');
      
      const { data: allOrders, error } = await supabase
        .from('orders')
        .select(`
          *,
          tables (table_number),
          order_items (
            id, quantity, unit_price,
            menu_items (name)
          ),
          takeaway_orders (customer_name, customer_phone),
          payments (id, payment_method, amount)
        `)
        .in('status', ['pending', 'preparing', 'ready', 'served'])
        .order('created_at', { ascending: true });

      if (error) {
        console.error('Error fetching orders:', error);
        throw error;
      }

      console.log('All orders found:', allOrders?.length || 0);

      // กรองเฉพาะออเดอร์ที่ยังไม่ได้ชำระเงิน
      const unpaidOrders = allOrders?.filter(order => {
        const hasPayment = order.payments && order.payments.length > 0;
        console.log(`Order ${order.order_number}: has payment = ${hasPayment}`);
        return !hasPayment;
      }) || [];

      console.log('Unpaid orders:', unpaidOrders.length);
      
      // Load pending QR payments
      const pending = loadPendingQRPayments();
      
      return unpaidOrders;
    },
    refetchInterval: 5000 // รีเฟรชทุก 5 วินาที
  });

  // รีเฟรช pending QR payments ทุก 3 วินาที
  useEffect(() => {
    const interval = setInterval(() => {
      loadPendingQRPayments();
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  // Handle selectedTable prop from TableManagement
  useEffect(() => {
    if (selectedTable && open) {
      // Find the order for this table
      const tableOrder = orders?.find(order => 
        order.order_type === 'dine-in' && order.table_id === selectedTable.id
      );
      if (tableOrder) {
        setSelectedOrder(tableOrder);
        setIsPaymentDialogOpen(true);
      }
    }
  }, [selectedTable, open, orders]);

  const handleOrderSelect = (order: any) => {
    setSelectedOrder(order);
    setIsPaymentDialogOpen(true);
  };

  const handlePaymentComplete = () => {
    refetch();
    setSelectedOrder(null);
    setIsPaymentDialogOpen(false);
    // Reload pending payments
    loadPendingQRPayments();
    // Close the parent dialog if it was opened from TableManagement
    if (onOpenChange) {
      onOpenChange(false);
    }
  };

  const getPaymentMethodIcon = (method: string) => {
    switch (method) {
      case 'cash':
        return <Banknote className="h-4 w-4" />;
      case 'credit_card':
        return <CreditCard className="h-4 w-4" />;
      case 'qr_code':
        return <Smartphone className="h-4 w-4" />;
      default:
        return <Receipt className="h-4 w-4" />;
    }
  };

  // Check if order has pending QR payment
  const hasQRPending = (orderId: string) => {
    return pendingQRPayments[orderId] && pendingQRPayments[orderId].status === 'slip_uploaded';
  };

  // Get pending QR orders count
  const pendingQROrdersCount = Object.values(pendingQRPayments).filter(
    (payment: any) => payment.status === 'slip_uploaded'
  ).length;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
        <span className="ml-2">กำลังโหลดข้อมูล...</span>
      </div>
    );
  }

  // If this component is used as a dialog from TableManagement
  if (selectedTable && open !== undefined && onOpenChange) {
    return (
      <ImprovedPaymentSystem
        order={selectedOrder}
        open={isPaymentDialogOpen}
        onOpenChange={(open) => {
          setIsPaymentDialogOpen(open);
          if (!open) {
            onOpenChange(false);
          }
        }}
        onPaymentComplete={handlePaymentComplete}
      />
    );
  }

  // Default standalone view
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <Receipt className="h-6 w-6" />
          ระบบชำระเงิน
        </h2>
        <Button onClick={() => refetch()} variant="outline" size="sm">
          รีเฟรช
        </Button>
      </div>

      {/* แจ้งเตือนสำหรับออเดอร์ที่มีสลิปรอการยืนยัน */}
      {canApprovePayments && pendingQROrdersCount > 0 && (
        <Alert className="border-orange-200 bg-orange-50">
          <Bell className="h-4 w-4 text-orange-600" />
          <AlertDescription className="text-orange-800">
            <div className="flex items-center justify-between">
              <span className="font-medium">
                🔔 มีการชำระเงินด้วย QR Code รอการยืนยัน {pendingQROrdersCount} รายการ
              </span>
              <Badge variant="outline" className="bg-orange-100 text-orange-700">
                รอดำเนินการ
              </Badge>
            </div>
            <div className="mt-2 text-sm">
              กรุณาตรวจสอบและยืนยันการชำระเงินในออเดอร์ที่มีสลิปแนบมา
            </div>
          </AlertDescription>
        </Alert>
      )}

      {orders.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Receipt className="h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-600 mb-2">
              ไม่มีออเดอร์ที่รอชำระเงิน
            </h3>
            <p className="text-gray-500 text-center">
              ออเดอร์ทั้งหมดได้ชำระเงินเรียบร้อยแล้ว
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {orders.map((order) => (
            <Card key={order.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">{order.order_number}</CardTitle>
                  <Badge variant={order.status === 'ready' ? 'default' : 'secondary'}>
                    {order.status === 'pending' ? 'รอดำเนินการ' :
                     order.status === 'preparing' ? 'กำลังเตรียม' :
                     order.status === 'ready' ? 'พร้อมเสิร์ฟ' :
                     order.status === 'served' ? 'เสิร์ฟแล้ว' :
                     order.status}
                  </Badge>
                </div>
                <div className="text-sm text-gray-600">
                  {order.order_type === 'dine-in' && order.tables ? (
                    <span>โต๊ะ {order.tables.table_number}</span>
                  ) : order.order_type === 'takeaway' && order.takeaway_orders?.[0] ? (
                    <span>กลับบ้าน - {order.takeaway_orders[0].customer_name}</span>
                  ) : (
                    <span>{order.order_type}</span>
                  )}
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-sm">
                    <span>จำนวนรายการ:</span>
                    <span>{order.order_items?.length || 0}</span>
                  </div>
                  <div className="flex justify-between font-semibold text-lg">
                    <span>ยอดรวม:</span>
                    <span className="text-green-600">฿{order.total_amount?.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm text-gray-500">
                    <span>เวลา:</span>
                    <span>{new Date(order.created_at).toLocaleTimeString('th-TH', { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}</span>
                  </div>
                </div>

                {/* แสดงเครื่องหมายเตือนหากมีสลิปรอยืนยัน */}
                {hasQRPending(order.id) && (
                  <div className="mb-3 p-2 bg-orange-100 border border-orange-200 rounded-lg">
                    <div className="flex items-center gap-2 text-orange-700 text-sm">
                      <AlertCircle className="h-4 w-4" />
                      <span className="font-medium">มีสลิปรอการยืนยัน</span>
                    </div>
                  </div>
                )}

                <Button 
                  onClick={() => handleOrderSelect(order)}
                  className="w-full"
                  variant={hasQRPending(order.id) ? "default" : "outline"}
                >
                  <Receipt className="h-4 w-4 mr-2" />
                  {hasQRPending(order.id) ? 
                    'ยืนยันการชำระเงิน' : 'ชำระเงิน'}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Payment Dialog */}
      <ImprovedPaymentSystem
        order={selectedOrder}
        open={isPaymentDialogOpen}
        onOpenChange={setIsPaymentDialogOpen}
        onPaymentComplete={handlePaymentComplete}
      />
    </div>
  );
};

export default PaymentSystemWrapper;

