
import { format } from 'date-fns';
import { th } from 'date-fns/locale';

interface ReceiptTemplateProps {
  order: any;
}

const ReceiptTemplate = ({ order }: ReceiptTemplateProps) => {
  const formatDate = (date: string) => {
    return format(new Date(date), 'dd/MM/yyyy HH:mm', { locale: th });
  };

  const formatCurrency = (amount: number) => {
    return amount.toLocaleString('th-TH', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
  };

  return (
    <div id="receipt-content" className="receipt">
      {/* Header */}
      <div className="header">
        <div className="shop-name">ร้านอาหารของเรา</div>
        <div>123 ถนนสุขุมวิท กรุงเทพฯ 10110</div>
        <div>โทร: 02-123-4567</div>
        <div>TAX ID: 0123456789012</div>
      </div>

      {/* Order Info */}
      <div className="order-info">
        <div>ใบเสร็จเลขที่: {order.order_number}</div>
        <div>วันที่: {formatDate(order.created_at)}</div>
        {order.order_type === 'dine-in' && order.tables && (
          <div>โต๊ะ: {order.tables.table_number}</div>
        )}
        {order.order_type === 'takeaway' && order.takeaway_orders?.[0] && (
          <div>ลูกค้า: {order.takeaway_orders[0].customer_name}</div>
        )}
        <div>จำนวนลูกค้า: {order.customer_count} คน</div>
      </div>

      <div className="separator"></div>

      {/* Items */}
      <div className="items">
        {order.order_items?.map((item: any, index: number) => (
          <div key={index} className="item">
            <div className="item-name">{item.menu_items?.name}</div>
            <div className="item-qty">{item.quantity}</div>
            <div className="item-price">฿{formatCurrency(item.total_price)}</div>
          </div>
        ))}
      </div>

      <div className="separator"></div>

      {/* Total */}
      <div className="total">
        <span>รวมทั้งสิ้น:</span>
        <span>฿{formatCurrency(order.total_amount)}</span>
      </div>

      {/* Payment Info */}
      {order.payments && order.payments.length > 0 && (
        <div className="order-info">
          <div>ชำระโดย: {
            order.payments[0].payment_method === 'cash' ? 'เงินสด' :
            order.payments[0].payment_method === 'credit_card' ? 'บัตรเครดิต' :
            order.payments[0].payment_method === 'qr_code' ? 'QR Code' : 
            order.payments[0].payment_method
          }</div>
          {order.payments[0].payment_method === 'cash' && (
            <>
              <div>เงินที่รับ: ฿{formatCurrency(order.payments[0].received_amount)}</div>
              {order.payments[0].change_amount > 0 && (
                <div>เงินทอน: ฿{formatCurrency(order.payments[0].change_amount)}</div>
              )}
            </>
          )}
        </div>
      )}

      {/* Footer */}
      <div className="footer">
        <div>ขอบคุณที่ใช้บริการ</div>
        <div>โปรดเก็บใบเสร็จไว้เป็นหลักฐาน</div>
        <div>{formatDate(new Date().toISOString())}</div>
      </div>
    </div>
  );
};

export default ReceiptTemplate;
