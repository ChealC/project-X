
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { supabase } from '@/integrations/supabase/client';
import { Activity, Search, Filter, Clock, User, Database } from 'lucide-react';

const ActivityLog = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [filterTable, setFilterTable] = useState('all');

  const { data: activities, isLoading } = useQuery({
    queryKey: ['activities', searchTerm, filterType, filterTable],
    queryFn: async () => {
      let query = supabase
        .from('activity_logs')
        .select('*, staff(name)')
        .order('created_at', { ascending: false })
        .limit(100);

      if (filterType !== 'all') {
        query = query.eq('action_type', filterType);
      }

      if (filterTable !== 'all') {
        query = query.eq('table_name', filterTable);
      }

      if (searchTerm) {
        query = query.or(`table_name.ilike.%${searchTerm}%,action_type.ilike.%${searchTerm}%`);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data;
    }
  });

  const getActionColor = (action: string) => {
    switch (action) {
      case 'INSERT': return 'bg-green-500';
      case 'UPDATE': return 'bg-blue-500';
      case 'DELETE': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const formatData = (data: any) => {
    if (!data) return 'ไม่มีข้อมูล';
    return JSON.stringify(data, null, 2);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            ประวัติการใช้งานระบบ
          </CardTitle>
        </CardHeader>
        <CardContent>
          {/* Filters */}
          <div className="flex gap-4 mb-6">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="ค้นหา..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="ประเภท" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">ทั้งหมด</SelectItem>
                <SelectItem value="INSERT">เพิ่มข้อมูล</SelectItem>
                <SelectItem value="UPDATE">แก้ไขข้อมูล</SelectItem>
                <SelectItem value="DELETE">ลบข้อมูล</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterTable} onValueChange={setFilterTable}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="ตาราง" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">ทั้งหมด</SelectItem>
                <SelectItem value="orders">ออเดอร์</SelectItem>
                <SelectItem value="payments">ชำระเงิน</SelectItem>
                <SelectItem value="staff_shifts">เวลาทำงาน</SelectItem>
                <SelectItem value="staff">พนักงาน</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Activity List */}
          <ScrollArea className="h-96">
            <div className="space-y-3">
              {isLoading ? (
                <div className="text-center py-8">กำลังโหลด...</div>
              ) : activities?.length === 0 ? (
                <div className="text-center py-8">ไม่พบข้อมูล</div>
              ) : (
                activities?.map((activity) => (
                  <Card key={activity.id} className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge className={getActionColor(activity.action_type)}>
                            {activity.action_type}
                          </Badge>
                          <Badge variant="outline">{activity.table_name}</Badge>
                          <div className="flex items-center gap-1 text-sm text-gray-500">
                            <Clock className="h-3 w-3" />
                            {new Date(activity.created_at).toLocaleString('th-TH')}
                          </div>
                        </div>
                        
                        {activity.staff && (
                          <div className="flex items-center gap-1 text-sm text-gray-600 mb-2">
                            <User className="h-3 w-3" />
                            {activity.staff.name}
                          </div>
                        )}

                        {activity.old_data && (
                          <details className="mb-2">
                            <summary className="cursor-pointer text-sm font-medium text-red-600">
                              ข้อมูลเดิม
                            </summary>
                            <pre className="text-xs bg-red-50 p-2 rounded mt-1 overflow-x-auto">
                              {formatData(activity.old_data)}
                            </pre>
                          </details>
                        )}

                        {activity.new_data && (
                          <details>
                            <summary className="cursor-pointer text-sm font-medium text-green-600">
                              ข้อมูลใหม่
                            </summary>
                            <pre className="text-xs bg-green-50 p-2 rounded mt-1 overflow-x-auto">
                              {formatData(activity.new_data)}
                            </pre>
                          </details>
                        )}
                      </div>
                    </div>
                  </Card>
                ))
              )}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
};

export default ActivityLog;
