
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { CheckCircle, X, Eye, Clock, AlertCircle } from 'lucide-react';

const QRPaymentConfirmationSystem = () => {
  const [pendingPayments, setPendingPayments] = useState<any[]>([]);
  const [selectedSlip, setSelectedSlip] = useState<any>(null);
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  // Load pending payments from localStorage
  const loadPendingPayments = () => {
    const stored = localStorage.getItem('pendingQRPayments');
    if (stored) {
      const parsed = JSON.parse(stored);
      const paymentsArray = Object.values(parsed).filter((payment: any) => 
        payment.status === 'slip_uploaded'
      );
      setPendingPayments(paymentsArray);
    }
  };

  useEffect(() => {
    loadPendingPayments();
    const interval = setInterval(loadPendingPayments, 2000);
    return () => clearInterval(interval);
  }, []);

  const confirmPayment = useMutation({
    mutationFn: async (payment: any) => {
      // Process payment in database
      const { error: paymentError } = await supabase
        .from('payments')
        .insert({
          order_id: payment.orderId,
          amount: 0, // Will be updated with actual amount
          payment_method: 'qr_code',
          staff_id: user?.staff_id,
          reference_number: `QR-${Date.now()}`
        });

      if (paymentError) throw paymentError;

      // Update order status
      const { error: orderError } = await supabase
        .from('orders')
        .update({ status: 'completed' })
        .eq('id', payment.orderId);

      if (orderError) throw orderError;

      // Remove from localStorage
      const stored = JSON.parse(localStorage.getItem('pendingQRPayments') || '{}');
      delete stored[payment.orderId];
      localStorage.setItem('pendingQRPayments', JSON.stringify(stored));

      return payment;
    },
    onSuccess: (payment) => {
      toast({
        title: "ยืนยันการชำระเงินสำเร็จ",
        description: `ออเดอร์ ${payment.orderNumber} ได้รับการยืนยันแล้ว`
      });
      loadPendingPayments();
      queryClient.invalidateQueries({ queryKey: ['orders'] });
    },
    onError: (error: any) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const rejectPayment = (payment: any) => {
    const stored = JSON.parse(localStorage.getItem('pendingQRPayments') || '{}');
    delete stored[payment.orderId];
    localStorage.setItem('pendingQRPayments', JSON.stringify(stored));
    
    toast({
      title: "ปฏิเสธการชำระเงิน",
      description: `ออเดอร์ ${payment.orderNumber} ถูกปฏิเสธ`
    });
    
    loadPendingPayments();
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">การชำระเงินด้วย QR Code รอยืนยัน</h3>
        <Badge variant="outline">{pendingPayments.length} รายการ</Badge>
      </div>

      {pendingPayments.length === 0 ? (
        <Alert>
          <CheckCircle className="h-4 w-4" />
          <AlertDescription>
            ไม่มีการชำระเงินรอการยืนยัน
          </AlertDescription>
        </Alert>
      ) : (
        <ScrollArea className="h-96">
          <div className="space-y-3">
            {pendingPayments.map((payment) => (
              <Card key={payment.orderId}>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center justify-between">
                    <span>ออเดอร์ {payment.orderNumber}</span>
                    <Badge className="bg-orange-500">รอยืนยัน</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="text-xs text-gray-500">
                    เวลาอัพโหลด: {new Date(payment.timestamp).toLocaleString('th-TH')}
                  </div>
                  
                  <div className="grid grid-cols-3 gap-2">
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => setSelectedSlip(payment)}
                    >
                      <Eye className="h-3 w-3 mr-1" />
                      ดูสลิป
                    </Button>
                    <Button 
                      size="sm" 
                      variant="destructive"
                      onClick={() => rejectPayment(payment)}
                    >
                      <X className="h-3 w-3 mr-1" />
                      ปฏิเสธ
                    </Button>
                    <Button 
                      size="sm"
                      onClick={() => confirmPayment.mutate(payment)}
                      disabled={confirmPayment.isPending}
                      className="bg-green-500 hover:bg-green-600"
                    >
                      <CheckCircle className="h-3 w-3 mr-1" />
                      ยืนยัน
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </ScrollArea>
      )}

      {/* Slip Preview Modal */}
      {selectedSlip && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <Card className="max-w-md w-full max-h-[90vh] overflow-auto">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>สลิปการโอนเงิน</span>
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => setSelectedSlip(null)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-sm">
                <div>ออเดอร์: {selectedSlip.orderNumber}</div>
                <div>เวลา: {new Date(selectedSlip.timestamp).toLocaleString('th-TH')}</div>
              </div>
              
              <img 
                src={selectedSlip.slipData} 
                alt="สลิปการโอนเงิน" 
                className="w-full rounded-lg border"
              />
              
              <div className="grid grid-cols-2 gap-3">
                <Button 
                  variant="destructive"
                  onClick={() => {
                    rejectPayment(selectedSlip);
                    setSelectedSlip(null);
                  }}
                >
                  <X className="h-4 w-4 mr-2" />
                  ปฏิเสธ
                </Button>
                <Button 
                  onClick={() => {
                    confirmPayment.mutate(selectedSlip);
                    setSelectedSlip(null);
                  }}
                  disabled={confirmPayment.isPending}
                  className="bg-green-500 hover:bg-green-600"
                >
                  <CheckCircle className="h-4 w-4 mr-2" />
                  ยืนยัน
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};

export default QRPaymentConfirmationSystem;
