
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/integrations/supabase/client';
import { 
  CheckCircle, 
  Clock, 
  Coffee, 
  Users, 
  Receipt,
  QrCode,
  User
} from 'lucide-react';
import QRPaymentConfirmationSystem from './QRPaymentConfirmationSystem';
import StaffCheckIn from './StaffCheckIn';

const MobileServiceInterface = () => {
  const [selectedOrder, setSelectedOrder] = useState<any>(null);

  const { data: orders = [] } = useQuery({
    queryKey: ['service-orders'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('orders')
        .select(`
          *,
          tables (table_number),
          order_items (
            id, quantity, unit_price,
            menu_items (name, category)
          ),
          takeaway_orders (customer_name)
        `)
        .in('status', ['ready', 'served'])
        .order('created_at', { ascending: true });

      if (error) throw error;
      return data || [];
    },
    refetchInterval: 3000
  });

  const updateOrderStatus = async (orderId: string, status: string) => {
    const { error } = await supabase
      .from('orders')
      .update({ status })
      .eq('id', orderId);

    if (!error) {
      window.location.reload();
    }
  };

  const readyOrders = orders.filter(order => order.status === 'ready');
  const servedOrders = orders.filter(order => order.status === 'served');

  return (
    <div className="min-h-screen bg-gray-50 p-2">
      <div className="max-w-md mx-auto space-y-4">
        <div className="bg-white rounded-lg p-4 shadow-sm">
          <h1 className="text-xl font-bold text-center text-blue-600">
            ระบบพนักงานเสิร์ฟ
          </h1>
        </div>

        <Tabs defaultValue="orders" className="w-full">
          <TabsList className="grid w-full grid-cols-4 h-12">
            <TabsTrigger value="orders" className="text-xs">
              <Coffee className="h-4 w-4 mb-1" />
              <span>ออเดอร์</span>
            </TabsTrigger>
            <TabsTrigger value="payments" className="text-xs">
              <QrCode className="h-4 w-4 mb-1" />
              <span>QR Pay</span>
            </TabsTrigger>
            <TabsTrigger value="checkin" className="text-xs">
              <User className="h-4 w-4 mb-1" />
              <span>เช็คชื่อ</span>
            </TabsTrigger>
            <TabsTrigger value="history" className="text-xs">
              <Receipt className="h-4 w-4 mb-1" />
              <span>ประวัติ</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="orders" className="space-y-4 mt-4">
            <div className="grid grid-cols-2 gap-2">
              <Card className="bg-orange-50 border-orange-200">
                <CardContent className="p-3 text-center">
                  <div className="text-2xl font-bold text-orange-600">
                    {readyOrders.length}
                  </div>
                  <div className="text-sm text-orange-600">พร้อมเสิร์ฟ</div>
                </CardContent>
              </Card>
              <Card className="bg-green-50 border-green-200">
                <CardContent className="p-3 text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {servedOrders.length}
                  </div>
                  <div className="text-sm text-green-600">เสิร์ฟแล้ว</div>
                </CardContent>
              </Card>
            </div>

            <ScrollArea className="h-[calc(100vh-280px)]">
              <div className="space-y-3">
                {readyOrders.map((order) => (
                  <Card key={order.id} className="border-orange-200 bg-orange-50">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm flex items-center justify-between">
                        <span>{order.order_number}</span>
                        <Badge className="bg-orange-500">พร้อมเสิร์ฟ</Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="text-xs">
                        {order.order_type === 'dine-in' && order.tables ? (
                          <span>🏷️ โต๊ะ {order.tables.table_number}</span>
                        ) : (
                          <span>📦 {order.takeaway_orders?.[0]?.customer_name}</span>
                        )}
                      </div>
                      
                      <div className="text-xs">
                        <div className="font-medium">รายการ:</div>
                        {order.order_items?.slice(0, 2).map((item: any, index: number) => (
                          <div key={index} className="ml-2">
                            • {item.menu_items.name} x{item.quantity}
                          </div>
                        ))}
                        {order.order_items?.length > 2 && (
                          <div className="ml-2 text-gray-500">
                            และอีก {order.order_items.length - 2} รายการ...
                          </div>
                        )}
                      </div>

                      <Button 
                        size="sm"
                        onClick={() => updateOrderStatus(order.id, 'served')}
                        className="w-full bg-green-500 hover:bg-green-600"
                      >
                        <CheckCircle className="h-3 w-3 mr-1" />
                        เสิร์ฟแล้ว
                      </Button>
                    </CardContent>
                  </Card>
                ))}

                {readyOrders.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    ไม่มีออเดอร์ที่พร้อมเสิร์ฟ
                  </div>
                )}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="payments" className="mt-4">
            <QRPaymentConfirmationSystem />
          </TabsContent>

          <TabsContent value="checkin" className="mt-4">
            <StaffCheckIn />
          </TabsContent>

          <TabsContent value="history" className="mt-4">
            <ScrollArea className="h-[calc(100vh-200px)]">
              <div className="space-y-3">
                {servedOrders.map((order) => (
                  <Card key={order.id} className="border-green-200 bg-green-50">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm flex items-center justify-between">
                        <span>{order.order_number}</span>
                        <Badge variant="secondary">เสิร์ฟแล้ว</Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-xs space-y-1">
                        <div>
                          {order.order_type === 'dine-in' && order.tables ? (
                            <span>🏷️ โต๊ะ {order.tables.table_number}</span>
                          ) : (
                            <span>📦 {order.takeaway_orders?.[0]?.customer_name}</span>
                          )}
                        </div>
                        <div>⏰ {new Date(order.updated_at).toLocaleTimeString('th-TH')}</div>
                        <div>💰 ฿{order.total_amount?.toFixed(2)}</div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default MobileServiceInterface;
