
import React from 'react';
import { useAuth } from '@/contexts/AuthContext';

interface ProtectedRouteProps {
  children: React.ReactNode;
  page?: string;
  permission?: 'view' | 'edit' | 'delete';
  fallback?: React.ReactNode;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ 
  children, 
  page, 
  permission = 'view',
  fallback 
}) => {
  const { user, hasPermission } = useAuth();

  if (!user) {
    return null; // Will be handled by main app
  }

  if (page && !hasPermission(page, permission)) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-center">
          <div className="text-6xl mb-4">🚫</div>
          <h2 className="text-xl font-semibold text-gray-700 mb-2">
            ไม่มีสิทธิ์เข้าถึง
          </h2>
          <p className="text-gray-500">
            คุณไม่มีสิทธิ์ในการเข้าถึงหน้านี้
          </p>
          {fallback && <div className="mt-4">{fallback}</div>}
        </div>
      </div>
    );
  }

  return <>{children}</>;
};

export default ProtectedRoute;
