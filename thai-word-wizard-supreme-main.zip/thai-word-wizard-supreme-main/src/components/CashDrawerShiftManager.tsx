
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { DollarSign, Lock, Unlock, Clock } from 'lucide-react';

const CashDrawerShiftManager = () => {
  const [openingAmount, setOpeningAmount] = useState('1000');
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  // Get current shift
  const { data: currentShift, isLoading } = useQuery({
    queryKey: ['current-cash-shift'],
    queryFn: async () => {
      if (!user?.staff_id) return null;
      
      const today = new Date().toISOString().split('T')[0];
      const { data, error } = await supabase
        .from('cash_drawer_shifts')
        .select('*')
        .eq('shift_date', today)
        .order('created_at', { ascending: false })
        .limit(1)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching shift:', error);
        return null;
      }

      return data;
    },
    enabled: !!user?.staff_id
  });

  const openShift = useMutation({
    mutationFn: async () => {
      if (!user?.staff_id) throw new Error('ไม่พบข้อมูลพนักงาน');
      
      const amount = parseFloat(openingAmount);
      if (isNaN(amount) || amount < 0) {
        throw new Error('กรุณาใส่จำนวนเงินที่ถูกต้อง');
      }

      const today = new Date().toISOString().split('T')[0];
      
      const { data, error } = await supabase
        .from('cash_drawer_shifts')
        .insert({
          staff_id: user.staff_id,
          shift_date: today,
          opening_amount: amount,
          status: 'open'
        })
        .select()
        .single();

      if (error) throw error;

      // Record opening transaction
      await supabase
        .from('cash_drawer_transactions')
        .insert({
          shift_id: data.id,
          transaction_type: 'opening',
          amount: amount,
          description: 'เปิดกะ - ยอดเงินเริ่มต้น',
          staff_id: user.staff_id
        });

      return data;
    },
    onSuccess: () => {
      toast({
        title: "เปิดกะสำเร็จ",
        description: `เปิดกะด้วยเงินเริ่มต้น ฿${openingAmount}`
      });
      queryClient.invalidateQueries({ queryKey: ['current-cash-shift'] });
    },
    onError: (error: any) => {
      toast({
        title: "ไม่สามารถเปิดกะได้",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const closeShift = useMutation({
    mutationFn: async () => {
      if (!currentShift) throw new Error('ไม่พบกะที่เปิดอยู่');
      
      // Calculate total sales and transactions
      const { data: transactions } = await supabase
        .from('cash_drawer_transactions')
        .select('*')
        .eq('shift_id', currentShift.id);

      const totalSales = transactions
        ?.filter(t => t.transaction_type === 'sale')
        .reduce((sum, t) => sum + (t.amount || 0), 0) || 0;

      const closingAmount = currentShift.opening_amount + totalSales;

      const { error } = await supabase
        .from('cash_drawer_shifts')
        .update({ 
          status: 'closed',
          closing_amount: closingAmount,
          closed_at: new Date().toISOString()
        })
        .eq('id', currentShift.id);

      if (error) throw error;

      return { totalSales, closingAmount };
    },
    onSuccess: (data) => {
      toast({
        title: "ปิดกะสำเร็จ",
        description: `ยอดขาย: ฿${data.totalSales.toFixed(2)}`
      });
      queryClient.invalidateQueries({ queryKey: ['current-cash-shift'] });
    },
    onError: (error: any) => {
      toast({
        title: "ไม่สามารถปิดกะได้",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  if (isLoading) {
    return <div className="flex justify-center p-4">กำลังโหลด...</div>;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <DollarSign className="h-5 w-5" />
          จัดการกะลิ้นชักเงินสด
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {currentShift ? (
          <div className="space-y-4">
            <Alert>
              <Clock className="h-4 w-4" />
              <AlertDescription>
                <div className="space-y-1">
                  <div className="font-medium">กะปัจจุบัน: {currentShift.status === 'open' ? 'เปิด' : 'ปิด'}</div>
                  <div>วันที่: {new Date(currentShift.shift_date).toLocaleDateString('th-TH')}</div>
                  <div>เงินเริ่มต้น: ฿{currentShift.opening_amount?.toFixed(2)}</div>
                  {currentShift.status === 'open' && (
                    <div>เวลาเปิด: {new Date(currentShift.created_at).toLocaleTimeString('th-TH')}</div>
                  )}
                </div>
              </AlertDescription>
            </Alert>

            {currentShift.status === 'open' ? (
              <Button 
                onClick={() => closeShift.mutate()}
                disabled={closeShift.isPending}
                variant="destructive"
                className="w-full"
              >
                <Lock className="h-4 w-4 mr-2" />
                {closeShift.isPending ? 'กำลังปิดกะ...' : 'ปิดกะ'}
              </Button>
            ) : (
              <Badge variant="secondary" className="w-full justify-center p-2">
                กะถูกปิดแล้ว
              </Badge>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            <Alert>
              <AlertDescription>
                ไม่มีกะที่เปิดอยู่ กรุณาเปิดกะใหม่เพื่อเริ่มต้นการทำงาน
              </AlertDescription>
            </Alert>

            <div>
              <Label htmlFor="opening-amount">จำนวนเงินเริ่มต้น (บาท)</Label>
              <Input
                id="opening-amount"
                type="number"
                value={openingAmount}
                onChange={(e) => setOpeningAmount(e.target.value)}
                placeholder="1000"
                min="0"
                step="0.01"
              />
            </div>

            <Button 
              onClick={() => openShift.mutate()}
              disabled={openShift.isPending}
              className="w-full"
            >
              <Unlock className="h-4 w-4 mr-2" />
              {openShift.isPending ? 'กำลังเปิดกะ...' : 'เปิดกะใหม่'}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default CashDrawerShiftManager;
