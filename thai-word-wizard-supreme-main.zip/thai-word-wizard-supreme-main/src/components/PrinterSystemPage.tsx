
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useEpsonPrinter } from '@/hooks/useEpsonPrinter';
import { Printer, Wifi, WifiOff, FileText, Settings } from 'lucide-react';
import EpsonPrintSystem from './EpsonPrintSystem';

const PrinterSystemPage = () => {
  const { status } = useEpsonPrinter();
  const [previewContent] = useState({
    order_number: 'TEST-001',
    order_type: 'dine-in',
    tables: { table_number: '5' },
    total_amount: 350.00,
    created_at: new Date().toISOString(),
    order_items: [
      {
        quantity: 2,
        unit_price: 120,
        menu_items: { name: 'ผัดไทยกุ้ง' }
      },
      {
        quantity: 1,
        unit_price: 80,
        menu_items: { name: 'น้ำมะนาว' }
      },
      {
        quantity: 1,
        unit_price: 30,
        menu_items: { name: 'ข้าวเปล่า' }
      }
    ]
  });

  const sampleReceiptHTML = `
    <div class="receipt">
      <div class="header">
        <div class="shop-name">ร้านอาหารของเรา</div>
        <div>123 ถนนสุขุมวิท กรุงเทพฯ 10110</div>
        <div>โทร: 02-123-4567</div>
      </div>
      <div class="separator"></div>
      <div class="order-info">
        <div>ออเดอร์: ${previewContent.order_number}</div>
        <div>โต๊ะ: ${previewContent.tables.table_number}</div>
        <div>วันที่: ${new Date().toLocaleDateString('th-TH')}</div>
        <div>เวลา: ${new Date().toLocaleTimeString('th-TH')}</div>
      </div>
      <div class="separator"></div>
      <div class="items">
        ${previewContent.order_items.map(item => `
          <div class="item">
            <div class="item-name">${item.menu_items.name}</div>
            <div class="item-qty">${item.quantity}</div>
            <div class="item-price">${(item.quantity * item.unit_price).toFixed(2)}</div>
          </div>
        `).join('')}
      </div>
      <div class="separator"></div>
      <div class="total">
        <span>รวมทั้งสิ้น:</span>
        <span>฿${previewContent.total_amount.toFixed(2)}</span>
      </div>
      <div class="footer">
        <div>ขอบคุณที่ใช้บริการ</div>
        <div>โปรดเก็บใบเสร็จไว้</div>
      </div>
    </div>
  `;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <Printer className="h-6 w-6" />
          ระบบปริ้นเตอร์
        </h2>
        <Badge variant={status.connected ? "default" : "destructive"}>
          {status.connected ? (
            <><Wifi className="h-3 w-3 mr-1" />เชื่อมต่อแล้ว</>
          ) : (
            <><WifiOff className="h-3 w-3 mr-1" />ไม่ได้เชื่อมต่อ</>
          )}
        </Badge>
      </div>

      <Tabs defaultValue="printer" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="printer">เครื่องปริ้นเตอร์</TabsTrigger>
          <TabsTrigger value="preview">ตัวอย่างใบเสร็จ</TabsTrigger>
          <TabsTrigger value="settings">ตั้งค่า</TabsTrigger>
        </TabsList>

        <TabsContent value="printer" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-medium mb-4">ควบคุมเครื่องปริ้นเตอร์</h3>
              <EpsonPrintSystem order={previewContent} />
            </div>
            
            <div>
              <h3 className="text-lg font-medium mb-4">สถานะระบบ</h3>
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">ข้อมูลการเชื่อมต่อ</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="font-medium">รุ่น:</span>
                      <div>Epson TMT82</div>
                    </div>
                    <div>
                      <span className="font-medium">IP Address:</span>
                      <div className="font-mono">{status.ip}</div>
                    </div>
                    <div>
                      <span className="font-medium">Port:</span>
                      <div className="font-mono">{status.port}</div>
                    </div>
                    <div>
                      <span className="font-medium">สถานะ:</span>
                      <div className={status.connected ? 'text-green-600' : 'text-red-600'}>
                        {status.connected ? 'พร้อมใช้งาน' : 'ไม่พร้อมใช้งาน'}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="mt-4">
                <CardHeader>
                  <CardTitle className="text-sm">คำแนะนำการใช้งาน</CardTitle>
                </CardHeader>
                <CardContent className="text-sm space-y-2">
                  <div>• ตรวจสอบให้แน่ใจว่าเครื่องปริ้นเตอร์เปิดอยู่</div>
                  <div>• ตรวจสอบการเชื่อมต่อเครือข่าย WiFi</div>
                  <div>• ใช้กระดาษความร้อน ขนาด 80mm</div>
                  <div>• ทดสอบการปริ้นต์ก่อนใช้งานจริง</div>
                  <div>• หากมีปัญหา ให้รีสตาร์ทเครื่องปริ้นเตอร์</div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="preview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-medium mb-4">ตัวอย่างใบเสร็จ</h3>
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">เนื้อหาใบเสร็จ</CardTitle>
                </CardHeader>
                <CardContent>
                  <div 
                    id="receipt-preview"
                    className="border rounded-lg p-4 bg-white"
                    style={{ 
                      width: '80mm', 
                      fontFamily: 'Courier New, monospace',
                      fontSize: '12px',
                      lineHeight: '1.2'
                    }}
                    dangerouslySetInnerHTML={{ __html: sampleReceiptHTML }}
                  />
                </CardContent>
              </Card>
            </div>

            <div>
              <h3 className="text-lg font-medium mb-4">รายละเอียดข้อมูล</h3>
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">เช็คข้อมูลก่อนปริ้นต์</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>หมายเลขออเดอร์:</span>
                      <span className="font-mono">{previewContent.order_number}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>ประเภท:</span>
                      <span>{previewContent.order_type === 'dine-in' ? 'ทานที่ร้าน' : 'กลับบ้าน'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>โต๊ะ:</span>
                      <span>{previewContent.tables.table_number}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>จำนวนรายการ:</span>
                      <span>{previewContent.order_items.length} รายการ</span>
                    </div>
                    <div className="flex justify-between font-semibold">
                      <span>ยอดรวม:</span>
                      <span>฿{previewContent.total_amount.toFixed(2)}</span>
                    </div>
                  </div>

                  <div className="border-t pt-3">
                    <div className="text-sm font-medium mb-2">รายการอาหาร:</div>
                    <div className="space-y-1 text-xs">
                      {previewContent.order_items.map((item, index) => (
                        <div key={index} className="flex justify-between">
                          <span>{item.menu_items.name} x{item.quantity}</span>
                          <span>฿{(item.quantity * item.unit_price).toFixed(2)}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="border-t pt-3">
                    <div className="flex items-center gap-2 text-green-600">
                      <FileText className="h-4 w-4" />
                      <span className="text-sm">ข้อมูลครบถ้วน พร้อมปริ้นต์</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                การตั้งค่าเครื่องปริ้นเตอร์
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <h4 className="font-medium">การเชื่อมต่อ</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>IP Address:</span>
                      <span className="font-mono">192.168.1.127</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Port:</span>
                      <span className="font-mono">9100</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Protocol:</span>
                      <span>ESC/POS</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="font-medium">การตั้งค่ากระดาษ</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>ขนาดกระดาษ:</span>
                      <span>80mm</span>
                    </div>
                    <div className="flex justify-between">
                      <span>ประเภท:</span>
                      <span>Thermal Paper</span>
                    </div>
                    <div className="flex justify-between">
                      <span>การตัดกระดาษ:</span>
                      <span>อัตโนมัติ</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="border-t pt-4">
                <h4 className="font-medium mb-3">ข้อมูลร้าน</h4>
                <div className="space-y-2 text-sm bg-gray-50 p-3 rounded">
                  <div>ชื่อร้าน: ร้านอาหารของเรา</div>
                  <div>ที่อยู่: 123 ถนนสุขุมวิท กรุงเทพฯ 10110</div>
                  <div>โทรศัพท์: 02-123-4567</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default PrinterSystemPage;
