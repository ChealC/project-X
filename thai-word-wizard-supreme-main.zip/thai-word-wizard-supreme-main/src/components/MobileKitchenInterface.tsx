
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/integrations/supabase/client';
import { 
  ChefHat, 
  Clock, 
  CheckCircle, 
  Package,
  User
} from 'lucide-react';
import StockManagement from './StockManagement';
import StaffCheckIn from './StaffCheckIn';

const MobileKitchenInterface = () => {
  const { data: orders = [] } = useQuery({
    queryKey: ['kitchen-orders'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('orders')
        .select(`
          *,
          tables (table_number),
          order_items (
            id, quantity, unit_price, special_requests,
            menu_items (name, category, cooking_time)
          ),
          takeaway_orders (customer_name)
        `)
        .in('status', ['pending', 'preparing', 'ready'])
        .order('created_at', { ascending: true });

      if (error) throw error;
      return data || [];
    },
    refetchInterval: 2000
  });

  const updateOrderStatus = async (orderId: string, status: string) => {
    const { error } = await supabase
      .from('orders')
      .update({ status })
      .eq('id', orderId);

    if (!error) {
      window.location.reload();
    }
  };

  const pendingOrders = orders.filter(order => order.status === 'pending');
  const preparingOrders = orders.filter(order => order.status === 'preparing');
  const readyOrders = orders.filter(order => order.status === 'ready');

  return (
    <div className="min-h-screen bg-gray-50 p-2">
      <div className="max-w-md mx-auto space-y-4">
        <div className="bg-white rounded-lg p-4 shadow-sm">
          <h1 className="text-xl font-bold text-center text-red-600">
            ระบบครัว
          </h1>
        </div>

        <Tabs defaultValue="orders" className="w-full">
          <TabsList className="grid w-full grid-cols-3 h-12">
            <TabsTrigger value="orders" className="text-xs">
              <ChefHat className="h-4 w-4 mb-1" />
              <span>ออเดอร์</span>
            </TabsTrigger>
            <TabsTrigger value="stock" className="text-xs">
              <Package className="h-4 w-4 mb-1" />
              <span>สต็อค</span>
            </TabsTrigger>
            <TabsTrigger value="checkin" className="text-xs">
              <User className="h-4 w-4 mb-1" />
              <span>เช็คชื่อ</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="orders" className="space-y-4 mt-4">
            <div className="grid grid-cols-3 gap-2">
              <Card className="bg-red-50 border-red-200">
                <CardContent className="p-2 text-center">
                  <div className="text-xl font-bold text-red-600">
                    {pendingOrders.length}
                  </div>
                  <div className="text-xs text-red-600">รอทำ</div>
                </CardContent>
              </Card>
              <Card className="bg-yellow-50 border-yellow-200">
                <CardContent className="p-2 text-center">
                  <div className="text-xl font-bold text-yellow-600">
                    {preparingOrders.length}
                  </div>
                  <div className="text-xs text-yellow-600">กำลังทำ</div>
                </CardContent>
              </Card>
              <Card className="bg-green-50 border-green-200">
                <CardContent className="p-2 text-center">
                  <div className="text-xl font-bold text-green-600">
                    {readyOrders.length}
                  </div>
                  <div className="text-xs text-green-600">เสร็จแล้ว</div>
                </CardContent>
              </Card>
            </div>

            <ScrollArea className="h-[calc(100vh-280px)]">
              <div className="space-y-3">
                {/* Pending Orders */}
                {pendingOrders.map((order) => (
                  <Card key={order.id} className="border-red-200 bg-red-50">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm flex items-center justify-between">
                        <span>{order.order_number}</span>
                        <Badge variant="destructive">รอทำ</Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="text-xs">
                        ⏰ {new Date(order.created_at).toLocaleTimeString('th-TH')}
                      </div>
                      
                      <div className="text-xs">
                        <div className="font-medium">รายการ:</div>
                        {order.order_items?.map((item: any, index: number) => (
                          <div key={index} className="ml-2 space-y-1">
                            <div>• {item.menu_items.name} x{item.quantity}</div>
                            {item.special_requests && (
                              <div className="text-orange-600 ml-2">
                                📝 {item.special_requests}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>

                      <Button 
                        size="sm"
                        onClick={() => updateOrderStatus(order.id, 'preparing')}
                        className="w-full bg-yellow-500 hover:bg-yellow-600"
                      >
                        <Clock className="h-3 w-3 mr-1" />
                        เริ่มทำ
                      </Button>
                    </CardContent>
                  </Card>
                ))}

                {/* Preparing Orders */}
                {preparingOrders.map((order) => (
                  <Card key={order.id} className="border-yellow-200 bg-yellow-50">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm flex items-center justify-between">
                        <span>{order.order_number}</span>
                        <Badge className="bg-yellow-500">กำลังทำ</Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="text-xs">
                        ⏰ เริ่มทำ: {new Date(order.updated_at).toLocaleTimeString('th-TH')}
                      </div>
                      
                      <div className="text-xs">
                        <div className="font-medium">รายการ:</div>
                        {order.order_items?.map((item: any, index: number) => (
                          <div key={index} className="ml-2">
                            • {item.menu_items.name} x{item.quantity}
                          </div>
                        ))}
                      </div>

                      <Button 
                        size="sm"
                        onClick={() => updateOrderStatus(order.id, 'ready')}
                        className="w-full bg-green-500 hover:bg-green-600"
                      >
                        <CheckCircle className="h-3 w-3 mr-1" />
                        เสร็จแล้ว
                      </Button>
                    </CardContent>
                  </Card>
                ))}

                {/* Ready Orders */}
                {readyOrders.map((order) => (
                  <Card key={order.id} className="border-green-200 bg-green-50">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm flex items-center justify-between">
                        <span>{order.order_number}</span>
                        <Badge className="bg-green-500">พร้อมเสิร์ฟ</Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-xs">
                        ✅ เสร็จเมื่อ: {new Date(order.updated_at).toLocaleTimeString('th-TH')}
                      </div>
                    </CardContent>
                  </Card>
                ))}

                {orders.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    ไม่มีออเดอร์ในระบบ
                  </div>
                )}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="stock" className="mt-4">
            <StockManagement />
          </TabsContent>

          <TabsContent value="checkin" className="mt-4">
            <StaffCheckIn />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default MobileKitchenInterface;
