import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/integrations/supabase/client';
import { Shield, AlertTriangle, CheckCircle, Eye, Search, Lock, Key, Bot } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import SecurityBot from './SecurityBot';

const SecuritySystem = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterSeverity, setFilterSeverity] = useState<string>('');
  const [resolveNote, setResolveNote] = useState('');
  const [selectedAlert, setSelectedAlert] = useState<string>('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: securityAlerts } = useQuery({
    queryKey: ['security-alerts'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('security_alerts')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50);
      
      if (error) throw error;
      return data;
    }
  });

  const { data: activityLogs } = useQuery({
    queryKey: ['recent-activity'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('activity_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(20);
      
      if (error) throw error;
      return data;
    }
  });

  const resolveAlert = useMutation({
    mutationFn: async ({ alertId, note }: { alertId: string; note: string }) => {
      const { error } = await supabase
        .from('security_alerts')
        .update({
          is_resolved: true,
          resolved_at: new Date().toISOString(),
          metadata: { resolve_note: note }
        })
        .eq('id', alertId);

      if (error) throw error;
    },
    onSuccess: () => {
      setSelectedAlert('');
      setResolveNote('');
      queryClient.invalidateQueries({ queryKey: ['security-alerts'] });
      toast({
        title: "แจ้งเตือนความปลอดภัยได้รับการแก้ไข",
        description: "สถานะได้รับการอัปเดตแล้ว"
      });
    }
  });

  const getSeverityIcon = (severity: string): React.ReactNode => {
    switch (severity) {
      case 'high':
        return <AlertTriangle className="h-4 w-4 text-red-500" />;
      case 'medium':
        return <Eye className="h-4 w-4 text-yellow-500" />;
      case 'low':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      default:
        return <Shield className="h-4 w-4 text-gray-500" />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'bg-red-500 text-white';
      case 'medium': return 'bg-yellow-500 text-white';
      case 'low': return 'bg-green-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  const getAlertTypeText = (type: string) => {
    const typeMap: { [key: string]: string } = {
      'SUSPICIOUS_ACTIVITY': 'กิจกรรมน่าสงสัย',
      'FAILED_LOGIN': 'เข้าสู่ระบบล้มเหลว',
      'UNAUTHORIZED_ACCESS': 'เข้าถึงโดยไม่ได้รับอนุญาต',
      'DATA_BREACH': 'การละเมิดข้อมูล',
      'SYSTEM_ANOMALY': 'ความผิดปกติของระบบ',
      'SYSTEM_ERROR': 'ข้อผิดพลาดระบบ'
    };
    return typeMap[type] || type;
  };

  const filteredAlerts = securityAlerts?.filter(alert => {
    const matchesSearch = alert.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         alert.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSeverity = !filterSeverity || alert.severity === filterSeverity;
    return matchesSearch && matchesSeverity;
  });

  const unresolvedAlerts = filteredAlerts?.filter(alert => !alert.is_resolved) || [];
  const resolvedAlerts = filteredAlerts?.filter(alert => alert.is_resolved) || [];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            ระบบรักษาความปลอดภัย
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="overview">ภาพรวม</TabsTrigger>
              <TabsTrigger value="bot">Security Bot</TabsTrigger>
              <TabsTrigger value="alerts">แจ้งเตือน</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <AlertTriangle className="h-8 w-8 text-red-500" />
                      <div>
                        <p className="text-2xl font-bold">{unresolvedAlerts.length}</p>
                        <p className="text-sm text-gray-600">แจ้งเตือนที่ยังไม่แก้ไข</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-8 w-8 text-green-500" />
                      <div>
                        <p className="text-2xl font-bold">{resolvedAlerts.length}</p>
                        <p className="text-sm text-gray-600">แจ้งเตือนที่แก้ไขแล้ว</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <Lock className="h-8 w-8 text-blue-500" />
                      <div>
                        <p className="text-2xl font-bold">{activityLogs?.length || 0}</p>
                        <p className="text-sm text-gray-600">กิจกรรมการเข้าถึง</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <Bot className="h-8 w-8 text-purple-500" />
                      <div>
                        <p className="text-2xl font-bold">1</p>
                        <p className="text-sm text-gray-600">Security Bot</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* System Status */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="bg-green-50 border-green-200">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <Shield className="h-6 w-6 text-green-600" />
                      <div>
                        <h3 className="font-semibold text-green-800">ระบบรักษาความปลอดภัย</h3>
                        <p className="text-sm text-green-600">ทำงานปกติ</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-blue-50 border-blue-200">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <Lock className="h-6 w-6 text-blue-600" />
                      <div>
                        <h3 className="font-semibold text-blue-800">การควบคุมการเข้าถึง</h3>
                        <p className="text-sm text-blue-600">เปิดใช้งาน</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-purple-50 border-purple-200">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <Bot className="h-6 w-6 text-purple-600" />
                      <div>
                        <h3 className="font-semibold text-purple-800">Security Bot</h3>
                        <p className="text-sm text-purple-600">ทำงานปกติ</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="bot">
              <SecurityBot />
            </TabsContent>

            <TabsContent value="alerts" className="space-y-6">
              {/* Search and Filter */}
              <div className="flex gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="ค้นหาแจ้งเตือนความปลอดภัย..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <select
                  value={filterSeverity}
                  onChange={(e) => setFilterSeverity(e.target.value)}
                  className="px-3 py-2 border rounded-md"
                >
                  <option value="">ทุกระดับความเสี่ยง</option>
                  <option value="high">สูง</option>
                  <option value="medium">กลาง</option>
                  <option value="low">ต่ำ</option>
                </select>
              </div>

              {/* Unresolved Alerts */}
              {unresolvedAlerts.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold mb-3 text-red-600">แจ้งเตือนความปลอดภัยที่ต้องแก้ไข</h3>
                  <div className="space-y-3">
                    {unresolvedAlerts.map((alert) => (
                      <Alert key={alert.id} className="border-red-200">
                        <div className="flex items-start justify-between">
                          <div className="flex items-start gap-3">
                            {getSeverityIcon(alert.severity)}
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <h4 className="font-semibold">{alert.title}</h4>
                                <Badge className={getSeverityColor(alert.severity)}>
                                  {alert.severity === 'high' ? 'สูง' : 
                                   alert.severity === 'medium' ? 'กลาง' : 'ต่ำ'}
                                </Badge>
                                <Badge variant="outline">
                                  {getAlertTypeText(alert.alert_type)}
                                </Badge>
                              </div>
                              <AlertDescription>
                                {alert.description}
                              </AlertDescription>
                              <p className="text-xs text-gray-500 mt-2">
                                {new Date(alert.created_at).toLocaleString('th-TH')}
                              </p>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            {selectedAlert === alert.id ? (
                              <div className="flex gap-2 items-center">
                                <Input
                                  placeholder="หมายเหตุการแก้ไข..."
                                  value={resolveNote}
                                  onChange={(e) => setResolveNote(e.target.value)}
                                  className="w-40"
                                />
                                <Button
                                  size="sm"
                                  onClick={() => resolveAlert.mutate({ 
                                    alertId: alert.id, 
                                    note: resolveNote 
                                  })}
                                  disabled={resolveAlert.isPending}
                                >
                                  แก้ไข
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => setSelectedAlert('')}
                                >
                                  ยกเลิก
                                </Button>
                              </div>
                            ) : (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => setSelectedAlert(alert.id)}
                              >
                                แก้ไข
                              </Button>
                            )}
                          </div>
                        </div>
                      </Alert>
                    ))}
                  </div>
                </div>
              )}

              {(!securityAlerts || securityAlerts.length === 0) && (
                <div className="text-center py-8">
                  <Shield className="h-12 w-12 mx-auto mb-4 text-green-500" />
                  <p className="text-gray-600">ระบบปลอดภัย - ไม่มีแจ้งเตือน</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default SecuritySystem;
