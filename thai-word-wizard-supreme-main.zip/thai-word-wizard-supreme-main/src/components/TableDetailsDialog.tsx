
import { useQuery } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { Tables } from '@/integrations/supabase/types';
import { Users, Clock, DollarSign, FileText } from 'lucide-react';

interface TableDetailsDialogProps {
  table: Tables<'tables'>;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const TableDetailsDialog = ({ table, open, onOpenChange }: TableDetailsDialogProps) => {
  // Get current order for this table
  const { data: currentOrder } = useQuery({
    queryKey: ['table-current-order', table.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('orders')
        .select(`
          *,
          order_items(
            *,
            menu_items(name, price)
          )
        `)
        .eq('table_id', table.id)
        .in('status', ['pending', 'preparing', 'ready', 'served'])
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      
      if (error) throw error;
      return data;
    },
    enabled: open && table.status === 'occupied'
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return 'bg-green-500 text-white';
      case 'occupied': return 'bg-red-500 text-white';
      case 'reserved': return 'bg-yellow-500 text-white';
      case 'cleaning': return 'bg-blue-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'available': return 'ว่าง';
      case 'occupied': return 'มีลูกค้า';
      case 'reserved': return 'จอง';
      case 'cleaning': return 'ทำความสะอาด';
      default: return status;
    }
  };

  const getOrderStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'รอดำเนินการ';
      case 'preparing': return 'กำลังเตรียม';
      case 'ready': return 'พร้อมเสิร์ฟ';
      case 'served': return 'เสิร์ฟแล้ว';
      default: return status;
    }
  };

  const getOrderStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-500 text-white';
      case 'preparing': return 'bg-blue-500 text-white';
      case 'ready': return 'bg-green-500 text-white';
      case 'served': return 'bg-purple-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>รายละเอียดโต๊ะ {table.table_number}</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Table Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">ข้อมูลโต๊ะ</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="font-medium">หมายเลขโต๊ะ:</span>
                <span className="text-2xl font-bold">โต๊ะ {table.table_number}</span>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="font-medium">จำนวนที่นั่ง:</span>
                <div className="flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  <span>{table.seats} ที่นั่ง</span>
                </div>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="font-medium">สถานะ:</span>
                <Badge className={getStatusColor(table.status)}>
                  {getStatusText(table.status)}
                </Badge>
              </div>
            </CardContent>
          </Card>

          {/* Current Order Information */}
          {table.status === 'occupied' && currentOrder && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  ออเดอร์ปัจจุบัน
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="font-medium">หมายเลขออเดอร์:</span>
                  <span className="font-mono text-sm bg-gray-100 px-2 py-1 rounded">
                    {currentOrder.order_number}
                  </span>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="font-medium">สถานะออเดอร์:</span>
                  <Badge className={getOrderStatusColor(currentOrder.status)}>
                    {getOrderStatusText(currentOrder.status)}
                  </Badge>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="font-medium">จำนวนลูกค้า:</span>
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    <span>{currentOrder.customer_count} คน</span>
                  </div>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="font-medium">เวลาสั่ง:</span>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    <span>{new Date(currentOrder.created_at).toLocaleString('th-TH')}</span>
                  </div>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="font-medium">ยอดรวม:</span>
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-4 w-4" />
                    <span className="text-xl font-bold text-green-600">
                      ฿{currentOrder.total_amount?.toLocaleString()}
                    </span>
                  </div>
                </div>

                {/* Order Items */}
                {currentOrder.order_items && currentOrder.order_items.length > 0 && (
                  <div>
                    <h4 className="font-medium mb-2">รายการอาหาร:</h4>
                    <div className="space-y-2">
                      {currentOrder.order_items.map((item) => (
                        <div key={item.id} className="flex justify-between items-center py-2 border-b border-gray-100 last:border-b-0">
                          <div>
                            <span className="font-medium">{item.menu_items?.name}</span>
                            <span className="text-gray-500 ml-2">x{item.quantity}</span>
                          </div>
                          <span className="font-medium">฿{item.total_price}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Order Notes */}
                {currentOrder.notes && (
                  <div>
                    <span className="font-medium">หมายเหตุ:</span>
                    <p className="text-gray-600 mt-1">{currentOrder.notes}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {table.status === 'occupied' && !currentOrder && (
            <Card>
              <CardContent className="p-6 text-center text-gray-500">
                ไม่พบข้อมูลออเดอร์สำหรับโต๊ะนี้
              </CardContent>
            </Card>
          )}

          {table.status !== 'occupied' && (
            <Card>
              <CardContent className="p-6 text-center text-gray-500">
                โต๊ะนี้ไม่มีลูกค้าในขณะนี้
              </CardContent>
            </Card>
          )}

          <div className="flex justify-end">
            <Button onClick={() => onOpenChange(false)}>
              ปิด
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default TableDetailsDialog;
