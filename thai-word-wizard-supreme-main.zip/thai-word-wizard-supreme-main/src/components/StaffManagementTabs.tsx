
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import StaffManagementFull from './StaffManagementFull';
import StaffCredentialsDisplay from './StaffCredentialsDisplay';
import { Users, Eye } from 'lucide-react';

const StaffManagementTabs = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Users className="h-6 w-6" />
        <h2 className="text-2xl font-bold">จัดการพนักงาน</h2>
      </div>

      <Tabs defaultValue="management" className="space-y-4">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="management" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            จัดการข้อมูลพนักงาน
          </TabsTrigger>
          <TabsTrigger value="credentials" className="flex items-center gap-2">
            <Eye className="h-4 w-4" />
            ข้อมูลการเข้าสู่ระบบ
          </TabsTrigger>
        </TabsList>

        <TabsContent value="management">
          <StaffManagementFull />
        </TabsContent>

        <TabsContent value="credentials">
          <StaffCredentialsDisplay />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default StaffManagementTabs;
