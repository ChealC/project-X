import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { UserPlus, Key, Database, Trash2, Users, Check } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Badge } from '@/components/ui/badge';

type StaffRole = 'admin' | 'manager' | 'kitchen_staff' | 'service_staff';

const QuickAuthFix = () => {
  const [isDeleting, setIsDeleting] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [userAccounts, setUserAccounts] = useState<any[]>([]);
  const [showUserList, setShowUserList] = useState(false);
  const { toast } = useToast();

  // Hash function to match AuthContext
  const hashPassword = (password: string): string => {
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const binaryString = String.fromCharCode(...data);
    return btoa(binaryString);
  };

  // ฟังก์ชันลบข้อมูลทั้งหมด
  const deleteAllData = async () => {
    setIsDeleting(true);
    
    try {
      console.log('=== เริ่มลบข้อมูลทั้งหมด ===');
      
      // Step 1: ลบ payments ก่อน
      console.log('ขั้นตอนที่ 1: ลบ payments ทั้งหมด...');
      const { error: paymentsError } = await supabase
        .from('payments')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000');
      
      if (paymentsError) {
        console.error('Payments delete error:', paymentsError);
      } else {
        console.log('✓ ลบ payments แล้ว');
      }

      // Step 2: ลบ order_items
      console.log('ขั้นตอนที่ 2: ลบ order_items ทั้งหมด...');
      const { error: orderItemsError } = await supabase
        .from('order_items')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000');
      
      if (orderItemsError) {
        console.error('Order items delete error:', orderItemsError);
      } else {
        console.log('✓ ลบ order_items แล้ว');
      }

      // Step 3: ลบ orders
      console.log('ขั้นตอนที่ 3: ลบ orders ทั้งหมด...');
      const { error: ordersError } = await supabase
        .from('orders')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000');
      
      if (ordersError) {
        console.error('Orders delete error:', ordersError);
      } else {
        console.log('✓ ลบ orders แล้ว');
      }

      // Step 4: ลบ kitchen_tasks
      console.log('ขั้นตอนที่ 4: ลบ kitchen_tasks ทั้งหมด...');
      const { error: kitchenTasksError } = await supabase
        .from('kitchen_tasks')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000');
      
      if (kitchenTasksError) {
        console.error('Kitchen tasks delete error:', kitchenTasksError);
      } else {
        console.log('✓ ลบ kitchen_tasks แล้ว');
      }

      // Step 5: ลบ staff_shifts
      console.log('ขั้นตอนที่ 5: ลบ staff_shifts ทั้งหมด...');
      const { error: shiftsError } = await supabase
        .from('staff_shifts')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000');
      
      if (shiftsError) {
        console.error('Staff shifts delete error:', shiftsError);
      } else {
        console.log('✓ ลบ staff_shifts แล้ว');
      }

      // Step 6: ลบ cash_drawer_transactions
      console.log('ขั้นตอนที่ 6: ลบ cash_drawer_transactions ทั้งหมด...');
      const { error: cashTransError } = await supabase
        .from('cash_drawer_transactions')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000');
      
      if (cashTransError) {
        console.error('Cash drawer transactions delete error:', cashTransError);
      } else {
        console.log('✓ ลบ cash_drawer_transactions แล้ว');
      }

      // Step 7: ลบ cash_drawer_shifts
      console.log('ขั้นตอนที่ 7: ลบ cash_drawer_shifts ทั้งหมด...');
      const { error: cashShiftsError } = await supabase
        .from('cash_drawer_shifts')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000');
      
      if (cashShiftsError) {
        console.error('Cash drawer shifts delete error:', cashShiftsError);
      } else {
        console.log('✓ ลบ cash_drawer_shifts แล้ว');
      }

      // Step 8: ลบ activity_logs
      console.log('ขั้นตอนที่ 8: ลบ activity_logs ทั้งหมด...');
      const { error: activityError } = await supabase
        .from('activity_logs')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000');
      
      if (activityError) {
        console.error('Activity logs delete error:', activityError);
      } else {
        console.log('✓ ลบ activity_logs แล้ว');
      }

      // Step 9: ลบ user accounts
      console.log('ขั้นตอนที่ 9: ลบ user accounts ทั้งหมด...');
      const { error: userError } = await supabase
        .from('user_accounts')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000');
      
      if (userError) {
        console.error('User accounts delete error:', userError);
      } else {
        console.log('✓ ลบ user accounts แล้ว');
      }

      // Step 10: ลบ staff สุดท้าย
      console.log('ขั้นตอนที่ 10: ลบ staff ทั้งหมด...');
      const { error: staffError } = await supabase
        .from('staff')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000');
      
      if (staffError) {
        console.error('Staff delete error:', staffError);
      } else {
        console.log('✓ ลบ staff แล้ว');
      }

      console.log('=== ลบข้อมูลทั้งหมดเสร็จสิ้น ===');
      
      toast({
        title: "ลบข้อมูลทั้งหมดสำเร็จ! 🗑️",
        description: "ลบข้อมูลพนักงานและบัญชีผู้ใช้ทั้งหมดเรียบร้อยแล้ว พร้อมเริ่มต้นใหม่"
      });

      setUserAccounts([]);
      setShowUserList(false);

    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "เกิดข้อผิดพลาด",
        description: `ไม่สามารถลบข้อมูลได้: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive"
      });
    } finally {
      setIsDeleting(false);
    }
  };

  // Staff data for creating new system
  const staffData = [
    // Admin
    { name: 'ผู้ดูแลระบบ', position: 'ผู้ดูแลระบบ', role: 'admin' as StaffRole, username: 'admin', password: 'admin123', isAdmin: true },
    
    // Manager
    { name: 'สมรน แก้วใส', position: 'ผู้จัดการ', role: 'manager' as StaffRole, username: 'manager_samorn', password: 'manager123' },
    
    // Service Staff (8 people)
    { name: 'สราวุธ บุญมี', position: 'หัวหน้าแผนกบริการ', role: 'service_staff' as StaffRole, username: 'service_sarawut', password: 'service123' },
    { name: 'ชลดา แสงตานี', position: 'พนักงานบริการ', role: 'service_staff' as StaffRole, username: 'service_chalada', password: 'service123' },
    { name: 'ปฏิมา ทองศรีจันทร์', position: 'แคชเชียร์', role: 'service_staff' as StaffRole, username: 'cashier_patima', password: 'service123' },
    { name: 'วิชญา นาคสวัสดิ์', position: 'พนักงานบริการ', role: 'service_staff' as StaffRole, username: 'service_wichaya', password: 'service123' },
    { name: 'สุชาติ วังใน', position: 'พนักงานบริการ', role: 'service_staff' as StaffRole, username: 'service_suchat', password: 'service123' },
    { name: 'นริศรา คำดี', position: 'พนักงานบริการ', role: 'service_staff' as StaffRole, username: 'service_narisara', password: 'service123' },
    { name: 'ธีรพงษ์ สุขสมบูรณ์', position: 'พนักงานบริการ', role: 'service_staff' as StaffRole, username: 'service_teerapong', password: 'service123' },
    { name: 'มนทิรา เพ็ชรเลิศ', position: 'พนักงานบริการ', role: 'service_staff' as StaffRole, username: 'service_montira', password: 'service123' },
    
    // Kitchen Staff (8 people)
    { name: 'ธนพล เหลือผล', position: 'หัวหน้าแผนกครัว', role: 'kitchen_staff' as StaffRole, username: 'chef_thanapol', password: 'kitchen123' },
    { name: 'ศักดิ์สยาม กองสุนทร์', position: 'พนักงานครัว', role: 'kitchen_staff' as StaffRole, username: 'kitchen_saksiam', password: 'kitchen123' },
    { name: 'สมพร หรดี', position: 'พนักงานครัว', role: 'kitchen_staff' as StaffRole, username: 'kitchen_somporn', password: 'kitchen123' },
    { name: 'สมุทรสาคร วุฒิยากรณ์', position: 'พนักงานครัว', role: 'kitchen_staff' as StaffRole, username: 'kitchen_samut', password: 'kitchen123' },
    { name: 'รณกร แก้วชาติ', position: 'พนักงานครัว', role: 'kitchen_staff' as StaffRole, username: 'kitchen_ranakorn', password: 'kitchen123' },
    { name: 'สุทธิชัย พรมมา', position: 'พนักงานครัว', role: 'kitchen_staff' as StaffRole, username: 'kitchen_suttichai', password: 'kitchen123' },
    { name: 'ประยูร ใจดี', position: 'พนักงานครัว', role: 'kitchen_staff' as StaffRole, username: 'kitchen_prayoon', password: 'kitchen123' },
    { name: 'สนิท มาลี', position: 'พนักงานครัว', role: 'kitchen_staff' as StaffRole, username: 'kitchen_sanit', password: 'kitchen123' },
  ];

  const createNewStaffSystem = async () => {
    setIsCreating(true);
    
    try {
      console.log('=== เริ่มสร้างระบบพนักงานใหม่ ===');
      
      let successCount = 0;
      const createdAccounts: any[] = [];
      
      for (let i = 0; i < staffData.length; i++) {
        const staff = staffData[i];
        const employeeId = staff.isAdmin ? 'ADMIN-001' : `EMP-${staff.role === 'manager' ? 'MGR' : staff.role === 'kitchen_staff' ? 'KIT' : 'SRV'}-${String(i).padStart(3, '0')}`;
        
        console.log(`สร้าง ${staff.name} รหัสพนักงาน: ${employeeId}`);
        
        try {
          if (!staff.isAdmin) {
            // สร้าง staff record ก่อน (remove created_at and updated_at)
            const staffRecord = {
              name: staff.name,
              position: staff.position,
              employee_id: employeeId,
              hourly_rate: 50,
              is_active: true
            };

            const { data: staffInserted, error: staffError } = await supabase
              .from('staff')
              .insert(staffRecord)
              .select('id')
              .single();

            if (staffError) {
              console.error(`Staff insert error for ${staff.name}:`, staffError);
              continue;
            }

            console.log(`✓ สร้าง staff record: ${staff.name}`);

            // สร้าง user account พร้อม staff_id (remove created_at and updated_at)
            const userAccount = {
              staff_id: staffInserted.id,
              username: staff.username,
              password_hash: hashPassword(staff.password),
              role: staff.role,
              is_active: true
            };

            const { data: userInserted, error: userError } = await supabase
              .from('user_accounts')
              .insert(userAccount)
              .select('*')
              .single();

            if (userError) {
              console.error(`User account insert error for ${staff.name}:`, userError);
              continue;
            }

            console.log(`✓ สร้าง user account: ${staff.username}`);

            createdAccounts.push({
              ...userInserted,
              staff: staffRecord,
              password: staff.password
            });
          } else {
            // สร้าง admin account โดยไม่มี staff_id (remove created_at and updated_at)
            const adminAccount = {
              username: staff.username,
              password_hash: hashPassword(staff.password),
              role: staff.role,
              is_active: true
            };

            const { data: adminInserted, error: adminError } = await supabase
              .from('user_accounts')
              .insert(adminAccount)
              .select('*')
              .single();

            if (adminError) {
              console.error(`Admin account insert error:`, adminError);
              continue;
            }

            console.log(`✓ สร้าง admin account: ${staff.username}`);

            createdAccounts.push({
              ...adminInserted,
              staff: { name: staff.name, position: staff.position },
              password: staff.password
            });
          }

          successCount++;
          console.log(`✓ สร้างสำเร็จ: ${staff.name} - ${staff.username}`);
          
        } catch (error) {
          console.error(`❌ ไม่สามารถสร้าง ${staff.name}:`, error);
        }
      }

      console.log(`\n=== เสร็จสิ้น: สร้างบัญชี ${successCount}/${staffData.length} บัญชี ===`);
      
      setUserAccounts(createdAccounts);
      setShowUserList(true);
      
      toast({
        title: "สร้างระบบพนักงานใหม่สำเร็จ! 🎉",
        description: `สร้างพนักงานและบัญชี ${successCount} คน พร้อมใช้งานทันที!`
      });

    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "เกิดข้อผิดพลาด",
        description: `ไม่สามารถสร้างระบบใหม่ได้: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive"
      });
    } finally {
      setIsCreating(false);
    }
  };

  const getRoleLabel = (role: string) => {
    switch (role) {
      case 'admin': return 'ผู้ดูแลระบบ';
      case 'manager': return 'ผู้จัดการ';
      case 'kitchen_staff': return 'พนักงานครัว';
      case 'service_staff': return 'พนักงานบริการ';
      default: return role;
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'admin': return 'bg-red-500';
      case 'manager': return 'bg-blue-500';
      case 'kitchen_staff': return 'bg-green-500';
      case 'service_staff': return 'bg-orange-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="space-y-6">
      <Card className="w-full max-w-md mx-auto">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-red-600">
            <Database className="w-5 h-5" />
            เริ่มต้นระบบพนักงานใหม่
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          
          {/* ปุ่มลบข้อมูลทั้งหมด */}
          <Button 
            onClick={deleteAllData}
            disabled={isDeleting || isCreating}
            className="w-full bg-red-600 hover:bg-red-700 text-white"
            size="lg"
          >
            <Trash2 className="w-4 h-4 mr-2" />
            {isDeleting ? 'กำลังลบข้อมูลทั้งหมด...' : 'ลบข้อมูลพนักงานและบัญชีทั้งหมด'}
          </Button>

          <div className="border-t pt-4">
            <p className="text-sm text-gray-600 mb-4">
              สร้างระบบพนักงานใหม่ทั้งหมด
            </p>
            
            <Button 
              onClick={createNewStaffSystem}
              disabled={isCreating || isDeleting}
              className="w-full bg-green-500 hover:bg-green-600 text-white"
              size="lg"
            >
              <Users className="w-4 h-4 mr-2" />
              {isCreating ? 'กำลังสร้างระบบใหม่...' : 'สร้างระบบพนักงานใหม่ (18 คน)'}
            </Button>
          </div>

          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <h3 className="font-semibold text-green-800 mb-2">🚀 ระบบพนักงานใหม่ (18 คน):</h3>
            <div className="text-sm text-green-700 space-y-1">
              <div><strong>Admin (1):</strong> <code>admin / admin123</code></div>
              <div><strong>Manager (1):</strong> <code>manager_samorn / manager123</code></div>
              <div><strong>Service (8):</strong> <code>service_sarawut, cashier_patima, etc. / service123</code></div>
              <div><strong>Kitchen (8):</strong> <code>chef_thanapol, kitchen_saksiam, etc. / kitchen123</code></div>
            </div>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h3 className="font-semibold text-blue-800 mb-2">⚡ วิธีใช้งาน:</h3>
            <div className="text-sm text-blue-700 space-y-1">
              <p>1. กดปุ่มแดงเพื่อลบข้อมูลเก่าทั้งหมด</p>
              <p>2. กดปุ่มเขียวเพื่อสร้างระบบพนักงานใหม่</p>
              <p>3. รอจนกว่าจะแสดง "สำเร็จ"</p>
              <p>4. ใช้บัญชีที่แสดงในตารางเพื่อเข้าสู่ระบบ</p>
            </div>
          </div>

          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
            <p className="text-xs text-yellow-700">
              <strong>⚠️ คำเตือน:</strong> การดำเนินการนี้จะลบข้อมูลเก่าทั้งหมดและไม่สามารถกู้คืนได้
            </p>
          </div>
        </CardContent>
      </Card>

      {/* รายการบัญชีผู้ใช้ที่สร้างแล้ว */}
      {showUserList && userAccounts.length > 0 && (
        <Card className="w-full">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-600">
              <Check className="w-5 h-5" />
              รายการบัญชีผู้ใช้ที่สร้างแล้ว ({userAccounts.length} บัญชี)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ชื่อผู้ใช้</TableHead>
                  <TableHead>รหัสผ่าน</TableHead>
                  <TableHead>ชื่อ</TableHead>
                  <TableHead>ตำแหน่ง</TableHead>
                  <TableHead>บทบาท</TableHead>
                  <TableHead>สถานะ</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {userAccounts.map((account, index) => (
                  <TableRow key={index}>
                    <TableCell className="font-mono">{account.username}</TableCell>
                    <TableCell className="font-mono">{account.password}</TableCell>
                    <TableCell>{account.staff?.name || 'ผู้ดูแลระบบ'}</TableCell>
                    <TableCell>{account.staff?.position || 'ระบบ'}</TableCell>
                    <TableCell>
                      <Badge className={`${getRoleColor(account.role)} text-white`}>
                        {getRoleLabel(account.role)}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant="default" className="bg-green-500">
                        ใช้งานได้
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default QuickAuthFix;
