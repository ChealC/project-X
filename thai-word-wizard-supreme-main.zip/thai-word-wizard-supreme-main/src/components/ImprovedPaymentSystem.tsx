

import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase } from '@/integrations/supabase/client';
import { CreditCard, Banknote, Smartphone, Receipt, AlertTriangle, Lock, CheckCircle, X, Eye } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import PrintButton from './PrintButton';
import QRPaymentDialog from './QRPaymentDialog';

interface PaymentDialogProps {
  order: any;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  embedded?: boolean;
  onPaymentComplete?: () => void;
}

const ImprovedPaymentSystem = ({ order, open, onOpenChange, embedded = false, onPaymentComplete }: PaymentDialogProps) => {
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'credit_card' | 'qr_code'>('qr_code');
  const [receivedAmount, setReceivedAmount] = useState<string>('');
  const [creditCardNumber, setCreditCardNumber] = useState('');
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showQRDialog, setShowQRDialog] = useState(false);
  const [pendingQRPayment, setPendingQRPayment] = useState<any>(null);
  const [showSlipPreview, setShowSlipPreview] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  // Check if user can handle cash payments (only admin and manager)
  const canHandleCash = user?.role === 'admin' || user?.role === 'manager';
  const canApprovePayments = user?.role === 'admin' || user?.role === 'manager';

  // Check for pending QR payment for this order
  useEffect(() => {
    if (order?.id && open) {
      const pendingPayments = JSON.parse(localStorage.getItem('pendingQRPayments') || '{}');
      const orderPendingPayment = pendingPayments[order.id];
      if (orderPendingPayment && orderPendingPayment.status === 'slip_uploaded') {
        setPendingQRPayment(orderPendingPayment);
      } else {
        setPendingQRPayment(null);
      }
    }
  }, [order?.id, open]);

  // Check for current open cash drawer shift (only for users who can handle cash)
  const { data: currentShift } = useQuery({
    queryKey: ['current-cash-shift'],
    queryFn: async () => {
      if (!user?.staff_id || !canHandleCash) return null;
      
      const { data, error } = await supabase
        .from('cash_drawer_shifts')
        .select('*')
        .eq('status', 'open')
        .eq('shift_date', new Date().toISOString().split('T')[0])
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching current shift:', error);
        return null;
      }

      return data;
    },
    enabled: !!user?.staff_id && canHandleCash && open
  });

  useEffect(() => {
    if (open && order?.total_amount) {
      setReceivedAmount(order.total_amount.toString());
      // Default to QR Code for non-admin/manager users
      if (!canHandleCash) {
        setPaymentMethod('qr_code');
      }
    }
  }, [open, order?.total_amount, canHandleCash]);

  const processPayment = useMutation({
    mutationFn: async () => {
      if (!order) throw new Error('ไม่พบข้อมูลออเดอร์');
      
      setIsProcessing(true);
      console.log('Processing payment for order:', order.id);

      const amount = order.total_amount;
      const received = parseFloat(receivedAmount) || 0;

      // Restrict cash payments to admin/manager only
      if (paymentMethod === 'cash' && !canHandleCash) {
        throw new Error('คุณไม่มีสิทธิ์รับชำระเงินสด กรุณาใช้วิธีการชำระเงินอื่น');
      }

      if (paymentMethod === 'cash' && received < amount) {
        throw new Error('จำนวนเงินที่รับไม่เพียงพอ');
      }

      if (paymentMethod === 'cash' && !currentShift) {
        throw new Error('ไม่พบกะลิ้นชักเงินสดที่เปิดอยู่ กรุณาเปิดกะก่อน');
      }

      if (paymentMethod === 'credit_card' && !creditCardNumber.trim()) {
        throw new Error('กรุณาใส่หมายเลขบัตรเครดิต');
      }

      const changeAmount = paymentMethod === 'cash' ? Math.max(0, received - amount) : 0;

      try {
        // บันทึกการชำระเงิน
        const { error: paymentError } = await supabase
          .from('payments')
          .insert({
            order_id: order.id,
            amount,
            payment_method: paymentMethod,
            received_amount: paymentMethod === 'cash' ? received : amount,
            change_amount: changeAmount,
            reference_number: paymentMethod === 'credit_card' ? creditCardNumber : null,
            staff_id: user?.staff_id
          });

        if (paymentError) {
          console.error('Payment error:', paymentError);
          throw new Error(`ไม่สามารถบันทึกการชำระเงินได้: ${paymentError.message}`);
        }

        console.log('Payment recorded successfully');

        // บันทึกรายการในลิ้นชักเงินสด (เฉพาะการชำระด้วยเงินสด)
        if (paymentMethod === 'cash' && currentShift && user?.staff_id) {
          console.log('Recording cash transaction to drawer');
          
          const { error: cashTransactionError } = await supabase
            .from('cash_drawer_transactions')
            .insert({
              shift_id: currentShift.id,
              transaction_type: 'sale',
              amount: amount,
              description: `ขาย - ออเดอร์ ${order.order_number}`,
              reference_id: order.id,
              staff_id: user.staff_id
            });

          if (cashTransactionError) {
            console.error('Error recording cash transaction:', cashTransactionError);
          } else {
            console.log('Cash transaction recorded successfully');
          }
        }

        // อัพเดทสถานะออเดอร์
        const { error: orderError } = await supabase
          .from('orders')
          .update({ status: 'completed' })
          .eq('id', order.id);

        if (orderError) {
          console.error('Order update error:', orderError);
          throw new Error(`ไม่สามารถอัพเดทสถานะออเดอร์ได้: ${orderError.message}`);
        }

        console.log('Order status updated successfully');

        // อัพเดทสถานะโต๊ะ (ถ้าเป็น dine-in)
        if (order.order_type === 'dine-in' && order.table_id) {
          const { error: tableError } = await supabase
            .from('tables')
            .update({ status: 'cleaning' })
            .eq('id', order.table_id);

          if (tableError) {
            console.error('Table update error:', tableError);
          } else {
            console.log('Table status updated successfully');
          }
        }

        return { changeAmount };
      } catch (error) {
        console.error('Payment processing error:', error);
        throw error;
      } finally {
        setIsProcessing(false);
      }
    },
    onSuccess: (data) => {
      console.log('Payment completed successfully');
      toast({
        title: "ชำระเงินสำเร็จ",
        description: paymentMethod === 'cash' && data.changeAmount > 0 
          ? `เงินทอน: ฿${data.changeAmount.toFixed(2)}`
          : "บันทึกการชำระเงินเรียบร้อย"
      });
      
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      queryClient.invalidateQueries({ queryKey: ['orders-ready-for-payment'] });
      queryClient.invalidateQueries({ queryKey: ['table-order'] });
      queryClient.invalidateQueries({ queryKey: ['tables'] });
      queryClient.invalidateQueries({ queryKey: ['current-cash-shift'] });
      onOpenChange(false);
      
      // Call the optional onPaymentComplete callback
      if (onPaymentComplete) {
        onPaymentComplete();
      }
      
      // รีเซ็ตฟอร์ม
      setPaymentMethod(canHandleCash ? 'cash' : 'qr_code');
      setReceivedAmount('');
      setCreditCardNumber('');
      setValidationErrors([]);
    },
    onError: (error: any) => {
      console.error('Payment error:', error);
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error.message || "ไม่สามารถชำระเงินได้",
        variant: "destructive"
      });
      setIsProcessing(false);
    }
  });

  const handleApproveQRPayment = () => {
    if (pendingQRPayment) {
      // Remove from localStorage
      const pendingPayments = JSON.parse(localStorage.getItem('pendingQRPayments') || '{}');
      delete pendingPayments[order.id];
      localStorage.setItem('pendingQRPayments', JSON.stringify(pendingPayments));
      
      // Process payment as QR code
      setPaymentMethod('qr_code');
      processPayment.mutate();
    }
  };

  const handleRejectQRPayment = () => {
    if (pendingQRPayment) {
      // Remove from localStorage
      const pendingPayments = JSON.parse(localStorage.getItem('pendingQRPayments') || '{}');
      delete pendingPayments[order.id];
      localStorage.setItem('pendingQRPayments', JSON.stringify(pendingPayments));
      
      setPendingQRPayment(null);
      toast({
        title: "ปฏิเสธการชำระเงิน",
        description: "สลิปไม่ถูกต้อง กรุณาลองใหม่",
        variant: "destructive"
      });
    }
  };

  const calculateChange = () => {
    if (paymentMethod !== 'cash') return 0;
    const received = parseFloat(receivedAmount) || 0;
    const total = order?.total_amount || 0;
    return Math.max(0, received - total);
  };

  const canProcess = () => {
    if (isProcessing) return false;
    
    // สำหรับเงินสด
    if (paymentMethod === 'cash') {
      if (!canHandleCash) return false;
      if (!currentShift) return false;
      const received = parseFloat(receivedAmount) || 0;
      return received >= (order?.total_amount || 0);
    }
    
    if (paymentMethod === 'credit_card') {
      return creditCardNumber.trim().length > 0;
    }
    if (paymentMethod === 'qr_code') {
      return true;
    }
    return false;
  };

  const handleQRPayment = () => {
    setShowQRDialog(true);
  };

  const handleQRPaymentComplete = () => {
    // อัพเดทสถานะออเดอร์เป็น completed หลังจากได้รับการยืนยัน
    processPayment.mutate();
    setShowQRDialog(false);
  };

  if (!order) return null;

  // If embedded is true, don't wrap in Dialog
  const content = (
    <div className="space-y-4">
      {/* แสดงข้อมูลสลิปที่รอยืนยัน */}
      {pendingQRPayment && canApprovePayments && (
        <Alert className="border-orange-200 bg-orange-50">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            <div className="space-y-3">
              <div className="font-medium text-orange-800">
                🔔 มีสลิปการโอนเงินรอการยืนยัน
              </div>
              <div className="flex gap-2">
                <Button 
                  size="sm"
                  variant="outline"
                  onClick={() => setShowSlipPreview(true)}
                  className="flex-1"
                >
                  <Eye className="h-4 w-4 mr-2" />
                  ดูสลิป
                </Button>
                <Button 
                  size="sm"
                  variant="destructive"
                  onClick={handleRejectQRPayment}
                  className="flex-1"
                >
                  <X className="h-4 w-4 mr-2" />
                  ปฏิเสธ
                </Button>
                <Button 
                  size="sm"
                  onClick={handleApproveQRPayment}
                  className="flex-1 bg-green-500 hover:bg-green-600"
                >
                  <CheckCircle className="h-4 w-4 mr-2" />
                  ยืนยัน
                </Button>
              </div>
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* แสดงสลิปเต็มจอ */}
      {showSlipPreview && pendingQRPayment && (
        <Dialog open={showSlipPreview} onOpenChange={setShowSlipPreview}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>สลิปการโอนเงิน</DialogTitle>
              <DialogDescription>
                ออเดอร์ {order.order_number} - ฿{order.total_amount?.toFixed(2)}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <img 
                src={pendingQRPayment.slipData} 
                alt="สลิปการโอนเงิน" 
                className="w-full rounded-lg border"
              />
              <div className="grid grid-cols-2 gap-3">
                <Button 
                  variant="destructive"
                  onClick={handleRejectQRPayment}
                >
                  <X className="h-4 w-4 mr-2" />
                  ปฏิเสธ
                </Button>
                <Button 
                  onClick={handleApproveQRPayment}
                  className="bg-green-500 hover:bg-green-600"
                >
                  <CheckCircle className="h-4 w-4 mr-2" />
                  ยืนยัน
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* เตือนเมื่อไม่ใช่ admin/manager */}
      {!canHandleCash && (
        <Alert>
          <Lock className="h-4 w-4" />
          <AlertDescription>
            คุณสามารถใช้บัตรเครดิตหรือ QR Code เท่านั้น 
            การรับชำระเงินสดจำกัดเฉพาะผู้จัดการและแอดมิน
          </AlertDescription>
        </Alert>
      )}

      {/* เตือนเมื่อไม่มีลิ้นชักเปิด (สำหรับผู้ที่มีสิทธิ์) */}
      {paymentMethod === 'cash' && canHandleCash && !currentShift && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            ไม่สามารถชำระด้วยเงินสดได้ เนื่องจากไม่มีกะลิ้นชักที่เปิดอยู่
            กรุณาเปิดกะในระบบลิ้นชักเงินสดก่อน
          </AlertDescription>
        </Alert>
      )}

      {/* ข้อมูลออเดอร์ */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm">รายละเอียดออเดอร์</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {order.order_type === 'dine-in' && order.tables && (
            <div className="flex justify-between text-sm">
              <span>โต๊ะ:</span>
              <span>{order.tables.table_number}</span>
            </div>
          )}
          {order.order_type === 'takeaway' && order.takeaway_orders?.[0] && (
            <div className="flex justify-between text-sm">
              <span>ลูกค้า:</span>
              <span>{order.takeaway_orders[0].customer_name}</span>
            </div>
          )}
          <div className="flex justify-between text-sm">
            <span>จำนวนรายการ:</span>
            <span>{order.order_items?.length || 0}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span>สถานะ:</span>
            <Badge variant={order.status === 'ready' ? 'default' : 'secondary'}>
              {order.status === 'ready' ? 'พร้อมเสิร์ฟ' : 
               order.status === 'served' ? 'เสิร์ฟแล้ว' : 
               order.status}
            </Badge>
          </div>
          <div className="flex justify-between font-semibold text-lg border-t pt-2">
            <span>ยอดรวม:</span>
            <span>฿{order.total_amount?.toFixed(2)}</span>
          </div>
        </CardContent>
      </Card>

      {/* ถ้าไม่มีสลิปรอยืนยัน ให้แสดงฟอร์มชำระเงินปกติ */}
      {!pendingQRPayment && (
        <>
          {/* เลือกวิธีการชำระเงิน */}
          <div className="space-y-3">
            <Label>วิธีการชำระเงิน</Label>
            <div className="grid grid-cols-3 gap-2">
              <Button
                variant={paymentMethod === 'cash' ? 'default' : 'outline'}
                onClick={() => setPaymentMethod('cash')}
                className="h-16 flex flex-col gap-1"
                disabled={isProcessing || !canHandleCash}
              >
                <Banknote className="h-5 w-5" />
                <span className="text-xs">เงินสด</span>
                {!canHandleCash && (
                  <span className="text-xs text-red-500">ไม่อนุญาต</span>
                )}
              </Button>
              <Button
                variant={paymentMethod === 'credit_card' ? 'default' : 'outline'}
                onClick={() => setPaymentMethod('credit_card')}
                className="h-16 flex flex-col gap-1"
                disabled={isProcessing}
              >
                <CreditCard className="h-5 w-5" />
                <span className="text-xs">บัตรเครดิต</span>
              </Button>
              <Button
                variant={paymentMethod === 'qr_code' ? 'default' : 'outline'}
                onClick={() => setPaymentMethod('qr_code')}
                className="h-16 flex flex-col gap-1"
                disabled={isProcessing}
              >
                <Smartphone className="h-5 w-5" />
                <span className="text-xs">QR Code</span>
              </Button>
            </div>
          </div>

          {/* ฟิลด์ตามวิธีการชำระเงิน */}
          {paymentMethod === 'cash' && canHandleCash && (
            <div className="space-y-3">
              <div>
                <Label>จำนวนเงินที่รับ</Label>
                <Input
                  type="number"
                  value={receivedAmount}
                  onChange={(e) => setReceivedAmount(e.target.value)}
                  placeholder="0.00"
                  className="text-lg"
                  disabled={isProcessing || !currentShift}
                />
              </div>
              {calculateChange() > 0 && (
                <div className="bg-blue-50 p-3 rounded-lg">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">เงินทอน:</span>
                    <span className="text-lg font-bold text-blue-600">
                      ฿{calculateChange().toFixed(2)}
                    </span>
                  </div>
                </div>
              )}
            </div>
          )}

          {paymentMethod === 'credit_card' && (
            <div>
              <Label>หมายเลขบัตรเครดิต (4 หลักสุดท้าย)</Label>
              <Input
                value={creditCardNumber}
                onChange={(e) => setCreditCardNumber(e.target.value)}
                placeholder="****"
                maxLength={4}
                disabled={isProcessing}
              />
            </div>
          )}

          {/* ปุ่มดำเนินการ */}
          <div className="flex gap-3 pt-4">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1"
              disabled={isProcessing}
            >
              ยกเลิก
            </Button>
            
            {paymentMethod === 'qr_code' ? (
              <Button
                onClick={handleQRPayment}
                disabled={isProcessing}
                className="flex-1"
              >
                <Smartphone className="h-4 w-4 mr-2" />
                แสดง QR Code
              </Button>
            ) : (
              <Button
                onClick={() => processPayment.mutate()}
                disabled={!canProcess()}
                className="flex-1"
              >
                {isProcessing ? 'กำลังดำเนินการ...' : 
                 `ชำระเงิน ฿${order.total_amount?.toFixed(2)}`}
              </Button>
            )}
          </div>
        </>
      )}

      {/* ปุ่มปริ้นต์ (หลังชำระเงินแล้ว) */}
      {order.status === 'completed' && order.payments && order.payments.length > 0 && (
        <div className="border-t pt-4">
          <PrintButton order={order} className="w-full" />
        </div>
      )}
    </div>
  );

  if (embedded) {
    return (
      <div className="p-4">
        <div className="mb-4">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Receipt className="h-5 w-5" />
            ชำระเงิน - {order.order_number}
          </h3>
          <p className="text-sm text-gray-600">
            กรุณาเลือกวิธีการชำระเงินและใส่ข้อมูลที่จำเป็น
          </p>
        </div>
        {content}
      </div>
    );
  }

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Receipt className="h-5 w-5" />
              ชำระเงิน - {order.order_number}
            </DialogTitle>
            <DialogDescription>
              กรุณาเลือกวิธีการชำระเงินและใส่ข้อมูลที่จำเป็น
            </DialogDescription>
          </DialogHeader>
          {content}
        </DialogContent>
      </Dialog>

      {/* QR Payment Dialog */}
      <QRPaymentDialog
        order={order}
        open={showQRDialog}
        onOpenChange={setShowQRDialog}
        onPaymentComplete={handleQRPaymentComplete}
      />
    </>
  );
};

export default ImprovedPaymentSystem;

