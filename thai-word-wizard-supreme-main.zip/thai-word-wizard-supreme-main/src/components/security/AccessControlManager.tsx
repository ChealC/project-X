
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Shield, Fingerprint, Clock, MapPin, Smartphone, Key } from 'lucide-react';

interface AccessControlSettings {
  biometric_enabled: boolean;
  mfa_required: boolean;
  time_based_access: boolean;
  location_based: boolean;
  device_recognition: boolean;
  dynamic_permissions: boolean;
}

const AccessControlManager = () => {
  const [settings, setSettings] = useState<AccessControlSettings>({
    biometric_enabled: true,
    mfa_required: true,
    time_based_access: true,
    location_based: true,
    device_recognition: true,
    dynamic_permissions: true
  });

  const [workingHours, setWorkingHours] = useState({
    start: '09:00',
    end: '18:00'
  });

  const [allowedIPs, setAllowedIPs] = useState([
    '192.168.1.0/24',
    '10.0.0.0/8'
  ]);

  const [riskLevels] = useState([
    { level: 'low', permissions: ['VIEW_ORDERS', 'PROCESS_PAYMENT'], color: 'bg-green-500' },
    { level: 'medium', permissions: ['VIEW_ORDERS', 'PROCESS_PAYMENT', 'VOID_ITEMS'], color: 'bg-yellow-500' },
    { level: 'high', permissions: ['VIEW_ORDERS', 'PROCESS_PAYMENT', 'VOID_ITEMS', 'MANAGE_DISCOUNTS'], color: 'bg-orange-500' },
    { level: 'critical', permissions: ['FULL_ACCESS'], color: 'bg-red-500' }
  ]);

  const updateSetting = (key: keyof AccessControlSettings, value: boolean) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Multi-layer Authentication
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex items-center gap-2">
                <Fingerprint className="h-5 w-5" />
                <span>Biometric Integration</span>
              </div>
              <Switch
                checked={settings.biometric_enabled}
                onCheckedChange={(checked) => updateSetting('biometric_enabled', checked)}
              />
            </div>

            <div className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex items-center gap-2">
                <Key className="h-5 w-5" />
                <span>2FA/MFA Required</span>
              </div>
              <Switch
                checked={settings.mfa_required}
                onCheckedChange={(checked) => updateSetting('mfa_required', checked)}
              />
            </div>

            <div className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                <span>Time-based Access</span>
              </div>
              <Switch
                checked={settings.time_based_access}
                onCheckedChange={(checked) => updateSetting('time_based_access', checked)}
              />
            </div>

            <div className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                <span>Location-based Security</span>
              </div>
              <Switch
                checked={settings.location_based}
                onCheckedChange={(checked) => updateSetting('location_based', checked)}
              />
            </div>

            <div className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex items-center gap-2">
                <Smartphone className="h-5 w-5" />
                <span>Device Recognition</span>
              </div>
              <Switch
                checked={settings.device_recognition}
                onCheckedChange={(checked) => updateSetting('device_recognition', checked)}
              />
            </div>

            <div className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                <span>Dynamic Permissions</span>
              </div>
              <Switch
                checked={settings.dynamic_permissions}
                onCheckedChange={(checked) => updateSetting('dynamic_permissions', checked)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {settings.time_based_access && (
        <Card>
          <CardHeader>
            <CardTitle>Working Hours Configuration</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">เวลาเริ่มงาน</label>
                <Input
                  type="time"
                  value={workingHours.start}
                  onChange={(e) => setWorkingHours(prev => ({ ...prev, start: e.target.value }))}
                />
              </div>
              <div>
                <label className="text-sm font-medium">เวลาเลิกงาน</label>
                <Input
                  type="time"
                  value={workingHours.end}
                  onChange={(e) => setWorkingHours(prev => ({ ...prev, end: e.target.value }))}
                />
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {settings.location_based && (
        <Card>
          <CardHeader>
            <CardTitle>Allowed IP Addresses</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {allowedIPs.map((ip, index) => (
                <div key={index} className="flex items-center gap-2">
                  <Input value={ip} readOnly />
                  <Badge variant="outline">Active</Badge>
                </div>
              ))}
              <Button variant="outline" size="sm">
                Add New IP Range
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {settings.dynamic_permissions && (
        <Card>
          <CardHeader>
            <CardTitle>Risk-based Permission Levels</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {riskLevels.map((risk) => (
                <div key={risk.level} className="p-3 border rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <div className={`w-3 h-3 rounded-full ${risk.color}`} />
                    <span className="font-medium capitalize">{risk.level} Risk</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {risk.permissions.map((permission) => (
                      <Badge key={permission} variant="secondary" className="text-xs">
                        {permission}
                      </Badge>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default AccessControlManager;
