
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Shield, CheckCircle, AlertTriangle, FileText, Download } from 'lucide-react';

interface ComplianceStandard {
  id: string;
  name: string;
  description: string;
  compliance_level: number;
  last_audit: string;
  next_audit: string;
  status: 'compliant' | 'partial' | 'non_compliant';
  requirements: string[];
}

const ComplianceMonitor = () => {
  const [selectedStandard, setSelectedStandard] = useState<string>('');

  const { data: complianceData } = useQuery({
    queryKey: ['compliance-monitoring'],
    queryFn: async () => {
      // Simulate compliance data
      const standards: ComplianceStandard[] = [
        {
          id: 'pci_dss',
          name: 'PCI DSS',
          description: 'Payment Card Industry Data Security Standard',
          compliance_level: 95,
          last_audit: '2024-01-15',
          next_audit: '2024-07-15',
          status: 'compliant',
          requirements: [
            'Install and maintain firewalls',
            'Do not use vendor-supplied defaults',
            'Protect stored cardholder data',
            'Encrypt transmission of cardholder data',
            'Use and regularly update anti-virus software'
          ]
        },
        {
          id: 'pdpa',
          name: 'PDPA Thailand',
          description: 'Personal Data Protection Act',
          compliance_level: 88,
          last_audit: '2024-02-01',
          next_audit: '2024-08-01',
          status: 'partial',
          requirements: [
            'Consent management',
            'Data subject rights',
            'Data breach notification',
            'Privacy by design',
            'Data protection officer appointment'
          ]
        },
        {
          id: 'revenue_dept',
          name: 'กรมสรรพากร',
          description: 'e-Tax Invoice & e-Receipt Compliance',
          compliance_level: 92,
          last_audit: '2024-01-30',
          next_audit: '2024-07-30',
          status: 'compliant',
          requirements: [
            'Digital signature implementation',
            'QR code generation',
            'Real-time reporting',
            'Data retention policies',
            'Audit trail maintenance'
          ]
        },
        {
          id: 'haccp',
          name: 'HACCP',
          description: 'Hazard Analysis Critical Control Points',
          compliance_level: 78,
          last_audit: '2024-02-15',
          next_audit: '2024-05-15',
          status: 'partial',
          requirements: [
            'Temperature monitoring',
            'Food safety documentation',
            'Critical control points',
            'Corrective actions',
            'Verification procedures'
          ]
        },
        {
          id: 'iso_27001',
          name: 'ISO 27001',
          description: 'Information Security Management',
          compliance_level: 85,
          last_audit: '2024-01-10',
          next_audit: '2024-07-10',
          status: 'compliant',
          requirements: [
            'Risk assessment',
            'Security policies',
            'Access control',
            'Incident management',
            'Business continuity'
          ]
        }
      ];

      return standards;
    }
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'compliant': return 'bg-green-500';
      case 'partial': return 'bg-yellow-500';
      case 'non_compliant': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'compliant': return 'ผ่านมาตรฐาน';
      case 'partial': return 'ผ่านบางส่วน';
      case 'non_compliant': return 'ไม่ผ่านมาตรฐาน';
      default: return 'ไม่ทราบสถานะ';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'compliant': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'partial': return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case 'non_compliant': return <AlertTriangle className="h-4 w-4 text-red-500" />;
      default: return <Shield className="h-4 w-4 text-gray-500" />;
    }
  };

  const overallCompliance = complianceData 
    ? Math.round(complianceData.reduce((acc, std) => acc + std.compliance_level, 0) / complianceData.length)
    : 0;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Overall Compliance Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center mb-4">
            <div className="text-3xl font-bold mb-2">{overallCompliance}%</div>
            <Progress value={overallCompliance} className="w-full mb-2" />
            <p className="text-sm text-gray-600">ระดับการปฏิบัติตามมาตรฐานโดยรวม</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-3 bg-green-50 rounded-lg">
              <div className="text-lg font-bold text-green-600">
                {complianceData?.filter(s => s.status === 'compliant').length || 0}
              </div>
              <div className="text-sm text-green-600">ผ่านมาตรฐาน</div>
            </div>
            <div className="text-center p-3 bg-yellow-50 rounded-lg">
              <div className="text-lg font-bold text-yellow-600">
                {complianceData?.filter(s => s.status === 'partial').length || 0}
              </div>
              <div className="text-sm text-yellow-600">ผ่านบางส่วน</div>
            </div>
            <div className="text-center p-3 bg-red-50 rounded-lg">
              <div className="text-lg font-bold text-red-600">
                {complianceData?.filter(s => s.status === 'non_compliant').length || 0}
              </div>
              <div className="text-sm text-red-600">ไม่ผ่านมาตรฐาน</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {complianceData?.map((standard) => (
          <Card key={standard.id} className="cursor-pointer hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  {getStatusIcon(standard.status)}
                  {standard.name}
                </span>
                <Badge className={getStatusColor(standard.status)}>
                  {getStatusText(standard.status)}
                </Badge>
              </CardTitle>
              <p className="text-sm text-gray-600">{standard.description}</p>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>ระดับการปฏิบัติตาม</span>
                    <span>{standard.compliance_level}%</span>
                  </div>
                  <Progress value={standard.compliance_level} />
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-gray-500">ตรวจล่าสุด:</span>
                    <div>{new Date(standard.last_audit).toLocaleDateString('th-TH')}</div>
                  </div>
                  <div>
                    <span className="text-gray-500">ตรวจครั้งถัดไป:</span>
                    <div>{new Date(standard.next_audit).toLocaleDateString('th-TH')}</div>
                  </div>
                </div>

                <div>
                  <span className="text-sm font-medium">ข้อกำหนดหลัก:</span>
                  <div className="mt-1 space-y-1">
                    {standard.requirements.slice(0, 3).map((req, index) => (
                      <div key={index} className="text-xs text-gray-600 flex items-center gap-1">
                        <CheckCircle className="h-3 w-3 text-green-500" />
                        {req}
                      </div>
                    ))}
                    {standard.requirements.length > 3 && (
                      <div className="text-xs text-gray-500">
                        และอีก {standard.requirements.length - 3} รายการ...
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button size="sm" variant="outline" className="flex-1">
                    <FileText className="h-3 w-3 mr-1" />
                    รายละเอียด
                  </Button>
                  <Button size="sm" variant="outline" className="flex-1">
                    <Download className="h-3 w-3 mr-1" />
                    รายงาน
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default ComplianceMonitor;
