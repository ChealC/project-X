
import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface ThreatEvent {
  id: string;
  type: 'ANOMALY_DETECTION' | 'FRAUD_PREVENTION' | 'PATTERN_RECOGNITION' | 'BEHAVIORAL_ANALYSIS' | 'TRANSACTION_MONITORING' | 'NETWORK_ANALYSIS';
  severity: 'critical' | 'high' | 'medium' | 'low';
  source: string;
  description: string;
  metadata: any;
  timestamp: string;
  auto_resolved: boolean;
}

export const useThreatDetection = () => {
  const [isActive, setIsActive] = useState(true);
  const [detectionRules, setDetectionRules] = useState({
    anomaly_threshold: 85,
    fraud_sensitivity: 'high',
    pattern_matching: true,
    behavioral_baseline: 30, // days
    transaction_limit_check: true,
    network_monitoring: true
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: threats } = useQuery({
    queryKey: ['threat-detection'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('security_alerts')
        .select('*')
        .eq('alert_type', 'THREAT_DETECTION')
        .order('created_at', { ascending: false })
        .limit(50);
      
      if (error) throw error;
      return data || [];
    },
    refetchInterval: isActive ? 5000 : false, // 5 second intervals for real-time monitoring
  });

  const detectThreats = useMutation({
    mutationFn: async () => {
      console.log('AI Security Bot: Running comprehensive threat detection...');
      
      // Simulate various threat detection algorithms
      const detectedThreats = [];
      
      // 1. Anomaly Detection
      if (Math.random() > 0.85) {
        detectedThreats.push({
          type: 'ANOMALY_DETECTION',
          severity: Math.random() > 0.7 ? 'high' : 'medium',
          source: 'Login System',
          description: `ตรวจพบการเข้าสู่ระบบผิดปกติจาก IP ${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
          metadata: { 
            failed_attempts: Math.floor(Math.random() * 10) + 5,
            time_window: '5 minutes',
            geolocation: 'Unknown'
          }
        });
      }

      // 2. Fraud Prevention
      if (Math.random() > 0.8) {
        detectedThreats.push({
          type: 'FRAUD_PREVENTION',
          severity: 'critical',
          source: 'Transaction Monitor',
          description: 'ตรวจพบการใช้ส่วนลดผิดปกติ - เกินกำหนดวันละ 10 ครั้ง',
          metadata: {
            employee_id: 'EMP001',
            discount_count: 25,
            normal_average: 3,
            suspicious_pattern: true
          }
        });
      }

      // 3. Pattern Recognition
      if (Math.random() > 0.9) {
        detectedThreats.push({
          type: 'PATTERN_RECOGNITION',
          severity: 'high',
          source: 'Network Security',
          description: 'ตรวจพบรูปแบบการโจมตี SQL Injection',
          metadata: {
            attack_type: 'SQL Injection',
            source_ip: '192.168.1.100',
            blocked_attempts: 15,
            attack_vector: 'Web Form Input'
          }
        });
      }

      // 4. Behavioral Analysis
      if (Math.random() > 0.85) {
        detectedThreats.push({
          type: 'BEHAVIORAL_ANALYSIS',
          severity: 'medium',
          source: 'User Behavior Monitor',
          description: 'พนักงานเข้าถึงข้อมูลลูกค้านอกเวลาทำการ',
          metadata: {
            employee: 'นางสาวอำไพ ใจดี',
            access_time: '02:30 AM',
            data_accessed: 'Customer Database',
            normal_hours: '09:00-18:00'
          }
        });
      }

      // Store detected threats
      for (const threat of detectedThreats) {
        await supabase.from('security_alerts').insert({
          alert_type: 'THREAT_DETECTION',
          severity: threat.severity,
          title: `${threat.type}: ${threat.source}`,
          description: threat.description,
          metadata: {
            ...threat.metadata,
            detection_time: new Date().toISOString(),
            auto_detection: true,
            threat_type: threat.type
          }
        });
      }

      return detectedThreats;
    },
    onSuccess: (threats) => {
      queryClient.invalidateQueries({ queryKey: ['threat-detection'] });
      
      if (threats.length > 0) {
        const criticalThreats = threats.filter(t => t.severity === 'critical').length;
        toast({
          title: "🚨 AI Security Alert",
          description: `ตรวจพบภัยคุกคาม ${threats.length} รายการ${criticalThreats > 0 ? ` (วิกฤต ${criticalThreats} รายการ)` : ''}`,
          variant: criticalThreats > 0 ? "destructive" : "default"
        });
      }
    }
  });

  const autoRespondToThreat = useMutation({
    mutationFn: async (threatId: string) => {
      console.log(`AI Security Bot: Auto-responding to threat ${threatId}...`);
      
      // Simulate automated response actions
      const responseActions = [
        'Auto-blocked suspicious IP address',
        'Terminated suspicious session',
        'Locked compromised account',
        'Triggered data backup',
        'Escalated to security team',
        'Collected forensic evidence'
      ];

      const action = responseActions[Math.floor(Math.random() * responseActions.length)];
      
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const { error } = await supabase
        .from('security_alerts')
        .update({
          is_resolved: true,
          resolved_at: new Date().toISOString(),
          metadata: { 
            auto_response: true,
            response_action: action,
            response_time: '0.1 seconds',
            resolution_method: 'AI_AUTOMATED'
          }
        })
        .eq('id', threatId);

      if (error) throw error;
      return action;
    },
    onSuccess: (action) => {
      queryClient.invalidateQueries({ queryKey: ['threat-detection'] });
      toast({
        title: "🤖 Auto-Response Executed",
        description: `การดำเนินการ: ${action}`
      });
    }
  });

  // Auto-detection effect
  useEffect(() => {
    if (isActive) {
      const interval = setInterval(() => {
        detectThreats.mutate();
      }, 10000); // Run every 10 seconds for demonstration

      return () => clearInterval(interval);
    }
  }, [isActive]);

  return {
    threats,
    isActive,
    setIsActive,
    detectionRules,
    setDetectionRules,
    detectThreats,
    autoRespondToThreat,
    isDetecting: detectThreats.isPending,
    isResponding: autoRespondToThreat.isPending
  };
};
