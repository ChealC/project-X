import { useState, useRef, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { Tables } from '@/integrations/supabase/types';
import { Plus, Minus, ShoppingCart } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { generateUniqueOrderNumber, canSubmitOrder, markSubmissionStart, markSubmissionEnd, resetSubmissionTracker } from '@/utils/orderUtils';

interface TableOrderDialogProps {
  table: Tables<'tables'>;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  specialInstructions?: string;
}

const TableOrderDialog = ({ table, open, onOpenChange }: TableOrderDialogProps) => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [customerCount, setCustomerCount] = useState(1);
  const [orderNotes, setOrderNotes] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Debounce ref for button clicks
  const debounceRef = useRef<NodeJS.Timeout | null>(null);
  const lastClickTimeRef = useRef(0);

  // Get or create default kitchen station
  const { data: defaultStation } = useQuery({
    queryKey: ['default-kitchen-station'],
    queryFn: async () => {
      console.log('Checking for kitchen stations...');
      
      let { data: stations, error } = await supabase
        .from('kitchen_stations')
        .select('*')
        .eq('is_active', true)
        .limit(1);
      
      if (error) {
        console.error('Error fetching stations:', error);
        throw error;
      }
      
      console.log('Found stations:', stations);
      
      if (!stations || stations.length === 0) {
        console.log('No stations found, creating default station...');
        const { data: newStation, error: createError } = await supabase
          .from('kitchen_stations')
          .insert({
            name: 'ครัวหลัก',
            description: 'สถานีครัวหลัก',
            is_active: true
          })
          .select()
          .single();
        
        if (createError) {
          console.error('Error creating station:', createError);
          throw createError;
        }
        
        console.log('Created new station:', newStation);
        return newStation;
      }
      
      console.log('Using existing station:', stations[0]);
      return stations[0];
    }
  });

  const { data: menuCategories } = useQuery({
    queryKey: ['menu-categories'],
    queryFn: async () => {
      console.log('Fetching menu categories...');
      const { data, error } = await supabase
        .from('menu_categories')
        .select('*, menu_items(*)')
        .eq('is_active', true)
        .order('sort_order');
      
      if (error) {
        console.error('Error fetching menu categories:', error);
        throw error;
      }
      
      console.log('Fetched menu categories:', data);
      return data;
    }
  });

  const createOrder = useMutation({
    mutationFn: async () => {
      console.log('Starting order creation with duplicate prevention...');
      
      if (!canSubmitOrder()) {
        throw new Error('การส่งออเดอร์ถูกบล็อก กรุณารอสักครู่');
      }
      
      if (isProcessing) {
        throw new Error('กำลังประมวลผลออเดอร์อยู่ กรุณารอ');
      }
      
      markSubmissionStart();
      setIsProcessing(true);
      
      try {
        if (!defaultStation) {
          throw new Error('ไม่สามารถหาสถานีครัวได้ กรุณาติดต่อผู้ดูแลระบบ');
        }

        if (cart.length === 0) {
          throw new Error('กรุณาเลือกอาหารก่อนส่งออเดอร์');
        }

        console.log('Generating unique order number...');
        const orderNumber = await generateUniqueOrderNumber(table.table_number.toString(), 'dine-in');
        
        // Verify order number doesn't exist
        const { data: existingOrder } = await supabase
          .from('orders')
          .select('id, order_number')
          .eq('order_number', orderNumber)
          .maybeSingle();
          
        if (existingOrder) {
          console.error('Order number collision detected:', orderNumber);
          throw new Error('เกิดข้อผิดพลาดในการสร้างหมายเลขออเดอร์ กรุณาลองใหม่');
        }
        
        const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        const totalAmount = subtotal;

        console.log('Order details:', { orderNumber, subtotal, totalAmount, cart });

        // Update menu items to have kitchen station assignments
        console.log('Updating menu items kitchen station assignments...');
        for (const cartItem of cart) {
          const { error: updateError } = await supabase
            .from('menu_items')
            .update({ kitchen_station_id: defaultStation.id })
            .eq('id', cartItem.id)
            .is('kitchen_station_id', null);
          
          if (updateError) {
            console.error('Error updating menu item:', updateError);
          }
        }

        // Create order
        console.log('Creating order...');
        const { data: order, error: orderError } = await supabase
          .from('orders')
          .insert({
            order_number: orderNumber,
            table_id: table.id,
            order_type: 'dine-in',
            subtotal,
            tax_amount: 0,
            service_charge: 0,
            discount_amount: 0,
            total_amount: totalAmount,
            customer_count: customerCount,
            status: 'pending',
            notes: orderNotes
          })
          .select()
          .single();

        if (orderError) {
          console.error('Error creating order:', orderError);
          throw orderError;
        }

        console.log('Order created successfully:', order);

        // Create order items
        console.log('Creating order items...');
        const orderItems = cart.map(item => ({
          order_id: order.id,
          menu_item_id: item.id,
          quantity: item.quantity,
          unit_price: item.price,
          total_price: item.price * item.quantity,
          special_instructions: item.specialInstructions
        }));

        const { data: createdItems, error: itemsError } = await supabase
          .from('order_items')
          .insert(orderItems)
          .select();

        if (itemsError) {
          console.error('Error creating order items:', itemsError);
          throw itemsError;
        }

        console.log('Order items created:', createdItems);

        // Create kitchen queue entries - ONE PER ORDER ITEM ONLY
        console.log('Creating kitchen queue entries (one per order item)...');
        const queuePromises = createdItems.map(async (orderItem) => {
          // Check if queue entry already exists for this order item
          const { data: existingQueue } = await supabase
            .from('kitchen_queue')
            .select('id')
            .eq('order_item_id', orderItem.id)
            .maybeSingle();

          if (existingQueue) {
            console.log('Kitchen queue entry already exists for item:', orderItem.id);
            return;
          }

          const { data: queueEntry, error: queueError } = await supabase
            .from('kitchen_queue')
            .insert({
              order_item_id: orderItem.id,
              station_id: defaultStation.id,
              estimated_time: 15,
              status: 'pending'
            })
            .select()
            .single();

          if (queueError) {
            console.error('Kitchen queue creation error for item:', orderItem.id, queueError);
            throw queueError;
          } else {
            console.log('Kitchen queue entry created for item:', orderItem.id, queueEntry);
          }

          return queueEntry;
        });

        await Promise.all(queuePromises);

        // Update table status
        console.log('Updating table status...');
        const { error: tableError } = await supabase
          .from('tables')
          .update({ status: 'occupied' })
          .eq('id', table.id);

        if (tableError) {
          console.error('Error updating table status:', tableError);
          throw tableError;
        }

        console.log('Order creation completed successfully');
        return order;
      } finally {
        setIsProcessing(false);
        markSubmissionEnd();
      }
    },
    onSuccess: () => {
      console.log('Order creation successful, resetting form...');
      setCart([]);
      setCustomerCount(1);
      setOrderNotes('');
      onOpenChange(false);
      
      resetSubmissionTracker();
      
      queryClient.invalidateQueries({ queryKey: ['tables'] });
      queryClient.invalidateQueries({ queryKey: ['kitchen-queue'] });
      queryClient.invalidateQueries({ queryKey: ['orders-ready-for-payment'] });
      queryClient.invalidateQueries({ queryKey: ['pending-orders'] });
      toast({
        title: "สั่งอาหารสำเร็จ",
        description: `ออเดอร์โต๊ะ ${table.table_number} ถูกส่งเข้าครัวแล้ว`
      });
    },
    onError: (error: any) => {
      console.error('Order creation failed:', error);
      setIsProcessing(false);
      markSubmissionEnd();
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error.message || "ไม่สามารถสร้างออเดอร์ได้",
        variant: "destructive"
      });
    }
  });

  // Debounced submit function
  const handleSubmitOrder = useCallback(() => {
    const now = Date.now();
    
    // Prevent rapid clicks
    if (now - lastClickTimeRef.current < 3000) {
      console.log('Submit blocked: too rapid clicking');
      return;
    }
    
    lastClickTimeRef.current = now;
    
    // Clear any existing debounce
    if (debounceRef.current) {
      clearTimeout(debounceRef.current);
    }
    
    // Debounce the actual submission
    debounceRef.current = setTimeout(() => {
      if (canSubmitOrder() && !isProcessing && defaultStation && cart.length > 0) {
        createOrder.mutate();
      }
    }, 500);
  }, [createOrder, isProcessing, defaultStation, cart.length]);

  const addToCart = (menuItem: any) => {
    console.log('Adding item to cart:', menuItem);
    const existingItem = cart.find(item => item.id === menuItem.id);
    if (existingItem) {
      setCart(cart.map(item => 
        item.id === menuItem.id 
          ? { ...item, quantity: item.quantity + 1 }
          : item
      ));
    } else {
      setCart([...cart, {
        id: menuItem.id,
        name: menuItem.name,
        price: menuItem.price,
        quantity: 1
      }]);
    }
  };

  const updateQuantity = (id: string, quantity: number) => {
    if (quantity === 0) {
      setCart(cart.filter(item => item.id !== id));
    } else {
      setCart(cart.map(item => 
        item.id === id ? { ...item, quantity } : item
      ));
    }
  };

  const updateSpecialInstructions = (id: string, instructions: string) => {
    setCart(cart.map(item => 
      item.id === id ? { ...item, specialInstructions: instructions } : item
    ));
  };

  const calculateTotal = () => {
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    return { subtotal, tax: 0, total: subtotal };
  };

  // Reset state when dialog closes
  const handleOpenChange = (open: boolean) => {
    if (!open) {
      resetSubmissionTracker();
      setIsProcessing(false);
    }
    onOpenChange(open);
  };

  const { subtotal, tax, total } = calculateTotal();

  const isSubmitDisabled = () => {
    return (
      createOrder.isPending || 
      isProcessing ||
      !canSubmitOrder() ||
      !defaultStation ||
      cart.length === 0
    );
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>สั่งอาหาร - โต๊ะ {table.table_number} ({table.seats} ที่นั่ง)</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Menu Section */}
          <div className="lg:col-span-2">
            {menuCategories && menuCategories.length > 0 ? (
              <Tabs defaultValue={menuCategories[0]?.id} className="space-y-4">
                <TabsList className="grid w-full" style={{ gridTemplateColumns: `repeat(${menuCategories.length}, 1fr)` }}>
                  {menuCategories.map((category) => (
                    <TabsTrigger key={category.id} value={category.id}>
                      {category.name}
                    </TabsTrigger>
                  ))}
                </TabsList>

                {menuCategories.map((category) => (
                  <TabsContent key={category.id} value={category.id}>
                    <div className="grid grid-cols-2 gap-4">
                      {category.menu_items && category.menu_items.length > 0 ? (
                        category.menu_items.map((item) => (
                          <Card key={item.id} className="cursor-pointer hover:shadow-md transition-shadow">
                            <CardContent className="p-4">
                              <h3 className="font-semibold mb-1">{item.name}</h3>
                              <p className="text-sm text-gray-600 mb-2">{item.description}</p>
                              <div className="flex justify-between items-center">
                                <span className="text-lg font-bold text-green-600">
                                  ฿{item.price}
                                </span>
                                <Button 
                                  size="sm" 
                                  onClick={() => addToCart(item)}
                                  disabled={!item.is_available || isProcessing}
                                >
                                  <Plus className="h-4 w-4" />
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        ))
                      ) : (
                        <div className="col-span-2 text-center py-8 text-gray-500">
                          ไม่มีเมนูในหมวดหมู่นี้
                        </div>
                      )}
                    </div>
                  </TabsContent>
                ))}
              </Tabs>
            ) : (
              <div className="text-center py-8 text-gray-500">
                กำลังโหลดเมนู...
              </div>
            )}
          </div>

          {/* Order Summary */}
          <div className="space-y-4">
            <Card>
              <CardContent className="p-4 space-y-4">
                <div className="flex items-center gap-2">
                  <ShoppingCart className="h-5 w-5" />
                  <span className="font-semibold">ออเดอร์ ({cart.length} รายการ)</span>
                </div>

                {/* Customer Count */}
                <div>
                  <Label>จำนวนลูกค้า</Label>
                  <Input 
                    type="number" 
                    value={customerCount}
                    onChange={(e) => setCustomerCount(parseInt(e.target.value) || 1)}
                    min={1}
                    max={table.seats}
                    disabled={isProcessing}
                  />
                </div>

                {/* Cart Items */}
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {cart.map((item) => (
                    <div key={item.id} className="border rounded p-2 space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <h4 className="font-medium text-sm">{item.name}</h4>
                          <p className="text-sm text-gray-600">฿{item.price}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            disabled={isProcessing}
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          <span className="w-8 text-center">{item.quantity}</span>
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            disabled={isProcessing}
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                      <Textarea
                        placeholder="หมายเหตุพิเศษ..."
                        value={item.specialInstructions || ''}
                        onChange={(e) => updateSpecialInstructions(item.id, e.target.value)}
                        className="text-sm"
                        rows={2}
                        disabled={isProcessing}
                      />
                    </div>
                  ))}
                </div>

                {/* Order Notes */}
                <div>
                  <Label>หมายเหตุออเดอร์</Label>
                  <Textarea
                    placeholder="หมายเหตุเพิ่มเติม..."
                    value={orderNotes}
                    onChange={(e) => setOrderNotes(e.target.value)}
                    disabled={isProcessing}
                  />
                </div>

                {/* Order Summary */}
                {cart.length > 0 && (
                  <div className="border-t pt-4 space-y-2">
                    <div className="flex justify-between font-bold">
                      <span>ยอดสุทธิ:</span>
                      <span>฿{total.toFixed(2)}</span>
                    </div>
                    <Button 
                      className="w-full" 
                      onClick={handleSubmitOrder}
                      disabled={isSubmitDisabled()}
                    >
                      {createOrder.isPending || isProcessing ? 'กำลังส่งเข้าครัว...' : 'ส่งเข้าครัว'}
                    </Button>
                    
                    {!canSubmitOrder() && (
                      <p className="text-xs text-orange-600 text-center">
                        กรุณารอ 10 วินาทีก่อนส่งออเดอร์ใหม่
                      </p>
                    )}
                  </div>
                )}

                {cart.length === 0 && (
                  <div className="text-center py-4 text-gray-500">
                    เลือกอาหารจากเมนูเพื่อเริ่มสั่งอาหาร
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default TableOrderDialog;
