import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/integrations/supabase/client';
import { Clock, Users, ChefHat, CheckCircle, PlayCircle, Timer, AlertCircle, UtensilsCrossed } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const KitchenSystem = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: kitchenStations } = useQuery({
    queryKey: ['kitchen-stations'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('kitchen_stations')
        .select('*')
        .eq('is_active', true)
        .order('name');
      
      if (error) throw error;
      return data;
    }
  });

  const { data: kitchenQueue } = useQuery({
    queryKey: ['kitchen-queue'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('kitchen_queue')
        .select(`
          *,
          order_items(
            *,
            menu_items(name, description),
            orders(
              order_number, 
              table_id, 
              order_type,
              tables(table_number)
            )
          ),
          kitchen_stations(name)
        `)
        .in('status', ['pending', 'preparing'])
        .order('created_at');
      
      if (error) throw error;
      return data;
    }
  });

  const updateKitchenStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const updateData: any = { 
        status, 
        updated_at: new Date().toISOString() 
      };

      if (status === 'preparing') {
        updateData.started_at = new Date().toISOString();
      } else if (status === 'ready') {
        updateData.completed_at = new Date().toISOString();
      }

      const { error } = await supabase
        .from('kitchen_queue')
        .update(updateData)
        .eq('id', id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['kitchen-queue'] });
      toast({
        title: "อัปเดตสถานะสำเร็จ",
        description: "สถานะการทำอาหารได้รับการอัปเดตแล้ว"
      });
    }
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-500';
      case 'preparing': return 'bg-blue-500';
      case 'ready': return 'bg-green-500';
      case 'served': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'รอทำ';
      case 'preparing': return 'กำลังทำ';
      case 'ready': return 'เสร็จแล้ว';
      case 'served': return 'เสิร์ฟแล้ว';
      default: return status;
    }
  };

  const getTimeElapsed = (createdAt: string, startedAt?: string) => {
    const start = startedAt ? new Date(startedAt) : new Date(createdAt);
    const now = new Date();
    const minutes = Math.floor((now.getTime() - start.getTime()) / 60000);
    return minutes;
  };

  if (!kitchenStations || kitchenStations.length === 0) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center text-gray-500">ไม่มีสถานีครัวที่ใช้งานได้</div>
        </CardContent>
      </Card>
    );
  }

  // Get total queue count for "All" tab
  const totalQueueCount = kitchenQueue?.length || 0;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ChefHat className="h-5 w-5" />
            ระบบครัว - จัดการออเดอร์
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all" className="space-y-4">
            <TabsList className="grid w-full gap-1" style={{ gridTemplateColumns: `repeat(${kitchenStations.length + 1}, 1fr)` }}>
              {/* Add "All" tab first */}
              <TabsTrigger value="all" className="relative">
                ทั้งหมด
                {totalQueueCount > 0 && (
                  <Badge className="ml-2 bg-red-500 text-white text-xs px-1 py-0">
                    {totalQueueCount}
                  </Badge>
                )}
              </TabsTrigger>
              
              {kitchenStations.map((station) => {
                const queueCount = kitchenQueue?.filter(item => item.station_id === station.id)?.length || 0;
                return (
                  <TabsTrigger key={station.id} value={station.id} className="relative">
                    {station.name}
                    {queueCount > 0 && (
                      <Badge className="ml-2 bg-red-500 text-white text-xs px-1 py-0">
                        {queueCount}
                      </Badge>
                    )}
                  </TabsTrigger>
                );
              })}
            </TabsList>

            {/* All orders tab content */}
            <TabsContent value="all">
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold">ออเดอร์ทั้งหมด</h3>
                  <Badge variant="outline">
                    ออเดอร์ในคิว: {totalQueueCount}
                  </Badge>
                </div>
                
                {totalQueueCount > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {kitchenQueue?.map((queueItem) => (
                      <Card key={queueItem.id} className="border-l-4 border-l-blue-500">
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start mb-3">
                            <div>
                              <h4 className="font-semibold">
                                {queueItem.order_items?.menu_items?.name}
                              </h4>
                              <p className="text-sm text-gray-600">
                                ออเดอร์: {queueItem.order_items?.orders?.order_number}
                              </p>
                              {queueItem.order_items?.orders?.tables?.table_number && (
                                <div className="flex items-center gap-1 text-sm text-blue-600 font-medium">
                                  <UtensilsCrossed className="h-4 w-4" />
                                  โต๊ะ: {queueItem.order_items.orders.tables.table_number}
                                </div>
                              )}
                              <p className="text-sm text-blue-600 font-medium">
                                สถานี: {queueItem.kitchen_stations?.name}
                              </p>
                            </div>
                            <Badge className={`${getStatusColor(queueItem.status)} text-white`}>
                              {getStatusText(queueItem.status)}
                            </Badge>
                          </div>

                          <div className="flex items-center gap-2 mb-3">
                            <Users className="h-4 w-4" />
                            <span className="text-sm">
                              จำนวน: {queueItem.order_items?.quantity}
                            </span>
                          </div>

                          <div className="flex items-center gap-2 mb-3">
                            <Timer className="h-4 w-4" />
                            <span className="text-sm">
                              เวลาประมาณ: {queueItem.estimated_time} นาที
                            </span>
                          </div>

                          <div className="flex items-center gap-2 mb-4">
                            <Clock className="h-4 w-4" />
                            <span className="text-sm">
                              เวลาผ่านไป: {getTimeElapsed(
                                queueItem.created_at, 
                                queueItem.started_at
                              )} นาที
                            </span>
                          </div>

                          {queueItem.order_items?.special_instructions && (
                            <div className="bg-yellow-50 p-2 rounded mb-3 flex items-start gap-2">
                              <AlertCircle className="h-4 w-4 text-yellow-600 mt-0.5 flex-shrink-0" />
                              <div>
                                <p className="text-sm font-medium text-yellow-800">หมายเหตุ:</p>
                                <p className="text-sm text-yellow-700">{queueItem.order_items.special_instructions}</p>
                              </div>
                            </div>
                          )}

                          <div className="flex gap-2">
                            {queueItem.status === 'pending' && (
                              <Button 
                                size="sm" 
                                onClick={() => updateKitchenStatus.mutate({ 
                                  id: queueItem.id, 
                                  status: 'preparing' 
                                })}
                                disabled={updateKitchenStatus.isPending}
                                className="flex-1"
                              >
                                <PlayCircle className="h-4 w-4 mr-1" />
                                เริ่มทำ
                              </Button>
                            )}
                            
                            {queueItem.status === 'preparing' && (
                              <Button 
                                size="sm" 
                                onClick={() => updateKitchenStatus.mutate({ 
                                  id: queueItem.id, 
                                  status: 'ready' 
                                })}
                                disabled={updateKitchenStatus.isPending}
                                className="flex-1"
                              >
                                <CheckCircle className="h-4 w-4 mr-1" />
                                เสร็จแล้ว
                              </Button>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <ChefHat className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-500 mb-2">ไม่มีออเดอร์ในคิว</h3>
                    <p className="text-gray-400">ครัวพร้อมรับงาน</p>
                  </div>
                )}
              </div>
            </TabsContent>

            {/* Individual station tabs */}
            {kitchenStations.map((station) => {
              const stationQueue = kitchenQueue?.filter(item => item.station_id === station.id) || [];
              
              return (
                <TabsContent key={station.id} value={station.id}>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <h3 className="text-lg font-semibold">{station.name}</h3>
                      <Badge variant="outline">
                        ออเดอร์ในคิว: {stationQueue.length}
                      </Badge>
                    </div>
                    
                    {stationQueue.length > 0 ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {stationQueue.map((queueItem) => (
                          <Card key={queueItem.id} className="border-l-4 border-l-blue-500">
                            <CardContent className="p-4">
                              <div className="flex justify-between items-start mb-3">
                                <div>
                                  <h4 className="font-semibold">
                                    {queueItem.order_items?.menu_items?.name}
                                  </h4>
                                  <p className="text-sm text-gray-600">
                                    ออเดอร์: {queueItem.order_items?.orders?.order_number}
                                  </p>
                                  {queueItem.order_items?.orders?.tables?.table_number && (
                                    <div className="flex items-center gap-1 text-sm text-blue-600 font-medium">
                                      <UtensilsCrossed className="h-4 w-4" />
                                      โต๊ะ: {queueItem.order_items.orders.tables.table_number}
                                    </div>
                                  )}
                                </div>
                                <Badge className={`${getStatusColor(queueItem.status)} text-white`}>
                                  {getStatusText(queueItem.status)}
                                </Badge>
                              </div>

                              <div className="flex items-center gap-2 mb-3">
                                <Users className="h-4 w-4" />
                                <span className="text-sm">
                                  จำนวน: {queueItem.order_items?.quantity}
                                </span>
                              </div>

                              <div className="flex items-center gap-2 mb-3">
                                <Timer className="h-4 w-4" />
                                <span className="text-sm">
                                  เวลาประมาณ: {queueItem.estimated_time} นาที
                                </span>
                              </div>

                              <div className="flex items-center gap-2 mb-4">
                                <Clock className="h-4 w-4" />
                                <span className="text-sm">
                                  เวลาผ่านไป: {getTimeElapsed(
                                    queueItem.created_at, 
                                    queueItem.started_at
                                  )} นาที
                                </span>
                              </div>

                              {queueItem.order_items?.special_instructions && (
                                <div className="bg-yellow-50 p-2 rounded mb-3 flex items-start gap-2">
                                  <AlertCircle className="h-4 w-4 text-yellow-600 mt-0.5 flex-shrink-0" />
                                  <div>
                                    <p className="text-sm font-medium text-yellow-800">หมายเหตุ:</p>
                                    <p className="text-sm text-yellow-700">{queueItem.order_items.special_instructions}</p>
                                  </div>
                                </div>
                              )}

                              <div className="flex gap-2">
                                {queueItem.status === 'pending' && (
                                  <Button 
                                    size="sm" 
                                    onClick={() => updateKitchenStatus.mutate({ 
                                      id: queueItem.id, 
                                      status: 'preparing' 
                                    })}
                                    disabled={updateKitchenStatus.isPending}
                                    className="flex-1"
                                  >
                                    <PlayCircle className="h-4 w-4 mr-1" />
                                    เริ่มทำ
                                  </Button>
                                )}
                                
                                {queueItem.status === 'preparing' && (
                                  <Button 
                                    size="sm" 
                                    onClick={() => updateKitchenStatus.mutate({ 
                                      id: queueItem.id, 
                                      status: 'ready' 
                                    })}
                                    disabled={updateKitchenStatus.isPending}
                                    className="flex-1"
                                  >
                                    <CheckCircle className="h-4 w-4 mr-1" />
                                    เสร็จแล้ว
                                  </Button>
                                )}
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-12">
                        <ChefHat className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-gray-500 mb-2">ไม่มีออเดอร์ในคิว</h3>
                        <p className="text-gray-400">สถานี {station.name} พร้อมรับงาน</p>
                      </div>
                    )}
                  </div>
                </TabsContent>
              );
            })}
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default KitchenSystem;
