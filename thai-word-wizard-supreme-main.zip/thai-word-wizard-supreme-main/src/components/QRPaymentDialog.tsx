
import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CheckCircle, Clock, X, QrCode, Upload, AlertCircle, Camera } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';

interface QRPaymentDialogProps {
  order: any;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onPaymentComplete: () => void;
}

const QRPaymentDialog = ({ order, open, onOpenChange, onPaymentComplete }: QRPaymentDialogProps) => {
  const [paymentStatus, setPaymentStatus] = useState<'pending' | 'slip_uploaded' | 'confirmed' | 'rejected'>('pending');
  const [countdown, setCountdown] = useState(600); // 10 minutes
  const [slipImage, setSlipImage] = useState<File | null>(null);
  const [slipPreview, setSlipPreview] = useState<string>('');
  const { toast } = useToast();
  const { user } = useAuth();

  // Check if user is cashier (admin or manager)
  const isCashier = user?.role === 'admin' || user?.role === 'manager';

  // ฟังก์ชันบันทึกสถานะไปยัง localStorage
  const savePendingPayment = (orderId: string, status: string, slipData?: string) => {
    const pendingPayments = JSON.parse(localStorage.getItem('pendingQRPayments') || '{}');
    pendingPayments[orderId] = {
      orderId,
      status,
      slipData,
      timestamp: new Date().toISOString(),
      orderNumber: order?.order_number
    };
    localStorage.setItem('pendingQRPayments', JSON.stringify(pendingPayments));
  };

  // ฟังก์ชันลบข้อมูลจาก localStorage
  const removePendingPayment = (orderId: string) => {
    const pendingPayments = JSON.parse(localStorage.getItem('pendingQRPayments') || '{}');
    delete pendingPayments[orderId];
    localStorage.setItem('pendingQRPayments', JSON.stringify(pendingPayments));
  };

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (paymentStatus === 'pending' && countdown > 0) {
      timer = setTimeout(() => setCountdown(countdown - 1), 1000);
    } else if (countdown === 0 && paymentStatus === 'pending') {
      setPaymentStatus('rejected');
      toast({
        title: "หมดเวลาชำระเงิน",
        description: "กรุณาลองใหม่อีกครั้ง",
        variant: "destructive"
      });
    }
    return () => clearTimeout(timer);
  }, [countdown, paymentStatus, toast]);

  const handleSlipUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        toast({
          title: "ไฟล์ใหญ่เกินไป",
          description: "กรุณาเลือกไฟล์ที่มีขนาดไม่เกิน 5MB",
          variant: "destructive"
        });
        return;
      }

      setSlipImage(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        const imageData = e.target?.result as string;
        setSlipPreview(imageData);
        setPaymentStatus('slip_uploaded');
        
        // บันทึกข้อมูลไปยัง localStorage
        if (order?.id) {
          savePendingPayment(order.id, 'slip_uploaded', imageData);
        }
        
        toast({
          title: "อัพโหลดสลิปสำเร็จ",
          description: "รอการยืนยันจากแคชเชียร์",
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCashierConfirm = () => {
    setPaymentStatus('confirmed');
    
    // ลบข้อมูลจาก localStorage
    if (order?.id) {
      removePendingPayment(order.id);
    }
    
    toast({
      title: "ยืนยันการชำระเงินสำเร็จ",
      description: "การชำระเงินได้รับการยืนยันแล้ว",
    });
    
    setTimeout(() => {
      onPaymentComplete();
      onOpenChange(false);
      resetDialog();
    }, 2000);
  };

  const handleCashierReject = () => {
    setPaymentStatus('rejected');
    
    // ลบข้อมูลจาก localStorage
    if (order?.id) {
      removePendingPayment(order.id);
    }
    
    toast({
      title: "ปฏิเสธการชำระเงิน",
      description: "สลิปไม่ถูกต้อง กรุณาลองใหม่",
      variant: "destructive"
    });
  };

  const resetDialog = () => {
    setPaymentStatus('pending');
    setCountdown(600);
    setSlipImage(null);
    setSlipPreview('');
    
    // ลบข้อมูลจาก localStorage เมื่อรีเซ็ต
    if (order?.id) {
      removePendingPayment(order.id);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[90vh] p-0">
        <DialogHeader className="p-6 pb-4 border-b">
          <DialogTitle className="text-center flex items-center justify-center gap-2">
            <QrCode className="h-6 w-6 text-blue-600" />
            ชำระเงินด้วย QR Code
          </DialogTitle>
        </DialogHeader>

        <ScrollArea className="max-h-[calc(90vh-100px)]">
          <div className="p-6 space-y-6">
            {/* Order Summary - ติดด้านบน */}
            <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-4 border border-blue-200 sticky top-0 z-10">
              <h3 className="font-semibold mb-2 text-blue-800">{order?.order_number}</h3>
              <div className="text-3xl font-bold text-green-600 text-center">
                ฿{order?.total_amount?.toLocaleString()}
              </div>
            </div>

            {/* Payment Status */}
            <div className="text-center">
              {paymentStatus === 'pending' && (
                <Badge variant="outline" className="mb-4 px-4 py-2">
                  <Clock className="h-4 w-4 mr-2" />
                  รอการชำระเงิน
                </Badge>
              )}
              {paymentStatus === 'slip_uploaded' && (
                <Badge className="mb-4 bg-orange-500 px-4 py-2">
                  <Upload className="h-4 w-4 mr-2" />
                  รอการยืนยันจากแคชเชียร์
                </Badge>
              )}
              {paymentStatus === 'confirmed' && (
                <Badge className="mb-4 bg-green-500 px-4 py-2">
                  <CheckCircle className="h-4 w-4 mr-2" />
                  ยืนยันการชำระเงินแล้ว
                </Badge>
              )}
              {paymentStatus === 'rejected' && (
                <Badge variant="destructive" className="mb-4 px-4 py-2">
                  <X className="h-4 w-4 mr-2" />
                  ปฏิเสธการชำระเงิน
                </Badge>
              )}
            </div>

            {/* QR Code Display */}
            {(paymentStatus === 'pending' || paymentStatus === 'slip_uploaded') && (
              <div className="bg-white border-2 border-dashed border-gray-300 rounded-lg p-4">
                <div className="text-center">
                  <div className="bg-white rounded-lg mb-4 flex justify-center p-4">
                    <img 
                      src="/lovable-uploads/2b69bb4e-7a75-4024-9bf4-cd4eb348b11a.png" 
                      alt="QR Code สำหรับชำระเงิน" 
                      className="w-48 h-48 md:w-64 md:h-64 object-contain rounded-lg shadow-lg"
                    />
                  </div>
                  <div className="space-y-2">
                    <div className="text-sm font-medium text-gray-700">
                      เลขอ้างอิง: <span className="font-mono bg-gray-100 px-2 py-1 rounded text-xs">{order?.order_number}</span>
                    </div>
                    <div className="text-xs text-gray-500">
                      สแกน QR Code เพื่อชำระเงิน
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Countdown Timer - แสดงอยู่เสมอเมื่อรอชำระ */}
            {(paymentStatus === 'pending' || paymentStatus === 'slip_uploaded') && (
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-3">
                <p className="text-orange-800 font-medium text-center">
                  หมดเวลาใน: <span className="font-mono text-lg">{formatTime(countdown)}</span>
                </p>
              </div>
            )}

            {/* Slip Upload Section - ปรับปรุงให้ใช้งานง่าย */}
            {paymentStatus === 'pending' && (
              <div className="space-y-4">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <Camera className="h-5 w-5 text-blue-600" />
                    <Label className="text-sm font-medium text-blue-800">
                      อัพโหลดสลิปการโอนเงิน
                    </Label>
                    <span className="text-red-500 text-sm">*</span>
                  </div>
                  
                  <div className="relative">
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={handleSlipUpload}
                      className="file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                    />
                  </div>
                  
                  <p className="text-xs text-blue-600 mt-2 flex items-center gap-1">
                    <Upload className="h-3 w-3" />
                    รองรับไฟล์ภาพ ขนาดไม่เกิน 5MB
                  </p>
                </div>
              </div>
            )}

            {/* Slip Preview - ปรับให้แสดงดีขึ้น */}
            {slipPreview && (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  <Label className="text-sm font-medium text-green-700">สลิปที่อัพโหลดแล้ว:</Label>
                </div>
                <div className="border-2 border-green-200 rounded-lg p-3 bg-green-50">
                  <img 
                    src={slipPreview} 
                    alt="สลิปการโอนเงิน" 
                    className="w-full max-h-64 object-contain rounded-lg shadow-md"
                  />
                </div>
                
                {paymentStatus === 'slip_uploaded' && (
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                    <p className="text-yellow-800 text-sm text-center font-medium">
                      ✅ ส่งคำขอยืนยันแล้ว รอแคชเชียร์ตรวจสอบ...
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Success Animation */}
            {paymentStatus === 'confirmed' && (
              <div className="text-center">
                <div className="bg-green-50 rounded-lg p-6">
                  <CheckCircle className="h-20 w-20 mx-auto text-green-500 mb-4 animate-bounce" />
                  <p className="text-green-600 font-bold text-lg">ยืนยันการชำระเงินสำเร็จ!</p>
                  <p className="text-green-600 text-sm">กำลังปิดหน้าต่าง...</p>
                </div>
              </div>
            )}

            {/* Rejection Message */}
            {paymentStatus === 'rejected' && (
              <div className="text-center">
                <div className="bg-red-50 rounded-lg p-6">
                  <AlertCircle className="h-16 w-16 mx-auto text-red-500 mb-4" />
                  <p className="text-red-600 font-bold">การชำระเงินไม่สำเร็จ</p>
                  <p className="text-red-600 text-sm">กรุณาตรวจสอบสลิปและลองใหม่</p>
                </div>
              </div>
            )}

            {/* Cashier Actions */}
            {paymentStatus === 'slip_uploaded' && isCashier && (
              <div className="space-y-3 border-t pt-4">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <p className="text-blue-800 font-medium text-center flex items-center justify-center gap-2">
                    🔐 <span>แคชเชียร์: ตรวจสอบสลิปและยืนยันการชำระเงิน</span>
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <Button 
                    variant="destructive"
                    onClick={handleCashierReject}
                    className="h-12"
                  >
                    <X className="h-4 w-4 mr-2" />
                    ปฏิเสธ
                  </Button>
                  <Button 
                    onClick={handleCashierConfirm}
                    className="h-12 bg-green-500 hover:bg-green-600"
                  >
                    <CheckCircle className="h-4 w-4 mr-2" />
                    ยืนยัน
                  </Button>
                </div>
              </div>
            )}

            {/* Non-cashier waiting message */}
            {paymentStatus === 'slip_uploaded' && !isCashier && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <p className="text-yellow-800 text-center flex items-center justify-center gap-2">
                  <Clock className="h-4 w-4 animate-spin" />
                  รอการยืนยันจากแคชเชียร์...
                </p>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Fixed Bottom Actions */}
        <div className="p-4 border-t bg-white">
          {/* Customer Actions */}
          {paymentStatus === 'pending' && (
            <Button 
              variant="outline" 
              onClick={() => onOpenChange(false)}
              className="w-full h-12"
            >
              <X className="h-4 w-4 mr-2" />
              ยกเลิก
            </Button>
          )}

          {/* Reset Actions */}
          {paymentStatus === 'rejected' && (
            <div className="grid grid-cols-2 gap-3">
              <Button 
                variant="outline" 
                onClick={() => onOpenChange(false)}
                className="h-12"
              >
                ปิด
              </Button>
              <Button 
                onClick={resetDialog}
                className="h-12 bg-blue-500 hover:bg-blue-600"
              >
                ลองใหม่
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default QRPaymentDialog;
