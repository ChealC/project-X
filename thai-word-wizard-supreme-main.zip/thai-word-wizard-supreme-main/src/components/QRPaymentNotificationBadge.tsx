
import { Bell, AlertCircle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useQRPaymentNotifications } from '@/hooks/useQRPaymentNotifications';
import { useAuth } from '@/contexts/AuthContext';

interface QRPaymentNotificationBadgeProps {
  className?: string;
  onNotificationClick?: () => void;
}

const QRPaymentNotificationBadge = ({ className, onNotificationClick }: QRPaymentNotificationBadgeProps) => {
  const { user } = useAuth();
  const { pendingCount } = useQRPaymentNotifications();

  // Only show for admin and manager
  const canApprovePayments = user?.role === 'admin' || user?.role === 'manager';

  if (!canApprovePayments || pendingCount === 0) {
    return null;
  }

  return (
    <Button
      variant="outline"
      size="sm"
      className={`relative ${className}`}
      onClick={onNotificationClick}
    >
      <Bell className="h-4 w-4 mr-2" />
      สลิปรอยืนยัน
      <Badge 
        variant="destructive" 
        className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 text-xs"
      >
        {pendingCount}
      </Badge>
    </Button>
  );
};

export default QRPaymentNotificationBadge;
