
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { supabase } from '@/integrations/supabase/client';
import { Users, Bell, CheckCircle, Clock, Plus, AlertCircle, Coffee, Receipt, UtensilsCrossed } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';

const MobileServiceSystem = () => {
  const [selectedTable, setSelectedTable] = useState<string>('');
  const [requestType, setRequestType] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user, hasPermission } = useAuth();

  // ตรวจสอบสิทธิ์การเข้าถึง
  if (!hasPermission('mobile', 'view')) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardContent className="text-center py-8">
            <AlertCircle className="h-16 w-16 mx-auto text-red-500 mb-4" />
            <h2 className="text-xl font-semibold text-gray-700 mb-2">
              ไม่มีสิทธิ์เข้าถึง
            </h2>
            <p className="text-gray-500">
              คุณไม่มีสิทธิ์ในการเข้าถึงระบบบริการมือถือ
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { data: tables } = useQuery({
    queryKey: ['service-tables'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('tables')
        .select('*')
        .order('table_number');
      
      if (error) throw error;
      return data;
    }
  });

  const { data: requests } = useQuery({
    queryKey: ['service-requests'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('service_requests')
        .select(`
          *,
          tables(table_number),
          staff(name)
        `)
        .in('status', ['pending', 'in_progress'])
        .order('priority', { ascending: false })
        .order('requested_at', { ascending: true });
      
      if (error) throw error;
      return data;
    }
  });

  const { data: staff } = useQuery({
    queryKey: ['service-staff'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('staff')
        .select('*')
        .eq('is_active', true)
        .in('position', ['waiter', 'waitress', 'server'])
        .order('name');
      
      if (error) throw error;
      return data;
    }
  });

  const createRequest = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from('service_requests')
        .insert({
          table_id: selectedTable,
          request_type: requestType,
          description: description || null,
          priority: requestType === 'urgent' ? 3 : requestType === 'complaint' ? 2 : 1
        });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['service-requests'] });
      setSelectedTable('');
      setRequestType('');
      setDescription('');
      setIsCreateDialogOpen(false);
      toast({
        title: "สร้างคำขอบริการสำเร็จ",
        description: "บันทึกคำขอบริการเรียบร้อยแล้ว"
      });
    }
  });

  const updateRequestStatus = useMutation({
    mutationFn: async ({ requestId, status, staffId }: { requestId: string; status: string; staffId?: string }) => {
      const updateData: any = { status };
      
      if (status === 'completed') {
        updateData.completed_at = new Date().toISOString();
      }

      if (staffId) {
        updateData.assigned_to = staffId;
      }

      const { error } = await supabase
        .from('service_requests')
        .update(updateData)
        .eq('id', requestId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['service-requests'] });
      toast({
        title: "อัพเดทสถานะสำเร็จ",
        description: "บันทึกสถานะคำขอบริการเรียบร้อยแล้ว"
      });
    }
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-500';
      case 'in_progress': return 'bg-blue-500';
      case 'completed': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'รอดำเนินการ';
      case 'in_progress': return 'กำลังดำเนินการ';
      case 'completed': return 'เสร็จแล้ว';
      default: return status;
    }
  };

  const getPriorityColor = (priority: number) => {
    if (priority >= 3) return 'bg-red-500';
    if (priority >= 2) return 'bg-orange-500';
    return 'bg-green-500';
  };

  const getRequestTypeText = (type: string) => {
    const types: { [key: string]: string } = {
      'water': 'ขอน้ำ',
      'menu': 'ขอเมนู',
      'bill': 'ขอบิล',
      'assistance': 'ขอความช่วยเหลือ',
      'complaint': 'ร้องเรียน',
      'urgent': 'เร่งด่วน',
      'cleaning': 'ทำความสะอาด'
    };
    return types[type] || type;
  };

  const getRequestTypeIcon = (type: string) => {
    switch (type) {
      case 'water': return <Coffee className="h-5 w-5" />;
      case 'bill': return <Receipt className="h-5 w-5" />;
      case 'menu': return <UtensilsCrossed className="h-5 w-5" />;
      default: return <Bell className="h-5 w-5" />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile-Optimized Header - Fixed */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10 shadow-sm">
        <div className="p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <div className="bg-blue-100 p-2 rounded-full">
                <Users className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-800">ระบบบริการ</h1>
                <p className="text-sm text-gray-600">{user?.staff_name}</p>
              </div>
            </div>
            
            {hasPermission('mobile', 'edit') && (
              <div className="bg-green-100 rounded-full">
                <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
                  <DialogTrigger asChild>
                    <Button size="sm" className="h-12 w-12 rounded-full bg-green-500 hover:bg-green-600 p-0">
                      <Plus className="h-6 w-6" />
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-sm mx-4 rounded-lg">
                    <DialogHeader>
                      <DialogTitle className="text-lg">สร้างคำขอบริการ</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 pt-2">
                      <div>
                        <label className="text-sm font-medium text-gray-700 mb-2 block">เลือกโต๊ะ</label>
                        <Select value={selectedTable} onValueChange={setSelectedTable}>
                          <SelectTrigger className="h-12 text-base">
                            <SelectValue placeholder="เลือกโต๊ะ" />
                          </SelectTrigger>
                          <SelectContent>
                            {tables?.map((table) => (
                              <SelectItem key={table.id} value={table.id} className="text-base py-3">
                                โต๊ะ {table.table_number}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-sm font-medium text-gray-700 mb-2 block">ประเภทคำขอ</label>
                        <Select value={requestType} onValueChange={setRequestType}>
                          <SelectTrigger className="h-12 text-base">
                            <SelectValue placeholder="ประเภทคำขอ" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="water" className="text-base py-3">🥤 ขอน้ำ</SelectItem>
                            <SelectItem value="menu" className="text-base py-3">📋 ขอเมนู</SelectItem>
                            <SelectItem value="bill" className="text-base py-3">🧾 ขอบิล</SelectItem>
                            <SelectItem value="assistance" className="text-base py-3">🙋 ขอความช่วยเหลือ</SelectItem>
                            <SelectItem value="complaint" className="text-base py-3">😞 ร้องเรียน</SelectItem>
                            <SelectItem value="urgent" className="text-base py-3">🚨 เร่งด่วน</SelectItem>
                            <SelectItem value="cleaning" className="text-base py-3">🧹 ทำความสะอาด</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-sm font-medium text-gray-700 mb-2 block">รายละเอียด</label>
                        <Textarea
                          placeholder="รายละเอียดเพิ่มเติม (ถ้ามี)"
                          value={description}
                          onChange={(e) => setDescription(e.target.value)}
                          className="h-24 resize-none text-base"
                        />
                      </div>

                      <Button
                        className="w-full h-12 text-base font-medium"
                        onClick={() => createRequest.mutate()}
                        disabled={!selectedTable || !requestType || createRequest.isPending}
                      >
                        {createRequest.isPending ? 'กำลังสร้าง...' : 'สร้างคำขอ'}
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            )}
          </div>
          
          {/* Status Summary Cards */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
              <div className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-yellow-600" />
                <div>
                  <div className="text-lg font-bold text-yellow-800">
                    {requests?.filter(r => r.status === 'pending').length || 0}
                  </div>
                  <div className="text-xs text-yellow-600">คำขอรอ</div>
                </div>
              </div>
            </div>
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <div className="flex items-center gap-2">
                <Users className="h-5 w-5 text-blue-600" />
                <div>
                  <div className="text-lg font-bold text-blue-800">
                    {requests?.filter(r => r.status === 'in_progress').length || 0}
                  </div>
                  <div className="text-xs text-blue-600">กำลังทำ</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Request List - Mobile Optimized */}
      <div className="p-4 space-y-4 pb-24">
        {requests?.length === 0 ? (
          <Card className="mt-8">
            <CardContent className="text-center py-12">
              <div className="bg-gray-100 w-20 h-20 rounded-full mx-auto mb-4 flex items-center justify-center">
                <Bell className="h-10 w-10 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium text-gray-700 mb-2">ไม่มีคำขอบริการ</h3>
              <p className="text-gray-500">คำขอบริการจะแสดงที่นี่เมื่อมีการร้องขอ</p>
            </CardContent>
          </Card>
        ) : (
          requests?.map((request) => (
            <Card key={request.id} className="border-l-4 border-l-blue-500 shadow-sm">
              <CardContent className="p-4">
                <div className="space-y-4">
                  {/* Header with Icon and Table */}
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-3">
                      <div className="bg-blue-100 p-2 rounded-full">
                        {getRequestTypeIcon(request.request_type)}
                      </div>
                      <div>
                        <h4 className="font-bold text-lg text-gray-800">
                          โต๊ะ {request.tables?.table_number}
                        </h4>
                        <p className="text-base font-medium text-blue-600">
                          {getRequestTypeText(request.request_type)}
                        </p>
                      </div>
                    </div>
                    <div className="flex flex-col gap-2">
                      <Badge className={`${getStatusColor(request.status)} text-white text-xs px-3 py-1`}>
                        {getStatusText(request.status)}
                      </Badge>
                      <Badge className={`${getPriorityColor(request.priority || 1)} text-white text-xs px-3 py-1`}>
                        {request.priority === 3 ? 'เร่งด่วน' : 
                         request.priority === 2 ? 'สำคัญ' : 'ปกติ'}
                      </Badge>
                    </div>
                  </div>

                  {/* Description */}
                  {request.description && (
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-sm text-gray-700">{request.description}</p>
                    </div>
                  )}

                  {/* Time and Staff Info */}
                  <div className="text-sm text-gray-500 space-y-2">
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4" />
                      <span>{new Date(request.requested_at).toLocaleString('th-TH')}</span>
                    </div>
                    {request.staff && (
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4" />
                        <span>ผู้รับผิดชอบ: {request.staff.name}</span>
                      </div>
                    )}
                  </div>

                  {/* Action Buttons */}
                  {hasPermission('mobile', 'edit') && (
                    <div className="pt-2">
                      {request.status === 'pending' && (
                        <div className="space-y-2">
                          <label className="text-sm font-medium text-gray-700">มอบหมายงานให้:</label>
                          <Select 
                            onValueChange={(staffId) => 
                              updateRequestStatus.mutate({ 
                                requestId: request.id, 
                                status: 'in_progress',
                                staffId 
                              })
                            }
                          >
                            <SelectTrigger className="h-12 text-base">
                              <SelectValue placeholder="เลือกพนักงาน" />
                            </SelectTrigger>
                            <SelectContent>
                              {staff?.map((member) => (
                                <SelectItem key={member.id} value={member.id} className="text-base py-3">
                                  {member.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      )}
                      {request.status === 'in_progress' && (
                        <Button
                          className="w-full h-12 text-base font-medium bg-green-600 hover:bg-green-700"
                          onClick={() => updateRequestStatus.mutate({ 
                            requestId: request.id, 
                            status: 'completed' 
                          })}
                        >
                          <CheckCircle className="h-5 w-5 mr-2" />
                          เสร็จแล้ว
                        </Button>
                      )}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};

export default MobileServiceSystem;
