import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, Plus, Edit, Trash2, AlertTriangle, Shield, UserPlus } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import BulkUserAccountCreation from './BulkUserAccountCreation';

const StaffManagementFull = () => {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedStaff, setSelectedStaff] = useState<any>(null);
  const [isAddingBulk, setIsAddingBulk] = useState(false);
  
  // Form state
  const [staffForm, setStaffForm] = useState({
    name: '',
    position: '',
    employee_id: '',
    hourly_rate: 50
  });

  const { toast } = useToast();
  const { hasPermission } = useAuth();
  const queryClient = useQueryClient();

  // Pre-defined staff list
  const newStaffList = [
    { name: 'ชลดา แสงตาเนตร', position: 'พนักงานบริการ', employee_id: 'SRV-001' },
    { name: 'ศราวุฒิ วงค์คำแก้ว', position: 'พนักงานบริการ', employee_id: 'SRV-002' },
    { name: 'รณกร​ แก้วชาติ', position: 'พนักงานครัว', employee_id: 'KIT-001' },
    { name: 'สมพร หรดี', position: 'พนักงานครัว', employee_id: 'KIT-002' },
    { name: 'ธนพล เหลือผล', position: 'พนักงานครัว', employee_id: 'KIT-003' },
    { name: 'ปฏิมา ทองศรีจันทร์', position: 'พนักงานบริการ', employee_id: 'SRV-003' },
    { name: 'สมุทรสาคร วุฒิยากรณ์', position: 'พนักงานครัว', employee_id: 'KIT-004' },
    { name: 'สมร ศรีหวาด', position: 'พนักงานบริการ', employee_id: 'SRV-004' },
    { name: 'ศักดิ์สยาม กองสุนทร', position: 'พนักงานครัว', employee_id: 'KIT-005' },
    { name: 'Siriporn', position: 'พนักงานบริการ', employee_id: 'SRV-005' },
  ];

  const { data: staff, refetch } = useQuery({
    queryKey: ['staff-full'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('staff')
        .select('*')
        .eq('is_active', true)
        .order('name');
      
      if (error) throw error;
      return data;
    }
  });

  const addBulkStaffMutation = useMutation({
    mutationFn: async () => {
      console.log('=== เริ่มเพิ่มพนักงานทั้งหมด ===');
      
      const staffData = newStaffList.map(staff => ({
        name: staff.name,
        position: staff.position,
        employee_id: staff.employee_id,
        hourly_rate: 50,
        is_active: true
      }));

      console.log('Staff data to insert:', staffData);

      const { data, error } = await supabase
        .from('staff')
        .insert(staffData)
        .select('*');
      
      if (error) {
        console.error('Insert error:', error);
        throw error;
      }
      
      console.log('Insert successful:', data);
      return data;
    },
    onSuccess: (data) => {
      console.log('✅ เพิ่มพนักงานสำเร็จ:', data);
      toast({
        title: "เพิ่มพนักงานสำเร็จ",
        description: `เพิ่มพนักงานใหม่ ${data.length} คนแล้ว`
      });
      refetch();
    },
    onError: (error: any) => {
      console.error('❌ เพิ่มพนักงานไม่สำเร็จ:', error);
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const addStaffMutation = useMutation({
    mutationFn: async (staffData: any) => {
      const { error } = await supabase
        .from('staff')
        .insert({
          name: staffData.name,
          position: staffData.position,
          employee_id: staffData.employee_id,
          hourly_rate: staffData.hourly_rate,
          is_active: true
        });
      
      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: "เพิ่มพนักงานสำเร็จ",
        description: "ข้อมูลพนักงานใหม่ได้ถูกเพิ่มแล้ว"
      });
      setIsAddDialogOpen(false);
      resetForm();
      refetch();
    },
    onError: (error: any) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const editStaffMutation = useMutation({
    mutationFn: async ({ id, ...staffData }: any) => {
      const { error } = await supabase
        .from('staff')
        .update(staffData)
        .eq('id', id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: "แก้ไขข้อมูลสำเร็จ",
        description: "ข้อมูลพนักงานได้ถูกอัปเดตแล้ว"
      });
      setIsEditDialogOpen(false);
      setSelectedStaff(null);
      resetForm();
      refetch();
    },
    onError: (error: any) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const deleteStaffMutation = useMutation({
    mutationFn: async (staffId: string) => {
      const { error } = await supabase
        .from('staff')
        .update({
          is_active: false
        })
        .eq('id', staffId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: "ลบพนักงานสำเร็จ",
        description: "ข้อมูลพนักงานได้ถูกปิดการใช้งานแล้ว"
      });
      setIsDeleteDialogOpen(false);
      setSelectedStaff(null);
      refetch();
    },
    onError: (error: any) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const resetForm = () => {
    setStaffForm({
      name: '',
      position: '',
      employee_id: '',
      hourly_rate: 50
    });
  };

  const handleAddBulkStaff = () => {
    setIsAddingBulk(true);
    addBulkStaffMutation.mutate();
    setTimeout(() => setIsAddingBulk(false), 2000);
  };

  const handleAddStaff = () => {
    if (!staffForm.name || !staffForm.position || !staffForm.employee_id) {
      toast({
        title: "กรุณากรอกข้อมูลให้ครบถ้วน",
        variant: "destructive"
      });
      return;
    }

    addStaffMutation.mutate({
      name: staffForm.name,
      position: staffForm.position,
      employee_id: staffForm.employee_id,
      hourly_rate: staffForm.hourly_rate
    });
  };

  const handleEditStaff = () => {
    if (!staffForm.name || !staffForm.position || !staffForm.employee_id) {
      toast({
        title: "กรุณากรอกข้อมูลให้ครบถ้วน",
        variant: "destructive"
      });
      return;
    }

    editStaffMutation.mutate({
      id: selectedStaff.id,
      name: staffForm.name,
      position: staffForm.position,
      employee_id: staffForm.employee_id,
      hourly_rate: staffForm.hourly_rate
    });
  };

  const openEditDialog = (staff: any) => {
    setSelectedStaff(staff);
    setStaffForm({
      name: staff.name,
      position: staff.position,
      employee_id: staff.employee_id,
      hourly_rate: staff.hourly_rate || 50
    });
    setIsEditDialogOpen(true);
  };

  const openDeleteDialog = (staff: any) => {
    setSelectedStaff(staff);
    setIsDeleteDialogOpen(true);
  };

  if (!hasPermission('staff', 'view')) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <Shield className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600">ไม่มีสิทธิ์ในการจัดการพนักงาน</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            จัดการข้อมูลพนักงาน
          </CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="staff-list" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="staff-list">รายการพนักงาน</TabsTrigger>
            <TabsTrigger value="create-accounts">สร้างบัญชีผู้ใช้</TabsTrigger>
          </TabsList>
          
          <TabsContent value="staff-list" className="space-y-6">
            {/* เนื้อหาเดิมของการจัดการพนักงาน */}
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">จัดการข้อมูลพนักงาน</h3>
              {hasPermission('staff', 'edit') && (
                <div className="flex gap-2">
                  <Button
                    onClick={handleAddBulkStaff}
                    disabled={isAddingBulk || addBulkStaffMutation.isPending}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    <UserPlus className="w-4 h-4 mr-2" />
                    {isAddingBulk ? 'กำลังเพิ่ม...' : 'เพิ่มพนักงาน 10 คน'}
                  </Button>
                  <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="w-4 h-4 mr-2" />
                        เพิ่มพนักงานใหม่
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>เพิ่มพนักงานใหม่</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4 pt-4">
                        <div className="space-y-2">
                          <Label htmlFor="employee-id">รหัสพนักงาน</Label>
                          <Input
                            id="employee-id"
                            value={staffForm.employee_id}
                            onChange={(e) => setStaffForm({...staffForm, employee_id: e.target.value})}
                            placeholder="เช่น EMP-SRV-006"
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="name">ชื่อ-นามสกุล</Label>
                          <Input
                            id="name"
                            value={staffForm.name}
                            onChange={(e) => setStaffForm({...staffForm, name: e.target.value})}
                            placeholder="กรอกชื่อ-นามสกุล"
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="position">ตำแหน่ง</Label>
                          <Select 
                            value={staffForm.position} 
                            onValueChange={(value) => setStaffForm({...staffForm, position: value})}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="เลือกตำแหน่ง" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="ผู้จัดการ">ผู้จัดการ</SelectItem>
                              <SelectItem value="หัวหน้าแผนกบริการ">หัวหน้าแผนกบริการ</SelectItem>
                              <SelectItem value="พนักงานบริการ">พนักงานบริการ</SelectItem>
                              <SelectItem value="แคชเชียร์">แคชเชียร์</SelectItem>
                              <SelectItem value="หัวหน้าแผนกครัว">หัวหน้าแผนกครัว</SelectItem>
                              <SelectItem value="พนักงานครัว">พนักงานครัว</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="hourly-rate">ค่าแรงต่อชั่วโมง (บาท)</Label>
                          <Input
                            id="hourly-rate"
                            type="number"
                            value={staffForm.hourly_rate}
                            onChange={(e) => setStaffForm({...staffForm, hourly_rate: Number(e.target.value)})}
                            placeholder="50"
                          />
                        </div>

                        <div className="flex gap-2 pt-4">
                          <Button onClick={handleAddStaff} className="flex-1" disabled={addStaffMutation.isPending}>
                            {addStaffMutation.isPending ? 'กำลังเพิ่ม...' : 'เพิ่มพนักงาน'}
                          </Button>
                          <Button variant="outline" onClick={() => {setIsAddDialogOpen(false); resetForm();}} className="flex-1">
                            ยกเลิก
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              )}
            </div>

            {/* Show preview of staff to be added */}
            {hasPermission('staff', 'edit') && (
              <Card className="mb-6 border-green-200 bg-green-50">
                <CardHeader>
                  <CardTitle className="text-green-800 flex items-center gap-2">
                    <UserPlus className="w-5 h-5" />
                    รายชื่อพนักงานที่จะเพิ่ม ({newStaffList.length} คน)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {newStaffList.map((staff, index) => (
                      <div key={index} className="flex justify-between items-center p-3 bg-white rounded border">
                        <div>
                          <div className="font-medium">{staff.name}</div>
                          <div className="text-sm text-gray-600">{staff.position}</div>
                          <div className="text-xs text-gray-500">รหัส: {staff.employee_id}</div>
                        </div>
                        <Badge variant="outline" className="text-green-700 border-green-300">
                          พร้อมเพิ่ม
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            <div className="space-y-4">
              {staff?.map((employee) => (
                <Card key={employee.id} className="p-4">
                  <div className="flex justify-between items-center">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold">{employee.name}</h3>
                        <Badge variant="outline">{employee.position}</Badge>
                      </div>
                      <p className="text-sm text-gray-600">รหัสพนักงาน: {employee.employee_id}</p>
                      <p className="text-sm text-gray-600">ค่าแรง: ฿{employee.hourly_rate}/ชม.</p>
                      <p className="text-xs text-gray-500">
                        สร้างเมื่อ: {new Date(employee.created_at).toLocaleDateString('th-TH')}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={employee.is_active ? "default" : "secondary"}>
                        {employee.is_active ? "ทำงานอยู่" : "ออกจากงาน"}
                      </Badge>
                      {hasPermission('staff', 'edit') && (
                        <div className="flex gap-1">
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => openEditDialog(employee)}
                          >
                            <Edit className="w-3 h-3" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => openDeleteDialog(employee)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                </Card>
              ))}

              {!staff?.length && (
                <p className="text-center text-gray-500 py-8">ไม่มีข้อมูลพนักงาน</p>
              )}
            </div>
          </TabsContent>

          <TabsContent value="create-accounts" className="space-y-6">
            <BulkUserAccountCreation />
          </TabsContent>
        </Tabs>

        {/* Edit Staff Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>แก้ไขข้อมูลพนักงาน</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label htmlFor="edit-employee-id">รหัสพนักงาน</Label>
                <Input
                  id="edit-employee-id"
                  value={staffForm.employee_id}
                  onChange={(e) => setStaffForm({...staffForm, employee_id: e.target.value})}
                  placeholder="เช่น EMP-SRV-006"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="edit-name">ชื่อ-นามสกุล</Label>
                <Input
                  id="edit-name"
                  value={staffForm.name}
                  onChange={(e) => setStaffForm({...staffForm, name: e.target.value})}
                  placeholder="กรอกชื่อ-นามสกุล"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="edit-position">ตำแหน่ง</Label>
                <Select 
                  value={staffForm.position} 
                  onValueChange={(value) => setStaffForm({...staffForm, position: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="เลือกตำแหน่ง" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ผู้จัดการ">ผู้จัดการ</SelectItem>
                    <SelectItem value="หัวหน้าแผนกบริการ">หัวหน้าแผนกบริการ</SelectItem>
                    <SelectItem value="พนักงานบริการ">พนักงานบริการ</SelectItem>
                    <SelectItem value="แคชเชียร์">แคชเชียร์</SelectItem>
                    <SelectItem value="หัวหน้าแผนกครัว">หัวหน้าแผนกครัว</SelectItem>
                    <SelectItem value="พนักงานครัว">พนักงานครัว</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="edit-hourly-rate">ค่าแรงต่อชั่วโมง (บาท)</Label>
                <Input
                  id="edit-hourly-rate"
                  type="number"
                  value={staffForm.hourly_rate}
                  onChange={(e) => setStaffForm({...staffForm, hourly_rate: Number(e.target.value)})}
                  placeholder="50"
                />
              </div>

              <div className="flex gap-2 pt-4">
                <Button onClick={handleEditStaff} className="flex-1" disabled={editStaffMutation.isPending}>
                  {editStaffMutation.isPending ? 'กำลังบันทึก...' : 'บันทึกการแก้ไข'}
                </Button>
                <Button variant="outline" onClick={() => {setIsEditDialogOpen(false); resetForm();}} className="flex-1">
                  ยกเลิก
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Delete Staff Dialog */}
        <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-red-600">
                <AlertTriangle className="w-5 h-5" />
                ยืนยันการลบพนักงาน
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <p className="text-sm text-gray-600">
                คุณต้องการลบข้อมูลพนักงาน <strong>{selectedStaff?.name}</strong> หรือไม่?
              </p>
              <p className="text-sm text-red-600">
                การดำเนินการนี้จะปิดการใช้งานพนักงานและไม่สามารถกู้คืนได้
              </p>

              <div className="flex gap-2 pt-4">
                <Button 
                  onClick={() => deleteStaffMutation.mutate(selectedStaff?.id)} 
                  variant="destructive" 
                  className="flex-1"
                  disabled={deleteStaffMutation.isPending}
                >
                  {deleteStaffMutation.isPending ? 'กำลังลบ...' : 'ลบพนักงาน'}
                </Button>
                <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)} className="flex-1">
                  ยกเลิก
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
};

export default StaffManagementFull;
