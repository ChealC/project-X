
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

interface NavItem {
  id: string;
  label: string;
  icon: any;
}

interface MainNavProps {
  className?: string;
  items: NavItem[];
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export function MainNav({ className, items, activeTab, setActiveTab }: MainNavProps) {
  return (
    <nav className={cn("flex flex-col space-y-2", className)}>
      {items.map((item) => (
        <Button
          key={item.id}
          variant={activeTab === item.id ? "default" : "ghost"}
          className="justify-start"
          onClick={() => setActiveTab(item.id)}
        >
          <item.icon className="mr-2 h-4 w-4" />
          {item.label}
        </Button>
      ))}
    </nav>
  );
}
