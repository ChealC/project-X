
import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import UserMenu from '@/components/UserMenu';
import {
  LayoutDashboard,
  ListChecks,
  ShoppingCart,
  Utensils,
  Coins,
  Menu,
  Boxes,
  BarChart,
  Users,
  Receipt,
  Activity,
  User,
  Shield,
  Smartphone,
  UserCheck
} from 'lucide-react';
import QRPaymentNotificationBadge from './QRPaymentNotificationBadge';

interface NavigationTabsProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const NavigationTabs = ({ activeTab, onTabChange }: NavigationTabsProps) => {
  const { user } = useAuth();
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  const handlePaymentNotificationClick = () => {
    onTabChange('payment');
  };

  const tabs = [
    { id: 'tables', label: 'จัดการโต๊ะ', icon: LayoutDashboard },
    { id: 'orders', label: 'ระบบสั่งอาหาร', icon: ShoppingCart },
    { id: 'kitchen', label: 'ระบบครัว', icon: Utensils },
    { id: 'payment', label: 'ระบบชำระเงิน', icon: Coins },
    { id: 'cash', label: 'ลิ้นชักเงินสด', icon: Receipt },
    { id: 'menu', label: 'จัดการเมนู', icon: Menu },
    { id: 'stock', label: 'จัดการคลัง', icon: Boxes },
    { id: 'reports', label: 'รายงานการขาย', icon: BarChart },
  ];

  const adminTabs = [
    { id: 'staff-data', label: 'จัดการพนักงาน', icon: Users },
    { id: 'user-accounts', label: 'รายการบัญชีผู้ใช้', icon: UserCheck },
    { id: 'activity', label: 'บันทึกกิจกรรม', icon: Activity },
    { id: 'accounts', label: 'ตั้งค่าบัญชี', icon: User },
    { id: 'security', label: 'ระบบรักษาความปลอดภัย', icon: Shield },
    { id: 'mobile', label: 'ระบบบริการโมบาย', icon: Smartphone },
  ];

  // Check if user has admin role
  const isAdmin = user?.role === 'admin' || user?.role === 'manager';

  return (
    <div className="bg-white shadow-sm border-b">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between py-3">
          <div className="flex items-center space-x-1">
            <UserMenu />
            <div className="flex space-x-1 overflow-x-auto">
              {tabs.map((tab) => (
                <Button
                  key={tab.id}
                  variant={activeTab === tab.id ? "default" : "ghost"}
                  size="sm"
                  onClick={() => onTabChange(tab.id)}
                  className="flex items-center gap-2 whitespace-nowrap"
                >
                  <tab.icon className="h-4 w-4" />
                  {tab.label}
                </Button>
              ))}
              {isAdmin && (
                <Button
                  variant={activeTab === 'admin' ? "default" : "ghost"}
                  size="sm"
                  onClick={toggleDropdown}
                  className="flex items-center gap-2 whitespace-nowrap"
                >
                  <ListChecks className="h-4 w-4" />
                  จัดการระบบ
                </Button>
              )}
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <QRPaymentNotificationBadge 
              onNotificationClick={handlePaymentNotificationClick}
            />
          </div>
        </div>
      </div>
      {isAdmin && isDropdownOpen && (
        <div className="bg-gray-100 border-b">
          <div className="container mx-auto px-4 py-2 flex space-x-2 overflow-x-auto">
            {adminTabs.map((tab) => (
              <Button
                key={tab.id}
                variant={activeTab === tab.id ? "default" : "ghost"}
                size="sm"
                onClick={() => onTabChange(tab.id)}
                className="flex items-center gap-2 whitespace-nowrap"
              >
                <tab.icon className="h-4 w-4" />
                {tab.label}
              </Button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default NavigationTabs;
