
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase } from '@/integrations/supabase/client';
import { CreditCard, Banknote, QrCode, DollarSign, Clock, CheckCircle, Lock, AlertTriangle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import QRPaymentDialog from './QRPaymentDialog';
import { useAuth } from '@/contexts/AuthContext';

const PaymentSystem = () => {
  const [selectedOrder, setSelectedOrder] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'credit_card' | 'qr_code'>('qr_code');
  const [receivedAmount, setReceivedAmount] = useState<number>(0);
  const [showQRDialog, setShowQRDialog] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();

  // Check if user can handle cash payments (only admin and manager)
  const canHandleCash = user?.role === 'admin' || user?.role === 'manager';

  // Get orders that are ready for payment
  const { data: pendingOrders } = useQuery({
    queryKey: ['orders-ready-for-payment'],
    queryFn: async () => {
      console.log('Fetching orders ready for payment...');
      const { data, error } = await supabase
        .from('orders')
        .select(`
          *,
          tables(table_number),
          order_items(*, menu_items(name)),
          takeaway_orders(customer_name, customer_phone),
          payments(id)
        `)
        .in('status', ['pending', 'preparing', 'ready', 'served'])
        .is('payments.id', null)
        .order('created_at', { ascending: true });
      
      if (error) {
        console.error('Error fetching orders for payment:', error);
        throw error;
      }
      
      console.log('Found orders ready for payment:', data);
      return data;
    }
  });

  const { data: currentShift } = useQuery({
    queryKey: ['current-cash-shift'],
    queryFn: async () => {
      if (!user?.staff_id || !canHandleCash) return null;
      
      const { data, error } = await supabase
        .from('cash_drawer_shifts')
        .select('*')
        .eq('status', 'open')
        .eq('shift_date', new Date().toISOString().split('T')[0])
        .eq('staff_id', user.staff_id)
        .maybeSingle();

      if (error) throw error;
      return data;
    },
    enabled: !!user?.staff_id && canHandleCash
  });

  const processPayment = useMutation({
    mutationFn: async ({ orderId, amount, received }: { orderId: string; amount: number; received: number }) => {
      console.log('Processing payment for order:', orderId);
      
      // Restrict cash payments to admin and manager only
      if (paymentMethod === 'cash' && !canHandleCash) {
        throw new Error('คุณไม่มีสิทธิ์รับชำระเงินสด กรุณาใช้วิธีการชำระเงินอื่น');
      }

      // For cash payments, check if there's an active shift
      if (paymentMethod === 'cash' && !currentShift) {
        throw new Error('ไม่พบกะที่เปิดอยู่ กรุณาเปิดกะลิ้นชักเงินสดก่อน');
      }

      const changeAmount = received - amount;

      // Create payment record
      const { error: paymentError } = await supabase
        .from('payments')
        .insert({
          order_id: orderId,
          payment_method: paymentMethod,
          amount,
          received_amount: received,
          change_amount: changeAmount > 0 ? changeAmount : 0,
          staff_id: user?.staff_id
        });

      if (paymentError) {
        console.error('Payment creation error:', paymentError);
        throw paymentError;
      }

      console.log('Payment recorded successfully');

      // If it's a cash payment, record it in the cash drawer
      if (paymentMethod === 'cash' && currentShift && user?.staff_id) {
        const { error: cashTransactionError } = await supabase
          .from('cash_drawer_transactions')
          .insert({
            shift_id: currentShift.id,
            transaction_type: 'sale',
            amount: amount,
            description: `ชำระเงินออเดอร์ ${pendingOrders?.find(o => o.id === orderId)?.order_number}`,
            reference_id: orderId,
            staff_id: user.staff_id
          });

        if (cashTransactionError) {
          console.error('Cash transaction error:', cashTransactionError);
          throw cashTransactionError;
        }

        console.log('Cash transaction recorded');
      }

      // Update order status to completed
      const { error: orderError } = await supabase
        .from('orders')
        .update({ 
          status: 'completed',
          updated_at: new Date().toISOString()
        })
        .eq('id', orderId);

      if (orderError) {
        console.error('Order update error:', orderError);
        throw orderError;
      }

      console.log('Order status updated to completed');

      // Update table status if dine-in
      const order = pendingOrders?.find(o => o.id === orderId);
      if (order?.order_type === 'dine-in' && order.table_id) {
        const { error: tableError } = await supabase
          .from('tables')
          .update({ status: 'cleaning' })
          .eq('id', order.table_id);

        if (tableError) {
          console.error('Table update error:', tableError);
          throw tableError;
        }

        console.log('Table status updated to cleaning');
      }

      return { changeAmount };
    },
    onSuccess: (data) => {
      console.log('Payment completed successfully');
      setSelectedOrder('');
      setReceivedAmount(0);
      queryClient.invalidateQueries({ queryKey: ['orders-ready-for-payment'] });
      queryClient.invalidateQueries({ queryKey: ['tables'] });
      queryClient.invalidateQueries({ queryKey: ['current-cash-shift'] });
      
      toast({
        title: "ชำระเงินสำเร็จ",
        description: paymentMethod === 'cash' 
          ? `เงินทอน: ฿${data.changeAmount.toFixed(2)} (บันทึกในลิ้นชักเงินสดแล้ว)`
          : `ชำระเงินเสร็จสิ้น`,
      });
    },
    onError: (error: any) => {
      console.error('Payment processing failed:', error);
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const selectedOrderData = pendingOrders?.find(order => order.id === selectedOrder);

  const handleQRPayment = () => {
    if (selectedOrderData) {
      setShowQRDialog(true);
    }
  };

  const handleQRPaymentComplete = () => {
    processPayment.mutate({
      orderId: selectedOrderData!.id,
      amount: selectedOrderData!.total_amount,
      received: selectedOrderData!.total_amount
    });
  };

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case 'ready': return 'bg-green-500 text-white';
      case 'served': return 'bg-purple-500 text-white';
      case 'preparing': return 'bg-yellow-500 text-white';
      case 'pending': return 'bg-orange-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'ready': return 'พร้อมเสิร์ฟ';
      case 'served': return 'เสิร์ฟแล้ว';
      case 'preparing': return 'กำลังทำ';
      case 'pending': return 'รอดำเนินการ';
      default: return status;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Section */}
      <div className="bg-gradient-to-r from-green-500 to-blue-500 rounded-2xl p-6 text-white">
        <h1 className="text-3xl font-bold mb-2">💳 ระบบชำระเงิน</h1>
        <p className="text-green-100">จัดการการชำระเงินสำหรับออเดอร์ทั้งหมดที่ยังไม่ได้ชำระ</p>
        
        {!canHandleCash && (
          <div className="mt-3 bg-white/20 rounded-lg p-3">
            <div className="flex items-center gap-2">
              <Lock className="h-4 w-4" />
              <p className="text-sm">🔒 คุณสามารถใช้บัตรเครดิตหรือ QR Code เท่านั้น</p>
            </div>
          </div>
        )}
        
        {canHandleCash && paymentMethod === 'cash' && currentShift && (
          <div className="mt-2 bg-white/20 rounded-lg p-3">
            <p className="text-sm">🏦 กะปัจจุบัน: เปิดด้วยเงิน ฿{currentShift.opening_amount.toLocaleString()}</p>
          </div>
        )}
        {canHandleCash && paymentMethod === 'cash' && !currentShift && (
          <div className="mt-2 bg-red-500/50 rounded-lg p-3">
            <p className="text-sm">⚠️ ไม่มีกะที่เปิดอยู่ - กรุณาเปิดกะลิ้นชักเงินสดก่อน</p>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Orders List */}
        <Card className="xl:col-span-2">
          <CardHeader className="bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-t-lg">
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              ออเดอร์ที่รอชำระเงิน ({pendingOrders?.length || 0})
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {pendingOrders?.map((order) => (
                <Card 
                  key={order.id} 
                  className={`cursor-pointer transition-all duration-200 hover:shadow-lg ${
                    selectedOrder === order.id ? 'ring-2 ring-blue-500 shadow-lg bg-blue-50' : 'hover:shadow-md'
                  }`}
                  onClick={() => setSelectedOrder(order.id)}
                >
                  <CardContent className="p-5">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h3 className="font-bold text-lg">{order.order_number}</h3>
                        <p className="text-sm text-gray-600 flex items-center gap-1">
                          {order.order_type === 'dine-in' ? (
                            <>🍽️ โต๊ะ {order.tables?.table_number}</>
                          ) : (
                            <>📦 {order.takeaway_orders?.[0]?.customer_name || 'ซื้อกลับ'}</>
                          )}
                        </p>
                      </div>
                      <Badge className={getStatusBadgeColor(order.status)}>
                        {getStatusText(order.status)}
                      </Badge>
                    </div>
                    
                    <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-lg p-3 mb-3 border border-green-200">
                      <div className="flex justify-between items-center">
                        <span className="text-2xl font-bold text-green-600">
                          ฿{order.total_amount?.toLocaleString()}
                        </span>
                        <span className="text-sm text-gray-500">
                          {order.order_items?.length} รายการ
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex justify-between items-center text-sm text-gray-600">
                      <span>⏰ {new Date(order.created_at).toLocaleTimeString('th-TH')}</span>
                      <span>👥 {order.customer_count} คน</span>
                    </div>
                  </CardContent>
                </Card>
              ))}

              {!pendingOrders?.length && (
                <div className="col-span-full text-center py-12">
                  <CheckCircle className="h-16 w-16 mx-auto text-gray-300 mb-4" />
                  <p className="text-gray-500 text-lg">ไม่มีออเดอร์ที่รอชำระเงิน</p>
                  <p className="text-gray-400 text-sm mt-2">ออเดอร์ที่ยังไม่ได้ชำระเงินจะปรากฏที่นี่</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Payment Processing */}
        <Card>
          <CardHeader className="bg-gradient-to-r from-green-500 to-blue-500 text-white rounded-t-lg">
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="h-5 w-5" />
              ระบบชำระเงิน
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-6">
            {selectedOrderData ? (
              <>
                {/* Order Summary */}
                <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-5 border border-blue-200">
                  <h3 className="font-bold text-lg mb-3 text-blue-800">{selectedOrderData.order_number}</h3>
                  <div className="space-y-2 text-sm">
                    {selectedOrderData.order_items?.map((item) => (
                      <div key={item.id} className="flex justify-between">
                        <span>{item.menu_items?.name} x{item.quantity}</span>
                        <span className="font-semibold">฿{item.total_price}</span>
                      </div>
                    ))}
                  </div>
                  <div className="border-t border-blue-200 mt-3 pt-3">
                    <div className="flex justify-between font-bold text-lg text-green-600">
                      <span>ยอดรวม:</span>
                      <span>฿{selectedOrderData.total_amount}</span>
                    </div>
                  </div>
                </div>

                {/* Permission Alert for non-cash users */}
                {!canHandleCash && (
                  <Alert>
                    <Lock className="h-4 w-4" />
                    <AlertDescription>
                      คุณสามารถใช้บัตรเครดิตหรือ QR Code เท่านั้น 
                      การรับชำระเงินสดจำกัดเฉพาะผู้จัดการและแอดมิน
                    </AlertDescription>
                  </Alert>
                )}

                {/* Payment Methods */}
                <div>
                  <label className="text-sm font-semibold mb-3 block">วิธีการชำระเงิน</label>
                  <Tabs value={paymentMethod} onValueChange={(value: any) => setPaymentMethod(value)}>
                    <TabsList className="grid grid-cols-3 w-full">
                      <TabsTrigger 
                        value="cash" 
                        className="flex items-center gap-2"
                        disabled={!canHandleCash}
                      >
                        <Banknote className="h-4 w-4" />
                        เงินสด
                      </TabsTrigger>
                      <TabsTrigger value="credit_card" className="flex items-center gap-2">
                        <CreditCard className="h-4 w-4" />
                        บัตร
                      </TabsTrigger>
                      <TabsTrigger value="qr_code" className="flex items-center gap-2">
                        <QrCode className="h-4 w-4" />
                        QR Code
                      </TabsTrigger>
                    </TabsList>
                  </Tabs>

                  {paymentMethod === 'cash' && canHandleCash && !currentShift && (
                    <div className="mt-2 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <p className="text-sm text-yellow-600">
                        ⚠️ ไม่มีกะที่เปิดอยู่ กรุณาเปิดกะลิ้นชักเงินสดในหน้าลิ้นชักเงินสดก่อน
                      </p>
                    </div>
                  )}
                </div>

                {/* Cash Payment Input */}
                {paymentMethod === 'cash' && canHandleCash && currentShift && (
                  <>
                    <div>
                      <label className="text-sm font-medium mb-2 block">จำนวนเงินที่รับ</label>
                      <Input
                        type="number"
                        placeholder="0.00"
                        value={receivedAmount || ''}
                        onChange={(e) => setReceivedAmount(Number(e.target.value))}
                        className="text-lg"
                      />
                      {receivedAmount > 0 && (
                        <div className="mt-2 p-3 bg-green-50 rounded-lg border border-green-200">
                          <p className="text-sm">
                            เงินทอน: <span className="font-bold text-green-600 text-lg">
                              ฿{Math.max(0, receivedAmount - selectedOrderData.total_amount).toFixed(2)}
                            </span>
                          </p>
                        </div>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      {[100, 200, 500, 1000].map((amount) => (
                        <Button
                          key={amount}
                          variant="outline"
                          size="sm"
                          onClick={() => setReceivedAmount(amount)}
                          className="text-sm"
                        >
                          ฿{amount}
                        </Button>
                      ))}
                    </div>
                  </>
                )}

                {/* Action Buttons */}
                <div className="space-y-3">
                  {paymentMethod === 'qr_code' ? (
                    <Button
                      className="w-full bg-green-500 hover:bg-green-600 text-white"
                      onClick={handleQRPayment}
                      size="lg"
                    >
                      <QrCode className="h-5 w-5 mr-2" />
                      แสดง QR Code
                    </Button>
                  ) : (
                    <Button
                      className="w-full bg-blue-500 hover:bg-blue-600 text-white"
                      onClick={() => processPayment.mutate({
                        orderId: selectedOrderData.id,
                        amount: selectedOrderData.total_amount,
                        received: paymentMethod === 'cash' ? receivedAmount : selectedOrderData.total_amount
                      })}
                      disabled={
                        processPayment.isPending || 
                        (paymentMethod === 'cash' && (!canHandleCash || !currentShift || receivedAmount < selectedOrderData.total_amount))
                      }
                      size="lg"
                    >
                      {processPayment.isPending ? 'กำลังประมวลผล...' : 'ชำระเงิน'}
                    </Button>
                  )}
                </div>
              </>
            ) : (
              <div className="text-center py-12">
                <DollarSign className="h-16 w-16 mx-auto text-gray-300 mb-4" />
                <p className="text-gray-500">เลือกออเดอร์เพื่อชำระเงิน</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* QR Payment Dialog */}
      {selectedOrderData && (
        <QRPaymentDialog
          order={selectedOrderData}
          open={showQRDialog}
          onOpenChange={setShowQRDialog}
          onPaymentComplete={handleQRPaymentComplete}
        />
      )}
    </div>
  );
};

export default PaymentSystem;
