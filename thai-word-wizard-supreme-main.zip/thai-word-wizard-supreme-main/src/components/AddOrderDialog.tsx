
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { Tables } from '@/integrations/supabase/types';
import { Plus, Minus, ShoppingCart, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface AddOrderDialogProps {
  table: Tables<'tables'>;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  specialInstructions?: string;
}

const AddOrderDialog = ({ table, open, onOpenChange }: AddOrderDialogProps) => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orderNotes, setOrderNotes] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: menuCategories } = useQuery({
    queryKey: ['menu-categories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('menu_categories')
        .select('*, menu_items(*)')
        .eq('is_active', true)
        .order('sort_order');
      
      if (error) throw error;
      return data;
    }
  });

  const { data: existingOrder } = useQuery({
    queryKey: ['table-order', table.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .eq('table_id', table.id)
        .eq('status', 'pending')
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      
      if (error) throw error;
      return data;
    },
    enabled: open && table.status === 'occupied'
  });

  const addToExistingOrder = useMutation({
    mutationFn: async () => {
      if (!existingOrder) {
        throw new Error('ไม่พบออเดอร์ที่เปิดอยู่');
      }

      // Create order items for additional items
      const orderItems = cart.map(item => ({
        order_id: existingOrder.id,
        menu_item_id: item.id,
        quantity: item.quantity,
        unit_price: item.price,
        total_price: item.price * item.quantity,
        special_instructions: item.specialInstructions
      }));

      const { error: itemsError } = await supabase
        .from('order_items')
        .insert(orderItems);

      if (itemsError) throw itemsError;

      // Update order totals
      const additionalSubtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
      const additionalTax = additionalSubtotal * 0.07;
      const newSubtotal = existingOrder.subtotal + additionalSubtotal;
      const newTaxAmount = existingOrder.tax_amount + additionalTax;
      const newTotalAmount = newSubtotal + newTaxAmount;

      const { error: orderError } = await supabase
        .from('orders')
        .update({
          subtotal: newSubtotal,
          tax_amount: newTaxAmount,
          total_amount: newTotalAmount,
          notes: orderNotes ? `${existingOrder.notes || ''}\n${orderNotes}` : existingOrder.notes,
          updated_at: new Date().toISOString()
        })
        .eq('id', existingOrder.id);

      if (orderError) throw orderError;

      return existingOrder;
    },
    onSuccess: () => {
      setCart([]);
      setOrderNotes('');
      onOpenChange(false);
      queryClient.invalidateQueries({ queryKey: ['table-order', table.id] });
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      toast({
        title: "เพิ่มอาหารสำเร็จ",
        description: `เพิ่มอาหารลงในออเดอร์โต๊ะ ${table.table_number} แล้ว`
      });
    }
  });

  const addToCart = (menuItem: any) => {
    const existingItem = cart.find(item => item.id === menuItem.id);
    if (existingItem) {
      setCart(cart.map(item => 
        item.id === menuItem.id 
          ? { ...item, quantity: item.quantity + 1 }
          : item
      ));
    } else {
      setCart([...cart, {
        id: menuItem.id,
        name: menuItem.name,
        price: menuItem.price,
        quantity: 1
      }]);
    }
  };

  const updateQuantity = (id: string, quantity: number) => {
    if (quantity === 0) {
      setCart(cart.filter(item => item.id !== id));
    } else {
      setCart(cart.map(item => 
        item.id === id ? { ...item, quantity } : item
      ));
    }
  };

  const updateSpecialInstructions = (id: string, instructions: string) => {
    setCart(cart.map(item => 
      item.id === id ? { ...item, specialInstructions: instructions } : item
    ));
  };

  const calculateTotal = () => {
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const tax = subtotal * 0.07;
    return { subtotal, tax, total: subtotal + tax };
  };

  const { subtotal, tax, total } = calculateTotal();

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>เพิ่มอาหาร - โต๊ะ {table.table_number}</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Menu Section */}
          <div className="lg:col-span-2">
            <Tabs defaultValue={menuCategories?.[0]?.id} className="space-y-4">
              <TabsList className="grid w-full" style={{gridTemplateColumns: `repeat(${menuCategories?.length || 1}, 1fr)`}}>
                {menuCategories?.map((category) => (
                  <TabsTrigger key={category.id} value={category.id} className="text-sm">
                    {category.name}
                  </TabsTrigger>
                ))}
              </TabsList>

              {menuCategories?.map((category) => (
                <TabsContent key={category.id} value={category.id} className="mt-6">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    {category.menu_items?.map((item) => (
                      <Card key={item.id} className="cursor-pointer hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <h3 className="font-semibold mb-1">{item.name}</h3>
                          <p className="text-sm text-gray-600 mb-3 line-clamp-2">{item.description}</p>
                          <div className="flex justify-between items-center">
                            <span className="text-lg font-bold text-green-600">
                              ฿{item.price}
                            </span>
                            <Button 
                              size="sm" 
                              onClick={() => addToCart(item)}
                              disabled={!item.is_available}
                              className="bg-green-500 hover:bg-green-600"
                            >
                              <Plus className="h-4 w-4" />
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
              ))}
            </Tabs>
          </div>

          {/* Cart Section */}
          <div>
            <Card className="sticky top-4">
              <CardContent className="p-4 space-y-4">
                <div className="flex items-center gap-2">
                  <ShoppingCart className="h-5 w-5" />
                  <span className="font-semibold">รายการเพิ่ม ({cart.length} รายการ)</span>
                </div>

                {/* Cart Items */}
                <div className="space-y-2 max-h-80 overflow-y-auto">
                  {cart.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <ShoppingCart className="h-12 w-12 mx-auto mb-2 opacity-50" />
                      <p>ไม่มีรายการที่เลือก</p>
                    </div>
                  ) : (
                    cart.map((item) => (
                      <div key={item.id} className="border rounded-lg p-3 space-y-2 bg-gray-50">
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <h4 className="font-medium text-sm">{item.name}</h4>
                            <p className="text-sm text-gray-600">฿{item.price}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => updateQuantity(item.id, item.quantity - 1)}
                              className="h-8 w-8 p-0"
                            >
                              <Minus className="h-3 w-3" />
                            </Button>
                            <span className="w-8 text-center font-medium">{item.quantity}</span>
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => updateQuantity(item.id, item.quantity + 1)}
                              className="h-8 w-8 p-0"
                            >
                              <Plus className="h-3 w-3" />
                            </Button>
                            <Button 
                              size="sm" 
                              variant="destructive"
                              onClick={() => updateQuantity(item.id, 0)}
                              className="h-8 w-8 p-0 ml-2"
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                        <Textarea
                          placeholder="หมายเหตุพิเศษ..."
                          value={item.specialInstructions || ''}
                          onChange={(e) => updateSpecialInstructions(item.id, e.target.value)}
                          className="text-sm"
                          rows={2}
                        />
                      </div>
                    ))
                  )}
                </div>

                {/* Order Notes */}
                <div>
                  <Label>หมายเหตุเพิ่มเติม</Label>
                  <Textarea
                    placeholder="หมายเหตุสำหรับรายการเพิ่ม..."
                    value={orderNotes}
                    onChange={(e) => setOrderNotes(e.target.value)}
                    rows={3}
                  />
                </div>

                {/* Order Summary */}
                {cart.length > 0 && (
                  <div className="border-t pt-4 space-y-3">
                    <div className="bg-blue-50 rounded-lg p-3 space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>ยอดรวม:</span>
                        <span>฿{subtotal.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>ภาษี (7%):</span>
                        <span>฿{tax.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between font-bold text-lg text-green-600 border-t pt-2">
                        <span>ยอดรวมเพิ่ม:</span>
                        <span>฿{total.toFixed(2)}</span>
                      </div>
                    </div>
                    <Button 
                      className="w-full bg-blue-500 hover:bg-blue-600" 
                      onClick={() => addToExistingOrder.mutate()}
                      disabled={addToExistingOrder.isPending}
                      size="lg"
                    >
                      {addToExistingOrder.isPending ? 'กำลังเพิ่ม...' : 'เพิ่มลงในออเดอร์'}
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default AddOrderDialog;
