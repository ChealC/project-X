import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/integrations/supabase/client';
import { Users, Clock, LogIn, LogOut } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import UserAccountManagement from './UserAccountManagement';
import UserAccountsList from './UserAccountsList';

const StaffManagement = () => {
  const [selectedStaff, setSelectedStaff] = useState<string>('');
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();

  const { data: staff } = useQuery({
    queryKey: ['staff'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('staff')
        .select('*')
        .eq('is_active', true)
        .order('name');
      
      if (error) throw error;
      return data;
    }
  });

  const { data: todayShifts } = useQuery({
    queryKey: ['today-shifts'],
    queryFn: async () => {
      const today = new Date().toISOString().split('T')[0];
      const { data, error } = await supabase
        .from('staff_shifts')
        .select('*, staff(name, position)')
        .eq('shift_date', today)
        .order('clock_in', { ascending: false });
      
      if (error) throw error;
      return data;
    }
  });

  const clockIn = useMutation({
    mutationFn: async (staffId: string) => {
      const today = new Date().toISOString().split('T')[0];
      const now = new Date().toISOString();

      // Check if already clocked in today without clock out
      const { data: existingShift } = await supabase
        .from('staff_shifts')
        .select('*')
        .eq('staff_id', staffId)
        .eq('shift_date', today)
        .is('clock_out', null)
        .maybeSingle();

      if (existingShift) {
        throw new Error('พนักงานคนนี้ได้ลงเวลาเข้างานแล้ว');
      }

      const { error } = await supabase
        .from('staff_shifts')
        .insert({
          staff_id: staffId,
          shift_date: today,
          clock_in: now
        });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['today-shifts'] });
      toast({
        title: "ลงเวลาเข้างานสำเร็จ",
        description: "บันทึกเวลาเข้างานแล้ว"
      });
    },
    onError: (error) => {
      toast({
        title: "ข้อผิดพลาด",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const clockOut = useMutation({
    mutationFn: async (staffId: string) => {
      const today = new Date().toISOString().split('T')[0];
      const now = new Date().toISOString();

      console.log('Attempting to clock out staff:', staffId, 'on date:', today);

      // Find today's active shift (clock_in exists, clock_out is null)
      const { data: shift, error: findError } = await supabase
        .from('staff_shifts')
        .select('*')
        .eq('staff_id', staffId)
        .eq('shift_date', today)
        .not('clock_in', 'is', null)
        .is('clock_out', null)
        .maybeSingle();

      console.log('Found shift:', shift, 'Find error:', findError);

      if (findError) {
        throw new Error('เกิดข้อผิดพลาดในการค้นหาข้อมูลการเข้างาน');
      }

      if (!shift) {
        throw new Error('ไม่พบข้อมูลการเข้างานวันนี้ หรือได้ออกงานแล้ว');
      }

      // Calculate total hours
      const clockInTime = new Date(shift.clock_in);
      const clockOutTime = new Date(now);
      const totalHours = (clockOutTime.getTime() - clockInTime.getTime()) / (1000 * 60 * 60);

      console.log('Updating shift with clock_out time and total hours:', totalHours);

      const { error: updateError } = await supabase
        .from('staff_shifts')
        .update({
          clock_out: now,
          total_hours: Math.round(totalHours * 100) / 100
        })
        .eq('id', shift.id);

      if (updateError) {
        console.error('Update error:', updateError);
        throw new Error('เกิดข้อผิดพลาดในการบันทึกเวลาออกงาน');
      }

      console.log('Clock out successful');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['today-shifts'] });
      toast({
        title: "ลงเวลาออกงานสำเร็จ",
        description: "บันทึกเวลาออกงานแล้ว"
      });
    },
    onError: (error) => {
      console.error('Clock out mutation error:', error);
      toast({
        title: "ข้อผิดพลาด",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const getStaffStatus = (staffId: string) => {
    const shift = todayShifts?.find(s => s.staff_id === staffId && s.clock_in && !s.clock_out);
    return shift ? 'working' : 'off';
  };

  const formatTime = (timeString: string) => {
    return new Date(timeString).toLocaleTimeString('th-TH', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Filter staff based on user role - non-admin can only see themselves
  const getCurrentUserStaff = () => {
    if (user?.role === 'admin' || user?.role === 'manager') {
      return staff; // Admin and manager can see all staff
    }
    // Other roles can only see themselves
    return staff?.filter(s => s.id === user?.staff_id) || [];
  };

  const visibleStaff = getCurrentUserStaff();

  return (
    <div className="h-[calc(100vh-140px)]">
      <Tabs defaultValue="shifts" className="w-full h-full flex flex-col">
        <TabsList className="grid w-full grid-cols-2 mb-3">
          <TabsTrigger value="shifts">การลงเวลา</TabsTrigger>
          {(user?.role === 'admin' || user?.role === 'manager') && (
            <TabsTrigger value="accounts">บัญชีผู้ใช้</TabsTrigger>
          )}
        </TabsList>
        
        <TabsContent value="shifts" className="flex-1 min-h-0">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-full">
            {/* Staff List */}
            <Card className="h-full">
              <CardHeader className="p-4">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Users className="h-5 w-5" />
                  {(user?.role === 'admin' || user?.role === 'manager') ? 'รายชื่อพนักงาน' : 'การลงเวลาของฉัน'}
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4 h-[calc(100%-80px)] overflow-y-auto">
                <div className="space-y-3">
                  {visibleStaff?.length ? visibleStaff.map((employee) => {
                    const status = getStaffStatus(employee.id);
                    const todayShift = todayShifts?.find(s => s.staff_id === employee.id && s.clock_in && !s.clock_out);
                    
                    return (
                      <Card key={employee.id} className="p-3">
                        <div className="flex justify-between items-center">
                          <div>
                            <h3 className="font-semibold text-sm">{employee.name}</h3>
                            <p className="text-xs text-gray-600">{employee.position}</p>
                            <p className="text-xs text-gray-600">รหัส: {employee.employee_id}</p>
                            {employee.hourly_rate && (
                              <p className="text-xs text-gray-600">ค่าแรง: ฿{employee.hourly_rate}/ชม.</p>
                            )}
                          </div>
                          <div className="flex flex-col items-end gap-2">
                            <Badge className={status === 'working' ? 'bg-green-500 text-xs' : 'bg-gray-500 text-xs'}>
                              {status === 'working' ? 'กำลังทำงาน' : 'ไม่ได้ทำงาน'}
                            </Badge>
                            
                            {status === 'working' && todayShift && (
                              <p className="text-xs text-gray-600">
                                เข้างาน: {formatTime(todayShift.clock_in)}
                              </p>
                            )}

                            <div className="flex gap-2">
                              {status === 'off' ? (
                                <Button
                                  size="sm"
                                  onClick={() => clockIn.mutate(employee.id)}
                                  disabled={clockIn.isPending}
                                  className="h-7 text-xs"
                                >
                                  <LogIn className="h-3 w-3 mr-1" />
                                  เข้างาน
                                </Button>
                              ) : (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => clockOut.mutate(employee.id)}
                                  disabled={clockOut.isPending}
                                  className="h-7 text-xs"
                                >
                                  <LogOut className="h-3 w-3 mr-1" />
                                  ออกงาน
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      </Card>
                    );
                  }) : (
                    <div className="text-center py-8">
                      <p className="text-gray-500">ไม่มีข้อมูลพนักงาน</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Today's Shifts */}
            <Card className="h-full">
              <CardHeader className="p-4">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Clock className="h-5 w-5" />
                  การทำงานวันนี้
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4 h-[calc(100%-80px)] overflow-y-auto">
                <div className="space-y-3">
                  {todayShifts?.filter(shift => 
                    user?.role === 'admin' || user?.role === 'manager' || shift.staff_id === user?.staff_id
                  ).length ? todayShifts.filter(shift => 
                    user?.role === 'admin' || user?.role === 'manager' || shift.staff_id === user?.staff_id
                  ).map((shift) => (
                    <Card key={shift.id} className="p-3">
                      <div className="flex justify-between items-center">
                        <div>
                          <h3 className="font-semibold text-sm">{shift.staff?.name}</h3>
                          <p className="text-xs text-gray-600">{shift.staff?.position}</p>
                        </div>
                        <div className="text-right">
                          {shift.clock_in && (
                            <p className="text-xs">
                              เข้า: {formatTime(shift.clock_in)}
                            </p>
                          )}
                          {shift.clock_out ? (
                            <>
                              <p className="text-xs">
                                ออก: {formatTime(shift.clock_out)}
                              </p>
                              <p className="text-xs font-semibold">
                                รวม: {shift.total_hours} ชม.
                              </p>
                            </>
                          ) : shift.clock_in ? (
                            <Badge className="bg-green-500 text-xs">กำลังทำงาน</Badge>
                          ) : (
                            <Badge className="bg-gray-500 text-xs">ยังไม่เข้างาน</Badge>
                          )}
                        </div>
                      </div>
                    </Card>
                  )) : (
                    <p className="text-center text-gray-500 py-8 text-sm">ไม่มีข้อมูลการทำงานวันนี้</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        {(user?.role === 'admin' || user?.role === 'manager') && (
          <TabsContent value="accounts" className="flex-1">
            <UserAccountsList />
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
};

export default StaffManagement;
