
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { BarChart3, TrendingUp, DollarSign, ShoppingCart } from 'lucide-react';

const SalesReport = () => {
  const { data: todaySales } = useQuery({
    queryKey: ['today-sales'],
    queryFn: async () => {
      const today = new Date().toISOString().split('T')[0];
      
      // Get today's completed orders
      const { data: orders, error } = await supabase
        .from('orders')
        .select(`
          *,
          order_items(*, menu_items(name, category_id)),
          payments(*)
        `)
        .eq('status', 'completed')
        .gte('created_at', `${today}T00:00:00`)
        .lt('created_at', `${today}T23:59:59`);

      if (error) throw error;

      const totalOrders = orders.length;
      const totalRevenue = orders.reduce((sum, order) => sum + (order.total_amount || 0), 0);
      const totalTax = orders.reduce((sum, order) => sum + (order.tax_amount || 0), 0);
      const totalDiscount = orders.reduce((sum, order) => sum + (order.discount_amount || 0), 0);
      
      const cashPayments = orders.reduce((sum, order) => {
        const cashAmount = order.payments
          ?.filter(p => p.payment_method === 'cash')
          .reduce((s, p) => s + p.amount, 0) || 0;
        return sum + cashAmount;
      }, 0);

      const cardPayments = orders.reduce((sum, order) => {
        const cardAmount = order.payments
          ?.filter(p => ['credit_card', 'debit_card'].includes(p.payment_method))
          .reduce((s, p) => s + p.amount, 0) || 0;
        return sum + cardAmount;
      }, 0);

      return {
        totalOrders,
        totalRevenue,
        totalTax,
        totalDiscount,
        cashPayments,
        cardPayments,
        orders
      };
    }
  });

  const { data: topSellingItems } = useQuery({
    queryKey: ['top-selling-items'],
    queryFn: async () => {
      const today = new Date().toISOString().split('T')[0];
      
      const { data, error } = await supabase
        .from('order_items')
        .select(`
          quantity,
          menu_items(name, price),
          orders!inner(created_at, status)
        `)
        .eq('orders.status', 'completed')
        .gte('orders.created_at', `${today}T00:00:00`)
        .lt('orders.created_at', `${today}T23:59:59`);

      if (error) throw error;

      // Group by menu item and sum quantities
      const itemSales = data.reduce((acc, item) => {
        const itemName = item.menu_items?.name || 'Unknown';
        if (!acc[itemName]) {
          acc[itemName] = {
            name: itemName,
            quantity: 0,
            revenue: 0,
            price: item.menu_items?.price || 0
          };
        }
        acc[itemName].quantity += item.quantity;
        acc[itemName].revenue += item.quantity * (item.menu_items?.price || 0);
        return acc;
      }, {} as Record<string, any>);

      return Object.values(itemSales)
        .sort((a: any, b: any) => b.quantity - a.quantity)
        .slice(0, 10);
    }
  });

  const { data: hourlyStats } = useQuery({
    queryKey: ['hourly-stats'],
    queryFn: async () => {
      const today = new Date().toISOString().split('T')[0];
      
      const { data, error } = await supabase
        .from('orders')
        .select('created_at, total_amount')
        .eq('status', 'completed')
        .gte('created_at', `${today}T00:00:00`)
        .lt('created_at', `${today}T23:59:59`)
        .order('created_at');

      if (error) throw error;

      // Group by hour
      const hourlyData = data.reduce((acc, order) => {
        const hour = new Date(order.created_at).getHours();
        if (!acc[hour]) {
          acc[hour] = { hour, orders: 0, revenue: 0 };
        }
        acc[hour].orders += 1;
        acc[hour].revenue += order.total_amount || 0;
        return acc;
      }, {} as Record<number, any>);

      return Object.values(hourlyData).sort((a: any, b: any) => a.hour - b.hour);
    }
  });

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">ยอดขายวันนี้</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ฿{todaySales?.totalRevenue?.toLocaleString() || 0}
            </div>
            <p className="text-xs text-muted-foreground">
              ภาษี: ฿{todaySales?.totalTax?.toLocaleString() || 0}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">จำนวนออเดอร์</CardTitle>
            <ShoppingCart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{todaySales?.totalOrders || 0}</div>
            <p className="text-xs text-muted-foreground">ออเดอร์ที่เสร็จสิ้น</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">เงินสด</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ฿{todaySales?.cashPayments?.toLocaleString() || 0}
            </div>
            <p className="text-xs text-muted-foreground">การชำระด้วยเงินสด</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">บัตร</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ฿{todaySales?.cardPayments?.toLocaleString() || 0}
            </div>
            <p className="text-xs text-muted-foreground">การชำระด้วยบัตร</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Selling Items */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              สินค้าขายดี (วันนี้)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {topSellingItems?.map((item: any, index: number) => (
                <div key={item.name} className="flex justify-between items-center p-3 border rounded">
                  <div className="flex items-center gap-3">
                    <Badge variant="outline">{index + 1}</Badge>
                    <div>
                      <h4 className="font-medium">{item.name}</h4>
                      <p className="text-sm text-gray-600">฿{item.price}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold">{item.quantity} ชิ้น</p>
                    <p className="text-sm text-gray-600">฿{item.revenue.toLocaleString()}</p>
                  </div>
                </div>
              ))}
              
              {!topSellingItems?.length && (
                <p className="text-center text-gray-500 py-8">ไม่มีข้อมูลการขาย</p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Hourly Sales */}
        <Card>
          <CardHeader>
            <CardTitle>ยอดขายตามชั่วโมง</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {hourlyStats?.map((stat: any) => (
                <div key={stat.hour} className="flex justify-between items-center p-2 border rounded">
                  <span className="font-medium">
                    {stat.hour.toString().padStart(2, '0')}:00
                  </span>
                  <div className="text-right">
                    <p className="font-bold">{stat.orders} ออเดอร์</p>
                    <p className="text-sm text-gray-600">฿{stat.revenue.toLocaleString()}</p>
                  </div>
                </div>
              ))}
              
              {!hourlyStats?.length && (
                <p className="text-center text-gray-500 py-8">ไม่มีข้อมูลการขาย</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default SalesReport;
