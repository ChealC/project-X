
import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { supabase } from '@/integrations/supabase/client';
import { Package, Plus } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useForm } from 'react-hook-form';

interface InventoryFormData {
  name: string;
  unit: string;
  min_stock: number;
  current_stock: number;
  cost_per_unit: number;
  supplier: string;
}

const InventoryForm = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const form = useForm<InventoryFormData>({
    defaultValues: {
      name: '',
      unit: '',
      min_stock: 0,
      current_stock: 0,
      cost_per_unit: 0,
      supplier: ''
    }
  });

  const addInventoryItem = useMutation({
    mutationFn: async (data: InventoryFormData) => {
      const { error } = await supabase
        .from('inventory_items')
        .insert(data);
      
      if (error) throw error;
    },
    onSuccess: () => {
      form.reset();
      setIsOpen(false);
      queryClient.invalidateQueries({ queryKey: ['inventory-items'] });
      toast({
        title: "เพิ่มวัตถุดิบสำเร็จ",
        description: "วัตถุดิบได้ถูกเพิ่มเข้าระบบแล้ว"
      });
    },
    onError: (error) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: "ไม่สามารถเพิ่มวัตถุดิบได้",
        variant: "destructive"
      });
    }
  });

  const predefinedIngredients = [
    { name: 'ปลาช่อน', unit: 'ตัว' },
    { name: 'ปลากะพง', unit: 'ตัว' },
    { name: 'ปลานิล', unit: 'ตัว' },
    { name: 'ปลาทับทิม', unit: 'ตัว' },
    { name: 'ปลาตะเพียน', unit: 'ตัว' },
    { name: 'ปลาน้ำเงิน', unit: 'โล' },
    { name: 'ปลาแดง', unit: 'โล' },
    { name: 'ปลาเนื้ออ่อน', unit: 'โล' },
    { name: 'ปลาคัง', unit: 'โล' },
    { name: 'ปลากด', unit: 'โล' },
    { name: 'ปลาบึก', unit: 'โล' },
    { name: 'ปลาค้าว', unit: 'โล' },
    { name: 'ปลากะทิง', unit: 'โล' },
    { name: 'ปลาบู่', unit: 'ตัว' },
    { name: 'ปลาแซลมอน', unit: 'โล' },
    { name: 'กุ้งแม่น้ำ', unit: 'โล' },
    { name: 'กุ้งเขียวใหญ่', unit: 'โล' },
    { name: 'กุ้งขาว', unit: 'โล' },
    { name: 'ปลาหมึกไข่', unit: 'โล' },
    { name: 'ปลาหมึก', unit: 'โล' },
    { name: 'ปูไข่', unit: 'โล' },
    { name: 'ปูนิ่ม', unit: 'แพ็ค' },
    { name: 'เนื้อก้ามปู', unit: 'แพ็ค' },
    { name: 'ปีกไก่', unit: 'โล' },
    { name: 'ไก่บ้าน', unit: 'โล' },
    { name: 'เนื้อเป็ดบด', unit: 'โล' },
    { name: 'หมูบด', unit: 'โล' },
    { name: 'หมูก้อน', unit: 'โล' },
    { name: 'หมูป่า', unit: 'โล' },
    { name: 'ลูกชิ้นปลา', unit: 'แพ็ค' },
    { name: 'เนื้อปลาบด', unit: 'แพ็ค' },
    { name: 'กบ', unit: 'โล' },
    { name: 'หอยขม', unit: 'โล' },
    { name: 'เต้าหู้ไข่หลอด', unit: 'แพ็ค' },
    { name: 'ต้นหอม', unit: 'โล' },
    { name: 'ผักชี', unit: 'โล' },
    { name: 'ต้งโอ๋', unit: 'โล' },
    { name: 'สะระแหน่', unit: 'โล' },
    { name: 'กระเพรา', unit: 'โล' },
    { name: 'โหรพา', unit: 'โล' },
    { name: 'แมงลัก', unit: 'โล' },
    { name: 'ผักชีฝรั่ง', unit: 'โล' },
    { name: 'ใบมะกรูด', unit: 'โล' },
    { name: 'ใบชะพลู', unit: 'โล' },
    { name: 'ผักกะเฉด', unit: 'โล' },
    { name: 'ผักกาดหอม', unit: 'โล' },
    { name: 'กรีนโอ็ค', unit: 'โล' },
    { name: 'เร็ดโอ็ค', unit: 'โล' },
    { name: 'ต้นอ่อนทานตะวัน', unit: 'โล' },
    { name: 'กระหล่ำ', unit: 'โล' },
    { name: 'กระหล่ำแดง', unit: 'โล' },
    { name: 'ผักกาดขาว', unit: 'โล' },
    { name: 'ยอดมะพร้าว', unit: 'โล' },
    { name: 'ยอดข้าวโพด', unit: 'โล' },
    { name: 'เห็ดหูหนู', unit: 'โล' },
    { name: 'เห็ดหอม', unit: 'โล' },
    { name: 'เห็ดนางฟ้า', unit: 'โล' },
    { name: 'เห็ดออริจิ', unit: 'โล' },
    { name: 'มะเขือยาว', unit: 'โล' },
    { name: 'มะเขือเปราะ', unit: 'โล' },
    { name: 'มะเขือพวง', unit: 'โล' },
    { name: 'มะเขือเทศลูกใหญ่', unit: 'โล' },
    { name: 'มะเขือเทศลูกเล็ก', unit: 'โล' },
    { name: 'มะระ', unit: 'โล' },
    { name: 'บวบ', unit: 'โล' },
    { name: 'แครอท', unit: 'โล' },
    { name: 'แตงล้าน', unit: 'โล' },
    { name: 'ถั่วพลู', unit: 'โล' },
    { name: 'ถั่วลันเตา', unit: 'โล' },
    { name: 'ถั่วฟักยาว', unit: 'โล' },
    { name: 'ฟักทอง', unit: 'โล' },
    { name: 'มะกอก', unit: 'โล' },
    { name: 'มะม่วงเปรี้ยว', unit: 'โล' },
    { name: 'มะละกอ', unit: 'โล' },
    { name: 'พริกขี้หนูแดงสด', unit: 'โล' },
    { name: 'พริกขี้หนูเขียวสด', unit: 'โล' },
    { name: 'พริกชี้ฟ้าแดง', unit: 'โล' },
    { name: 'พริกชี้ฟ้าแดงใหญ่', unit: 'โล' },
    { name: 'พริกหยวก', unit: 'โล' },
    { name: 'พริกไทสด', unit: 'โล' },
    { name: 'มะนาว', unit: 'โล' },
    { name: 'ขิงซอย', unit: 'โล' },
    { name: 'กะชายซอย', unit: 'โล' },
    { name: 'ข่า', unit: 'โล' },
    { name: 'หอมแดง', unit: 'โล' },
    { name: 'หอมใหญ่', unit: 'โล' },
    { name: 'กระเทียมกรีบใหญ่', unit: 'โล' },
    { name: 'กระเทียมกรีบเล็ก', unit: 'โล' },
    { name: 'ตระไคร้', unit: 'โล' },
    { name: 'ใบตอง', unit: 'โล' },
    { name: 'ใบเตย', unit: 'โล' },
    { name: 'มะพร้าวลูก', unit: 'โล' },
    { name: 'กระทิสด', unit: 'โล' },
    { name: 'บล็อกโคลี่', unit: 'โล' },
    { name: 'ยอดแม้ว', unit: 'โล' }
  ];

  const addBulkIngredients = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from('inventory_items')
        .insert(
          predefinedIngredients.map(ingredient => ({
            ...ingredient,
            min_stock: 5,
            current_stock: 0,
            cost_per_unit: 0
          }))
        );
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['inventory-items'] });
      toast({
        title: "เพิ่มวัตถุดิบทั้งหมดสำเร็จ",
        description: `เพิ่มวัตถุดิบ ${predefinedIngredients.length} รายการเข้าระบบแล้ว`
      });
    },
    onError: (error) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: "ไม่สามารถเพิ่มวัตถุดิบได้",
        variant: "destructive"
      });
    }
  });

  const onSubmit = (data: InventoryFormData) => {
    addInventoryItem.mutate(data);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Package className="h-5 w-5" />
          จัดการวัตถุดิบ
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex gap-2 mb-4">
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                เพิ่มวัตถุดิบใหม่
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>เพิ่มวัตถุดิบใหม่</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>ชื่อวัตถุดิบ</FormLabel>
                        <FormControl>
                          <Input {...field} required />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="unit"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>หน่วยนับ</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="เช่น โล, ตัว, แพ็ค" required />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="min_stock"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>จำนวนขั้นต่ำ</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            type="number" 
                            onChange={(e) => field.onChange(Number(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="current_stock"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>จำนวนปัจจุบัน</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            type="number" 
                            onChange={(e) => field.onChange(Number(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="cost_per_unit"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>ราคาต้นทุน/หน่วย</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            type="number" 
                            step="0.01"
                            onChange={(e) => field.onChange(Number(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="supplier"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>ผู้จำหน่าย</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit" 
                    className="w-full"
                    disabled={addInventoryItem.isPending}
                  >
                    {addInventoryItem.isPending ? 'กำลังเพิ่ม...' : 'เพิ่มวัตถุดิบ'}
                  </Button>
                </form>
              </Form>
            </DialogContent>
          </Dialog>

          <Button 
            variant="outline"
            onClick={() => addBulkIngredients.mutate()}
            disabled={addBulkIngredients.isPending}
          >
            {addBulkIngredients.isPending ? 'กำลังเพิ่ม...' : `เพิ่มวัตถุดิบทั้งหมด (${predefinedIngredients.length} รายการ)`}
          </Button>
        </div>

        <div className="text-sm text-gray-600">
          <p>รายการวัตถุดิบที่จะเพิ่ม: {predefinedIngredients.length} รายการ</p>
          <p>รวมปลา {predefinedIngredients.filter(i => i.name.includes('ปลา')).length} ชนิด, ผัก {predefinedIngredients.filter(i => i.name.includes('ผัก') || i.name.includes('มะ') || i.name.includes('ถั่ว')).length} ชนิด, เครื่องเทศ {predefinedIngredients.filter(i => i.name.includes('พริก') || i.name.includes('ข่า') || i.name.includes('กระเทียม')).length} ชนิด</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default InventoryForm;
