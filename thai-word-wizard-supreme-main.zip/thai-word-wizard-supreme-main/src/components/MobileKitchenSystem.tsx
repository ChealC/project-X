import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { ChefHat, Clock, Play, CheckCircle, Timer, AlertCircle, UtensilsCrossed } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';

const MobileKitchenSystem = () => {
  const [selectedStaff, setSelectedStaff] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user, hasPermission } = useAuth();

  // ตรวจสอบสิทธิ์การเข้าถึง
  if (!hasPermission('kitchen', 'view')) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardContent className="text-center py-8">
            <AlertCircle className="h-16 w-16 mx-auto text-red-500 mb-4" />
            <h2 className="text-xl font-semibold text-gray-700 mb-2">
              ไม่มีสิทธิ์เข้าถึง
            </h2>
            <p className="text-gray-500">
              คุณไม่มีสิทธิ์ในการเข้าถึงระบบครัว
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { data: staff } = useQuery({
    queryKey: ['kitchen-staff'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('staff')
        .select('*')
        .eq('is_active', true)
        .in('position', ['chef', 'cook', 'kitchen_assistant'])
        .order('name');
      
      if (error) throw error;
      return data;
    }
  });

  const { data: tasks } = useQuery({
    queryKey: ['kitchen-tasks'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('kitchen_tasks')
        .select(`
          *,
          order_items(
            *,
            menu_items(name),
            orders(
              order_number, 
              table_id, 
              tables(table_number)
            )
          ),
          staff(name)
        `)
        .in('status', ['pending', 'in_progress'])
        .order('priority', { ascending: false })
        .order('created_at', { ascending: true });
      
      if (error) throw error;
      return data;
    }
  });

  const { data: pendingOrderItems } = useQuery({
    queryKey: ['pending-order-items'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('order_items')
        .select(`
          *,
          menu_items(name, preparation_time),
          orders(
            order_number, 
            table_id, 
            tables(table_number)
          )
        `)
        .eq('status', 'pending')
        .order('created_at');
      
      if (error) throw error;
      return data;
    }
  });

  const createTask = useMutation({
    mutationFn: async ({ orderItemId, staffId }: { orderItemId: string; staffId: string }) => {
      const { error } = await supabase
        .from('kitchen_tasks')
        .insert({
          order_item_id: orderItemId,
          staff_id: staffId,
          task_type: 'prepare',
          status: 'pending'
        });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['kitchen-tasks'] });
      queryClient.invalidateQueries({ queryKey: ['pending-order-items'] });
      setSelectedStaff('');
      toast({
        title: "มอบหมายงานสำเร็จ",
        description: "ได้มอบหมายงานให้พนักงานแล้ว"
      });
    }
  });

  const updateTaskStatus = useMutation({
    mutationFn: async ({ taskId, status, notes }: { taskId: string; status: string; notes?: string }) => {
      const updateData: any = { status };
      
      if (status === 'in_progress') {
        updateData.started_at = new Date().toISOString();
      } else if (status === 'completed') {
        updateData.completed_at = new Date().toISOString();
      }

      if (notes) {
        updateData.notes = notes;
      }

      const { error } = await supabase
        .from('kitchen_tasks')
        .update(updateData)
        .eq('id', taskId);

      if (error) throw error;

      // Update order item status if task is completed
      if (status === 'completed') {
        const { data: task } = await supabase
          .from('kitchen_tasks')
          .select('order_item_id')
          .eq('id', taskId)
          .single();

        if (task) {
          await supabase
            .from('order_items')
            .update({ status: 'ready' })
            .eq('id', task.order_item_id);
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['kitchen-tasks'] });
      setNotes('');
      toast({
        title: "อัพเดทสถานะสำเร็จ",
        description: "บันทึกสถานะงานเรียบร้อยแล้ว"
      });
    }
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-500';
      case 'in_progress': return 'bg-blue-500';
      case 'completed': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'รอดำเนินการ';
      case 'in_progress': return 'กำลังทำ';
      case 'completed': return 'เสร็จแล้ว';
      default: return status;
    }
  };

  const getPriorityColor = (priority: number) => {
    if (priority >= 3) return 'bg-red-500';
    if (priority >= 2) return 'bg-orange-500';
    return 'bg-green-500';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile-Optimized Header - Fixed */}
      <div className="bg-white border-b border-gray-200 p-4 sticky top-0 z-10 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-orange-100 p-3 rounded-full">
              <ChefHat className="h-7 w-7 text-orange-600" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-800">ระบบครัวมือถือ</h1>
              <p className="text-sm text-gray-600">{user?.staff_name}</p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-lg font-bold text-orange-600">
              {pendingOrderItems?.length || 0}
            </div>
            <div className="text-xs text-gray-600">งานรอ</div>
          </div>
        </div>
        
        {/* Status Summary - Mobile Cards */}
        <div className="grid grid-cols-3 gap-3 mt-4">
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 text-center">
            <div className="text-lg font-bold text-yellow-800">
              {pendingOrderItems?.length || 0}
            </div>
            <div className="text-xs text-yellow-600">รอมอบหมาย</div>
          </div>
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-center">
            <div className="text-lg font-bold text-blue-800">
              {tasks?.filter(t => t.status === 'in_progress').length || 0}
            </div>
            <div className="text-xs text-blue-600">กำลังทำ</div>
          </div>
          <div className="bg-green-50 border border-green-200 rounded-lg p-3 text-center">
            <div className="text-lg font-bold text-green-800">
              {tasks?.filter(t => t.status === 'pending').length || 0}
            </div>
            <div className="text-xs text-green-600">รอเริ่ม</div>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-4 pb-24">
        {/* Pending Order Items - Mobile Optimized */}
        {pendingOrderItems && pendingOrderItems.length > 0 && (
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <AlertCircle className="h-6 w-6 text-yellow-500" />
                รายการใหม่ ({pendingOrderItems.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {pendingOrderItems.map((item) => (
                <Card key={item.id} className="bg-yellow-50 border-yellow-200 shadow-sm">
                  <CardContent className="p-4">
                    <div className="space-y-4">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h4 className="font-bold text-lg text-gray-800 mb-2">
                            {item.menu_items?.name}
                          </h4>
                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              <span className="bg-blue-100 text-blue-800 text-sm font-medium px-2 py-1 rounded">
                                ออเดอร์: {item.orders?.order_number}
                              </span>
                            </div>
                            {item.orders?.tables && (
                              <div className="flex items-center gap-2 text-blue-600 font-medium">
                                <UtensilsCrossed className="h-5 w-5" />
                                <span className="text-lg">โต๊ะ: {item.orders.tables.table_number}</span>
                              </div>
                            )}
                            <div className="flex items-center gap-2">
                              <span className="text-base font-medium">จำนวน: {item.quantity} รายการ</span>
                            </div>
                          </div>
                        </div>
                        <Badge className="bg-yellow-500 text-white text-sm px-3 py-1">
                          {item.menu_items?.preparation_time || 15} นาที
                        </Badge>
                      </div>
                      
                      {hasPermission('kitchen', 'edit') && (
                        <div className="space-y-3">
                          <label className="text-sm font-medium text-gray-700">มอบหมายให้พนักงาน:</label>
                          <Select value={selectedStaff} onValueChange={setSelectedStaff}>
                            <SelectTrigger className="h-12 text-base">
                              <SelectValue placeholder="เลือกพนักงาน" />
                            </SelectTrigger>
                            <SelectContent>
                              {staff?.map((member) => (
                                <SelectItem key={member.id} value={member.id} className="text-base py-3">
                                  {member.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <Button
                            className="w-full h-12 text-base font-medium"
                            onClick={() => createTask.mutate({ 
                              orderItemId: item.id, 
                              staffId: selectedStaff 
                            })}
                            disabled={!selectedStaff || createTask.isPending}
                          >
                            {createTask.isPending ? 'กำลังมอบหมาย...' : 'มอบหมายงาน'}
                          </Button>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </CardContent>
          </Card>
        )}

        {/* Active Tasks - Mobile Optimized */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <Timer className="h-6 w-6 text-blue-500" />
              งานที่กำลังดำเนินการ ({tasks?.length || 0})
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {tasks?.length === 0 ? (
              <div className="text-center py-12">
                <div className="bg-gray-100 w-20 h-20 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <ChefHat className="h-10 w-10 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium text-gray-700 mb-2">ไม่มีงานที่ต้องทำ</h3>
                <p className="text-gray-500">ครัวพร้อมรับงานใหม่</p>
              </div>
            ) : (
              tasks?.map((task) => (
                <Card key={task.id} className="border-l-4 border-l-blue-500 shadow-sm">
                  <CardContent className="p-4">
                    <div className="space-y-4">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h4 className="font-bold text-lg text-gray-800 mb-2">
                            {task.order_items?.menu_items?.name}
                          </h4>
                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              <span className="bg-blue-100 text-blue-800 text-sm font-medium px-2 py-1 rounded">
                                ออเดอร์: {task.order_items?.orders?.order_number}
                              </span>
                            </div>
                            {task.order_items?.orders?.tables && (
                              <div className="flex items-center gap-2 text-blue-600 font-medium">
                                <UtensilsCrossed className="h-5 w-5" />
                                <span className="text-lg">โต๊ะ: {task.order_items.orders.tables.table_number}</span>
                              </div>
                            )}
                            <div className="bg-gray-100 p-2 rounded text-sm">
                              <span className="font-medium">พนักงาน:</span> {task.staff?.name}
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-base font-medium">จำนวน: {task.order_items?.quantity} รายการ</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex flex-col gap-2">
                          <Badge className={getStatusColor(task.status) + ' text-white text-sm px-3 py-1'}>
                            {getStatusText(task.status)}
                          </Badge>
                          <Badge className={getPriorityColor(task.priority || 1) + ' text-white text-sm px-3 py-1'}>
                            ลำดับ {task.priority || 1}
                          </Badge>
                        </div>
                      </div>

                      {task.started_at && (
                        <div className="bg-blue-50 p-3 rounded-lg">
                          <div className="flex items-center gap-2 text-blue-700">
                            <Clock className="h-5 w-5" />
                            <span className="font-medium">เริ่มทำเมื่อ: </span>
                            <span>{new Date(task.started_at).toLocaleTimeString('th-TH')}</span>
                          </div>
                        </div>
                      )}

                      {hasPermission('kitchen', 'edit') && (
                        <div className="space-y-3">
                          {task.status === 'pending' && (
                            <Button
                              className="w-full h-12 text-base font-medium"
                              onClick={() => updateTaskStatus.mutate({ 
                                taskId: task.id, 
                                status: 'in_progress' 
                              })}
                              disabled={updateTaskStatus.isPending}
                            >
                              <Play className="h-5 w-5 mr-2" />
                              เริ่มทำงาน
                            </Button>
                          )}
                          
                          {task.status === 'in_progress' && (
                            <>
                              <Textarea
                                placeholder="หมายเหตุเพิ่มเติม (ถ้ามี)"
                                value={notes}
                                onChange={(e) => setNotes(e.target.value)}
                                className="h-20 resize-none text-base"
                              />
                              <Button
                                className="w-full h-12 text-base font-medium bg-green-600 hover:bg-green-700"
                                onClick={() => updateTaskStatus.mutate({ 
                                  taskId: task.id, 
                                  status: 'completed',
                                  notes
                                })}
                                disabled={updateTaskStatus.isPending}
                              >
                                <CheckCircle className="h-5 w-5 mr-2" />
                                เสร็จสิ้น
                              </Button>
                            </>
                          )}
                        </div>
                      )}

                      {task.notes && (
                        <div className="bg-amber-50 p-3 rounded-lg border border-amber-200">
                          <div className="font-medium text-amber-800 mb-1">หมายเหตุ:</div>
                          <div className="text-amber-700">{task.notes}</div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default MobileKitchenSystem;
