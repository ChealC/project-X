
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { supabase } from '@/integrations/supabase/client';
import { Eye, EyeOff, Copy, Search } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const StaffCredentialsDisplay = () => {
  const [showPasswords, setShowPasswords] = useState<{[key: string]: boolean}>({});
  const [searchTerm, setSearchTerm] = useState('');
  const { toast } = useToast();

  const { data: staffAccounts = [], isLoading } = useQuery({
    queryKey: ['staff-credentials'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('staff')
        .select(`
          id,
          name,
          position,
          phone,
          created_at,
          user_accounts (
            username,
            password_hash,
            role
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    }
  });

  const togglePasswordVisibility = (staffId: string) => {
    setShowPasswords(prev => ({
      ...prev,
      [staffId]: !prev[staffId]
    }));
  };

  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text).then(() => {
      toast({
        title: "คัดลอกสำเร็จ",
        description: `คัดลอก${type}เรียบร้อยแล้ว`
      });
    });
  };

  const getRoleLabel = (role: string) => {
    switch (role) {
      case 'admin': return 'แอดมิน';
      case 'manager': return 'ผู้จัดการ';
      case 'kitchen_staff': return 'ครัว';
      case 'service_staff': return 'เสิร์ฟ';
      default: return role;
    }
  };

  const getRoleBadgeVariant = (role: string) => {
    switch (role) {
      case 'admin': return 'default';
      case 'manager': return 'secondary';
      case 'kitchen_staff': return 'outline';
      case 'service_staff': return 'outline';
      default: return 'outline';
    }
  };

  const filteredStaff = staffAccounts.filter(staff => 
    staff.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    staff.position?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    staff.user_accounts?.[0]?.username?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (isLoading) {
    return <div className="flex justify-center p-4">กำลังโหลดข้อมูล...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">ข้อมูลการเข้าสู่ระบบพนักงาน</h3>
        <Badge variant="outline">{filteredStaff.length} คน</Badge>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        <Input
          placeholder="ค้นหาพนักงาน..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      <ScrollArea className="h-96">
        <div className="space-y-3">
          {filteredStaff.map((staff) => (
            <Card key={staff.id}>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center justify-between">
                  <span>{staff.name}</span>
                  {staff.user_accounts?.[0]?.role && (
                    <Badge variant={getRoleBadgeVariant(staff.user_accounts[0].role)}>
                      {getRoleLabel(staff.user_accounts[0].role)}
                    </Badge>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="text-sm text-gray-600">
                  ตำแหน่ง: {staff.position}
                </div>
                {staff.phone && (
                  <div className="text-sm text-gray-600">
                    โทร: {staff.phone}
                  </div>
                )}

                {staff.user_accounts?.[0] ? (
                  <div className="space-y-2">
                    {/* Username */}
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium w-16">User:</span>
                      <Input
                        value={staff.user_accounts[0].username}
                        readOnly
                        className="flex-1 bg-gray-50 text-sm"
                      />
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => copyToClipboard(staff.user_accounts[0].username, 'ชื่อผู้ใช้')}
                      >
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>

                    {/* Password */}
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium w-16">Pass:</span>
                      <Input
                        type={showPasswords[staff.id] ? 'text' : 'password'}
                        value={staff.user_accounts[0].password_hash || 'ไม่พบรหัสผ่าน'}
                        readOnly
                        className="flex-1 bg-gray-50 text-sm"
                      />
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => togglePasswordVisibility(staff.id)}
                      >
                        {showPasswords[staff.id] ? (
                          <EyeOff className="h-3 w-3" />
                        ) : (
                          <Eye className="h-3 w-3" />
                        )}
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => copyToClipboard(staff.user_accounts[0].password_hash || '', 'รหัสผ่าน')}
                      >
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-sm text-red-500 bg-red-50 p-2 rounded">
                    ยังไม่มีบัญชีผู้ใช้
                  </div>
                )}

                <div className="text-xs text-gray-500">
                  สร้างเมื่อ: {new Date(staff.created_at).toLocaleString('th-TH')}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </ScrollArea>

      {filteredStaff.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          ไม่พบข้อมูลพนักงานที่ค้นหา
        </div>
      )}
    </div>
  );
};

export default StaffCredentialsDisplay;
