import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Users, Key, Eye, EyeOff, Shield, Edit, Settings, AlertTriangle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const UserAccountsList = () => {
  const [isResetDialogOpen, setIsResetDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeactivateDialogOpen, setIsDeactivateDialogOpen] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState('');
  const [selectedAccount, setSelectedAccount] = useState<any>(null);
  const [newPassword, setNewPassword] = useState('');
  const [editUsername, setEditUsername] = useState('');
  const [editRole, setEditRole] = useState<'admin' | 'manager' | 'kitchen_staff' | 'service_staff'>('service_staff');
  const [showPassword, setShowPassword] = useState(false);
  const { toast } = useToast();
  const { hasPermission } = useAuth();
  const queryClient = useQueryClient();

  const { data: userAccounts, refetch } = useQuery({
    queryKey: ['user-accounts'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('user_accounts')
        .select(`
          *,
          staff (
            name,
            position,
            employee_id
          )
        `)
        .eq('is_active', true)
        .order('username');
      
      if (error) throw error;
      return data;
    }
  });

  // Updated hash function to match AuthContext
  const hashPassword = (password: string): string => {
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const binaryString = String.fromCharCode(...data);
    return btoa(binaryString);
  };

  const handleResetPassword = async () => {
    if (!selectedUserId || !newPassword) {
      toast({
        title: "กรุณากรอกข้อมูลให้ครบถ้วน",
        variant: "destructive"
      });
      return;
    }

    if (newPassword.length < 6) {
      toast({
        title: "รหัสผ่านสั้นเกินไป",
        description: "รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร",
        variant: "destructive"
      });
      return;
    }

    try {
      const passwordHash = hashPassword(newPassword);
      
      const { error } = await supabase
        .from('user_accounts')
        .update({
          password_hash: passwordHash,
          updated_at: new Date().toISOString()
        })
        .eq('id', selectedUserId);

      if (error) {
        toast({
          title: "เกิดข้อผิดพลาด",
          description: error.message,
          variant: "destructive"
        });
        return;
      }

      toast({
        title: "รีเซ็ตรหัสผ่านสำเร็จ",
        description: "รหัสผ่านได้รับการเปลี่ยนแปลงแล้ว"
      });

      // Reset form
      setNewPassword('');
      setSelectedUserId('');
      setIsResetDialogOpen(false);
      refetch();
    } catch (error) {
      console.error('Password reset error:', error);
      toast({
        title: "เกิดข้อผิดพลาด",
        description: "ไม่สามารถรีเซ็ตรหัสผ่านได้",
        variant: "destructive"
      });
    }
  };

  const handleEditAccount = async () => {
    if (!selectedAccount || !editUsername || !editRole) {
      toast({
        title: "กรุณากรอกข้อมูลให้ครบถ้วน",
        variant: "destructive"
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('user_accounts')
        .update({
          username: editUsername,
          role: editRole,
          updated_at: new Date().toISOString()
        })
        .eq('id', selectedAccount.id);

      if (error) {
        toast({
          title: "เกิดข้อผิดพลาด",
          description: error.message,
          variant: "destructive"
        });
        return;
      }

      toast({
        title: "แก้ไขบัญชีสำเร็จ",
        description: "ข้อมูลบัญชีได้รับการอัปเดตแล้ว"
      });

      setIsEditDialogOpen(false);
      setSelectedAccount(null);
      refetch();
    } catch (error) {
      console.error('Edit account error:', error);
      toast({
        title: "เกิดข้อผิดพลาด",
        description: "ไม่สามารถแก้ไขบัญชีได้",
        variant: "destructive"
      });
    }
  };

  const handleDeactivateAccount = async () => {
    if (!selectedAccount) return;

    try {
      const { error } = await supabase
        .from('user_accounts')
        .update({
          is_active: false,
          updated_at: new Date().toISOString()
        })
        .eq('id', selectedAccount.id);

      if (error) {
        toast({
          title: "เกิดข้อผิดพลาด",
          description: error.message,
          variant: "destructive"
        });
        return;
      }

      toast({
        title: "ปิดการใช้งานบัญชีสำเร็จ",
        description: "บัญชีได้ถูกปิดการใช้งานแล้ว"
      });

      setIsDeactivateDialogOpen(false);
      setSelectedAccount(null);
      refetch();
    } catch (error) {
      console.error('Deactivate account error:', error);
      toast({
        title: "เกิดข้อผิดพลาด",
        description: "ไม่สามารถปิดการใช้งานบัญชีได้",
        variant: "destructive"
      });
    }
  };

  const openEditDialog = (account: any) => {
    setSelectedAccount(account);
    setEditUsername(account.username);
    setEditRole(account.role as 'admin' | 'manager' | 'kitchen_staff' | 'service_staff');
    setIsEditDialogOpen(true);
  };

  const openDeactivateDialog = (account: any) => {
    setSelectedAccount(account);
    setIsDeactivateDialogOpen(true);
  };

  const getRoleLabel = (role: string) => {
    switch (role) {
      case 'admin': return 'ผู้ดูแลระบบ';
      case 'manager': return 'ผู้จัดการ';
      case 'kitchen_staff': return 'พนักงานครัว';
      case 'service_staff': return 'พนักงานบริการ';
      default: return role;
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'admin': return 'bg-red-500';
      case 'manager': return 'bg-blue-500';
      case 'kitchen_staff': return 'bg-green-500';
      case 'service_staff': return 'bg-orange-500';
      default: return 'bg-gray-500';
    }
  };

  if (!hasPermission('staff', 'view')) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <Shield className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600">ไม่มีสิทธิ์ในการดูรายการบัญชีผู้ใช้</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            รายการบัญชีผู้ใช้
          </CardTitle>
          {hasPermission('staff', 'edit') && (
            <Dialog open={isResetDialogOpen} onOpenChange={setIsResetDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline">
                  <Key className="w-4 h-4 mr-2" />
                  รีเซ็ตรหัสผ่าน
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>รีเซ็ตรหัสผ่านผู้ใช้</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <Label>เลือกผู้ใช้</Label>
                    <Select value={selectedUserId} onValueChange={setSelectedUserId}>
                      <SelectTrigger>
                        <SelectValue placeholder="เลือกผู้ใช้ที่ต้องการรีเซ็ตรหัสผ่าน" />
                      </SelectTrigger>
                      <SelectContent>
                        {userAccounts?.map((account) => (
                          <SelectItem key={account.id} value={account.id}>
                            {account.username} - {account.staff?.name || 'ผู้ดูแลระบบ'}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="new-password">รหัสผ่านใหม่</Label>
                    <div className="relative">
                      <Input
                        id="new-password"
                        type={showPassword ? "text" : "password"}
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        placeholder="กรอกรหัสผ่านใหม่"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>

                  <div className="flex gap-2 pt-4">
                    <Button onClick={handleResetPassword} className="flex-1">
                      รีเซ็ตรหัสผ่าน
                    </Button>
                    <Button variant="outline" onClick={() => setIsResetDialogOpen(false)} className="flex-1">
                      ยกเลิก
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {userAccounts?.map((account) => (
            <Card key={account.id} className="p-4">
              <div className="flex justify-between items-center">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold">{account.username}</h3>
                    <Badge className={`${getRoleColor(account.role)} text-white`}>
                      {getRoleLabel(account.role)}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600">{account.staff?.name || 'ผู้ดูแลระบบ'}</p>
                  <p className="text-sm text-gray-600">{account.staff?.position || 'ระบบ'}</p>
                  {account.staff?.employee_id && (
                    <p className="text-sm text-gray-600">รหัสพนักงาน: {account.staff.employee_id}</p>
                  )}
                  {account.last_login && (
                    <p className="text-xs text-gray-500">
                      เข้าสู่ระบบล่าสุด: {new Date(account.last_login).toLocaleDateString('th-TH')}
                    </p>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={account.is_active ? "default" : "secondary"}>
                    {account.is_active ? "ใช้งานได้" : "ปิดใช้งาน"}
                  </Badge>
                  {hasPermission('staff', 'edit') && (
                    <div className="flex gap-1">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => openEditDialog(account)}
                      >
                        <Edit className="w-3 h-3" />
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => openDeactivateDialog(account)}
                        className="text-orange-600 hover:text-orange-700"
                      >
                        <Settings className="w-3 h-3" />
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </Card>
          ))}

          {!userAccounts?.length && (
            <p className="text-center text-gray-500 py-8">ไม่มีข้อมูลบัญชีผู้ใช้</p>
          )}
        </div>

        {/* Edit Account Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>แก้ไขบัญชีผู้ใช้</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label htmlFor="edit-username">ชื่อผู้ใช้</Label>
                <Input
                  id="edit-username"
                  value={editUsername}
                  onChange={(e) => setEditUsername(e.target.value)}
                  placeholder="กรอกชื่อผู้ใช้"
                />
              </div>
              
              <div className="space-y-2">
                <Label>บทบาท</Label>
                <Select value={editRole} onValueChange={(value) => setEditRole(value as 'admin' | 'manager' | 'kitchen_staff' | 'service_staff')}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="admin">ผู้ดูแลระบบ</SelectItem>
                    <SelectItem value="manager">ผู้จัดการ</SelectItem>
                    <SelectItem value="kitchen_staff">พนักงานครัว</SelectItem>
                    <SelectItem value="service_staff">พนักงานบริการ</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex gap-2 pt-4">
                <Button onClick={handleEditAccount} className="flex-1">
                  บันทึกการแก้ไข
                </Button>
                <Button variant="outline" onClick={() => setIsEditDialogOpen(false)} className="flex-1">
                  ยกเลิก
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Deactivate Account Dialog */}
        <Dialog open={isDeactivateDialogOpen} onOpenChange={setIsDeactivateDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-orange-600">
                <AlertTriangle className="w-5 h-5" />
                ยืนยันการปิดใช้งานบัญชี
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <p className="text-sm text-gray-600">
                คุณต้องการปิดใช้งานบัญชี <strong>{selectedAccount?.username}</strong> หรือไม่?
              </p>
              <p className="text-sm text-orange-600">
                การดำเนินการนี้จะปิดการใช้งานบัญชีชั่วคราว และสามารถเปิดใช้งานได้ในภายหลัง
              </p>

              <div className="flex gap-2 pt-4">
                <Button 
                  onClick={handleDeactivateAccount} 
                  variant="outline"
                  className="flex-1 border-orange-300 text-orange-600 hover:bg-orange-50"
                >
                  ปิดใช้งาน
                </Button>
                <Button variant="outline" onClick={() => setIsDeactivateDialogOpen(false)} className="flex-1">
                  ยกเลิก
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <h3 className="font-semibold text-blue-800 mb-2">รายการบัญชีผู้ใช้ใหม่:</h3>
          <div className="text-sm text-blue-700 space-y-1">
            <div><strong>Admin:</strong> username: <code>admin</code> | password: <code>admin123</code></div>
            <div><strong>Manager:</strong> username: <code>manager_samorn</code> | password: <code>manager123</code></div>
            <div><strong>Service Head:</strong> username: <code>service_sarawut</code> | password: <code>service123</code></div>
            <div><strong>Service Staff:</strong> username: <code>service_chalada</code> | password: <code>service123</code></div>
            <div><strong>Cashier:</strong> username: <code>cashier_patima</code> | password: <code>cashier123</code></div>
            <div><strong>Kitchen Head:</strong> username: <code>chef_thanapol</code> | password: <code>chef123</code></div>
            <div><strong>Kitchen Staff:</strong> username: <code>kitchen_saksiam</code>, <code>kitchen_somporn</code>, <code>kitchen_samut</code>, <code>kitchen_ranakorn</code> | password: <code>kitchen123</code></div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default UserAccountsList;
