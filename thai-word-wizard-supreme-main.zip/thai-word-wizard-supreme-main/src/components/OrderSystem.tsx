
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { supabase } from '@/integrations/supabase/client';
import { ShoppingCart, Plus, Minus, Trash2, Package, Menu } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useIsMobile } from '@/hooks/use-mobile';
import { generateUniqueOrderNumber } from '@/utils/orderUtils';

interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  specialInstructions?: string;
}

const OrderSystem = () => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedTable, setSelectedTable] = useState<string>('');
  const [orderType, setOrderType] = useState<'dine-in' | 'takeaway' | 'delivery'>('dine-in');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [orderNotes, setOrderNotes] = useState('');
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCreatingOrder, setIsCreatingOrder] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isMobile = useIsMobile();

  // Get or create default kitchen station
  const { data: defaultStation } = useQuery({
    queryKey: ['default-kitchen-station'],
    queryFn: async () => {
      // First try to get existing station
      let { data: stations, error } = await supabase
        .from('kitchen_stations')
        .select('*')
        .eq('is_active', true)
        .limit(1);
      
      if (error) throw error;
      
      // If no stations exist, create a default one
      if (!stations || stations.length === 0) {
        const { data: newStation, error: createError } = await supabase
          .from('kitchen_stations')
          .insert({
            name: 'ครัวหลัก',
            description: 'สถานีครัวหลัก',
            is_active: true
          })
          .select()
          .single();
        
        if (createError) throw createError;
        return newStation;
      }
      
      return stations[0];
    }
  });

  const { data: menuCategories } = useQuery({
    queryKey: ['menu-categories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('menu_categories')
        .select('*, menu_items(*)')
        .eq('is_active', true)
        .order('sort_order');
      
      if (error) throw error;
      return data;
    }
  });

  const { data: tables } = useQuery({
    queryKey: ['all-tables'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('tables')
        .select('*')
        .order('table_number');
      
      if (error) throw error;
      return data;
    }
  });

  const createOrder = useMutation({
    mutationFn: async (orderData: any) => {
      console.log('Creating order with data:', orderData);
      
      if (isCreatingOrder) {
        throw new Error('กำลังสร้างออเดอร์อยู่ กรุณารอสักครู่');
      }
      
      setIsCreatingOrder(true);
      
      try {
        if (cart.length === 0) {
          throw new Error('ไม่มีรายการอาหารในตะกร้า');
        }

        if (orderType === 'dine-in' && !selectedTable) {
          throw new Error('กรุณาเลือกโต๊ะสำหรับการทานที่ร้าน');
        }

        if (orderType === 'takeaway' && (!customerName || !customerPhone)) {
          throw new Error('กรุณาใส่ชื่อและเบอร์โทรลูกค้าสำหรับการห่อกลับ');
        }

        if (!defaultStation) {
          throw new Error('ไม่สามารถหาสถานีครัวได้ กรุณาติดต่อผู้ดูแลระบบ');
        }

        // Generate unique order number
        console.log('Generating unique order number...');
        const orderNumber = await generateUniqueOrderNumber(
          orderType === 'dine-in' ? selectedTable : undefined, 
          orderType
        );
        
        const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        const totalAmount = subtotal;

        console.log('Order details:', {
          orderNumber,
          subtotal,
          totalAmount,
          cartItems: cart.length,
          defaultStation: defaultStation.id
        });

        // First, ensure all menu items have kitchen station assignments
        console.log('Updating menu items to have kitchen station assignments...');
        for (const cartItem of cart) {
          await supabase
            .from('menu_items')
            .update({ kitchen_station_id: defaultStation.id })
            .eq('id', cartItem.id)
            .is('kitchen_station_id', null);
        }

        // Create order first
        const { data: order, error: orderError } = await supabase
          .from('orders')
          .insert({
            order_number: orderNumber,
            table_id: selectedTable || null,
            order_type: orderType,
            subtotal,
            tax_amount: 0,
            service_charge: 0,
            discount_amount: 0,
            total_amount: totalAmount,
            customer_count: 1,
            status: 'pending',
            notes: orderNotes || null
          })
          .select()
          .single();

        if (orderError) {
          console.error('Order creation error:', orderError);
          throw new Error(`ไม่สามารถสร้างออเดอร์ได้: ${orderError.message}`);
        }

        console.log('Order created successfully:', order);

        // Create order items
        const orderItems = cart.map(item => ({
          order_id: order.id,
          menu_item_id: item.id,
          quantity: item.quantity,
          unit_price: item.price,
          total_price: item.price * item.quantity,
          special_instructions: item.specialInstructions || null
        }));

        console.log('Creating order items:', orderItems);

        const { data: createdItems, error: itemsError } = await supabase
          .from('order_items')
          .insert(orderItems)
          .select();

        if (itemsError) {
          console.error('Order items creation error:', itemsError);
          // Try to delete the order if items creation failed
          await supabase.from('orders').delete().eq('id', order.id);
          throw new Error(`ไม่สามารถเพิ่มรายการอาหารได้: ${itemsError.message}`);
        }

        console.log('Order items created:', createdItems);

        // Create kitchen queue entries directly with proper station_id
        console.log('Creating kitchen queue entries...');
        for (const orderItem of createdItems) {
          const { data: queueEntry, error: queueError } = await supabase
            .from('kitchen_queue')
            .insert({
              order_item_id: orderItem.id,
              station_id: defaultStation.id,
              estimated_time: 15,
              status: 'pending'
            })
            .select()
            .single();

          if (queueError) {
            console.error('Kitchen queue creation error for item:', orderItem.id, queueError);
            // Don't fail the entire order for this, just log it
          } else {
            console.log('Kitchen queue entry created:', queueEntry);
          }
        }

        // Create takeaway order record if needed
        if (orderType === 'takeaway') {
          const { error: takeawayError } = await supabase
            .from('takeaway_orders')
            .insert({
              order_id: order.id,
              customer_name: customerName,
              customer_phone: customerPhone,
              notes: orderNotes || null
            });

          if (takeawayError) {
            console.error('Takeaway order creation error:', takeawayError);
            // Don't fail the entire order for this
          }
        }

        // Update table status if dine-in and table is available
        if (orderType === 'dine-in' && selectedTable) {
          const selectedTableData = tables?.find(t => t.id === selectedTable);
          if (selectedTableData?.status === 'available') {
            const { error: tableError } = await supabase
              .from('tables')
              .update({ status: 'occupied' })
              .eq('id', selectedTable);

            if (tableError) {
              console.error('Table update error:', tableError);
              // Don't fail the entire order for this
            }
          }
        }

        return order;
      } finally {
        setIsCreatingOrder(false);
      }
    },
    onSuccess: (order) => {
      console.log('Order created successfully:', order);
      setCart([]);
      setSelectedTable('');
      setCustomerName('');
      setCustomerPhone('');
      setOrderNotes('');
      setIsCartOpen(false);
      queryClient.invalidateQueries({ queryKey: ['tables'] });
      queryClient.invalidateQueries({ queryKey: ['all-tables'] });
      queryClient.invalidateQueries({ queryKey: ['kitchen-queue'] });
      toast({
        title: "สร้างออเดอร์สำเร็จ",
        description: `ออเดอร์ ${order.order_number} ได้รับการสร้างและส่งเข้าครัวแล้ว`
      });
    },
    onError: (error: any) => {
      console.error('Order creation failed:', error);
      setIsCreatingOrder(false);
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error.message || "ไม่สามารถสร้างออเดอร์ได้",
        variant: "destructive"
      });
    }
  });

  const addToCart = (menuItem: any) => {
    console.log('Adding to cart:', menuItem);
    const existingItem = cart.find(item => item.id === menuItem.id);
    if (existingItem) {
      setCart(cart.map(item => 
        item.id === menuItem.id 
          ? { ...item, quantity: item.quantity + 1 }
          : item
      ));
    } else {
      setCart([...cart, {
        id: menuItem.id,
        name: menuItem.name,
        price: menuItem.price,
        quantity: 1
      }]);
    }
    
    toast({
      title: "เพิ่มในตะกร้าแล้ว",
      description: `${menuItem.name} ถูกเพิ่มในตะกร้า`,
    });

    // Auto-open cart on mobile after adding item
    if (isMobile) {
      setIsCartOpen(true);
    }
  };

  const updateQuantity = (id: string, quantity: number) => {
    if (quantity === 0) {
      setCart(cart.filter(item => item.id !== id));
    } else {
      setCart(cart.map(item => 
        item.id === id ? { ...item, quantity } : item
      ));
    }
  };

  const calculateTotal = () => {
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    return { subtotal, total: subtotal };
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'available': return 'ว่าง';
      case 'occupied': return 'มีลูกค้า';
      case 'reserved': return 'จอง';
      case 'cleaning': return 'ทำความสะอาด';
      default: return status;
    }
  };

  const { subtotal, total } = calculateTotal();

  const canCreateOrder = () => {
    if (cart.length === 0) return false;
    if (orderType === 'dine-in' && !selectedTable) return false;
    if (orderType === 'takeaway' && (!customerName || !customerPhone)) return false;
    if (isCreatingOrder) return false;
    return true;
  };

  // Mobile Cart Component
  const CartContent = () => (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between p-4 border-b">
        <div className="flex items-center gap-2">
          {orderType === 'takeaway' ? <Package className="h-5 w-5" /> : <ShoppingCart className="h-5 w-5" />}
          <span className="font-bold text-lg">ตะกร้าออเดอร์ ({cart.length})</span>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4">
        {cart.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            <ShoppingCart className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p className="text-base">ไม่มีรายการในตะกร้า</p>
            <p className="text-sm text-gray-400 mt-1">เลือกเมนูเพื่อเริ่มสั่งอาหาร</p>
          </div>
        ) : (
          <div className="space-y-4">
            {cart.map((item) => (
              <div key={item.id} className="border rounded-lg p-4 bg-gray-50">
                <div className="flex justify-between items-start mb-3">
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-base line-clamp-1 mb-1">{item.name}</h4>
                    <p className="text-sm text-gray-600">฿{item.price} x {item.quantity}</p>
                    <p className="text-base font-semibold text-green-600">รวม: ฿{(item.price * item.quantity).toFixed(2)}</p>
                  </div>
                  <Button 
                    size="sm" 
                    variant="destructive"
                    onClick={() => updateQuantity(item.id, 0)}
                    className="h-8 w-8 p-0 ml-2"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex items-center justify-center gap-4">
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => updateQuantity(item.id, item.quantity - 1)}
                    className="h-10 w-10 p-0"
                  >
                    <Minus className="h-5 w-5" />
                  </Button>
                  <span className="w-12 text-center font-medium text-lg">{item.quantity}</span>
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => updateQuantity(item.id, item.quantity + 1)}
                    className="h-10 w-10 p-0"
                  >
                    <Plus className="h-5 w-5" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {cart.length > 0 && (
        <div className="border-t p-4 bg-white">
          <div className="bg-blue-50 rounded-lg p-4 mb-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-gray-600">จำนวนรายการ:</span>
              <span className="text-sm font-medium">{cart.reduce((sum, item) => sum + item.quantity, 0)} รายการ</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-lg font-semibold">ยอดรวมทั้งสิ้น:</span>
              <span className="text-2xl font-bold text-green-600">฿{total.toFixed(2)}</span>
            </div>
          </div>
          
          {!canCreateOrder() && (
            <div className="mb-3 p-3 bg-yellow-50 border border-yellow-200 rounded text-sm text-yellow-800">
              {orderType === 'dine-in' && !selectedTable && "กรุณาเลือกโต๊ะ"}
              {orderType === 'takeaway' && (!customerName || !customerPhone) && "กรุณาใส่ชื่อและเบอร์โทรลูกค้า"}
            </div>
          )}
          
          <Button 
            className="w-full bg-blue-500 hover:bg-blue-600 h-14 text-lg font-semibold" 
            onClick={() => createOrder.mutate({})}
            disabled={createOrder.isPending || !canCreateOrder() || !defaultStation}
          >
            {createOrder.isPending ? 'กำลังสร้างออเดอร์...' : 'สร้างออเดอร์'}
          </Button>
        </div>
      )}
    </div>
  );

  if (isMobile) {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Mobile Header - Fixed */}
        <div className="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm">
          <div className="p-4">
            {/* Order Type Selector */}
            <div className="mb-4">
              <Label className="text-sm font-medium mb-2 block">ประเภทออเดอร์</Label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { type: 'dine-in', label: 'ทานที่ร้าน' },
                  { type: 'takeaway', label: 'ห่ออาหาร' },
                  { type: 'delivery', label: 'เดลิเวอรี่' }
                ].map(({ type, label }) => (
                  <Button
                    key={type}
                    size="default"
                    variant={orderType === type ? 'default' : 'outline'}
                    onClick={() => setOrderType(type as any)}
                    className="h-12 text-sm font-medium"
                  >
                    {label}
                  </Button>
                ))}
              </div>
            </div>

            {/* Dynamic Fields */}
            <div className="space-y-3">
              {orderType === 'takeaway' && (
                <>
                  <div>
                    <Label className="text-sm font-medium mb-1 block">ชื่อลูกค้า</Label>
                    <Input
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="ชื่อลูกค้า"
                      className="h-12 text-base"
                    />
                  </div>
                  <div>
                    <Label className="text-sm font-medium mb-1 block">เบอร์โทรศัพท์</Label>
                    <Input
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      placeholder="เบอร์โทรศัพท์"
                      className="h-12 text-base"
                    />
                  </div>
                </>
              )}

              {orderType === 'dine-in' && (
                <div>
                  <Label className="text-sm font-medium mb-1 block">เลือกโต๊ะ</Label>
                  <select 
                    className="w-full h-12 px-3 border rounded-md text-base bg-white"
                    value={selectedTable}
                    onChange={(e) => setSelectedTable(e.target.value)}
                  >
                    <option value="">เลือกโต๊ะ</option>
                    {tables?.map((table) => (
                      <option key={table.id} value={table.id}>
                        โต๊ะ {table.table_number} ({table.seats} ที่นั่ง) - {getStatusText(table.status)}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <Label className="text-sm font-medium mb-1 block">หมายเหตุ</Label>
                <Textarea
                  value={orderNotes}
                  onChange={(e) => setOrderNotes(e.target.value)}
                  placeholder="หมายเหตุเพิ่มเติม..."
                  rows={2}
                  className="text-base resize-none"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Menu Content */}
        <div className="p-4 pb-20">
          <Tabs defaultValue={menuCategories?.[0]?.id} className="w-full">
            <TabsList className="grid w-full mb-4 h-12" style={{gridTemplateColumns: `repeat(${menuCategories?.length || 1}, 1fr)`}}>
              {menuCategories?.map((category) => (
                <TabsTrigger key={category.id} value={category.id} className="text-sm py-3 font-medium">
                  {category.name}
                </TabsTrigger>
              ))}
            </TabsList>

            {menuCategories?.map((category) => (
              <TabsContent key={category.id} value={category.id}>
                <div className="grid grid-cols-1 gap-4">
                  {category.menu_items?.map((item) => (
                    <Card key={item.id} className="cursor-pointer hover:shadow-lg transition-all duration-200">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div className="flex-1 min-w-0 mr-4">
                            <h3 className="font-semibold text-lg mb-1">{item.name}</h3>
                            <p className="text-sm text-gray-600 mb-2 line-clamp-2">{item.description}</p>
                            <span className="text-xl font-bold text-green-600">
                              ฿{item.price}
                            </span>
                          </div>
                          <Button 
                            size="lg" 
                            onClick={() => addToCart(item)}
                            disabled={!item.is_available}
                            className="bg-green-500 hover:bg-green-600 h-12 w-12 p-0 flex-shrink-0"
                          >
                            <Plus className="h-6 w-6" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </div>

        {/* Floating Cart Button */}
        <div className="fixed bottom-4 right-4 z-50">
          <Sheet open={isCartOpen} onOpenChange={setIsCartOpen}>
            <SheetTrigger asChild>
              <Button 
                size="lg" 
                className="bg-blue-500 hover:bg-blue-600 h-16 w-16 rounded-full shadow-lg relative"
              >
                <ShoppingCart className="h-6 w-6" />
                {cart.length > 0 && (
                  <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs font-bold rounded-full h-6 w-6 flex items-center justify-center">
                    {cart.reduce((sum, item) => sum + item.quantity, 0)}
                  </span>
                )}
              </Button>
            </SheetTrigger>
            <SheetContent side="bottom" className="h-[90vh] p-0">
              <CartContent />
            </SheetContent>
          </Sheet>
        </div>
      </div>
    );
  }

  // Desktop Layout (unchanged)
  return (
    <div className="h-screen flex flex-col bg-gray-50">
      {/* Order Type Section - Fixed at top */}
      <div className="bg-white border-b border-gray-200 p-4 flex-shrink-0 shadow-sm">
        {/* Order Type Buttons */}
        <div className="flex items-center gap-3 mb-4">
          <Label className="font-semibold text-base min-w-fit">ประเภทออเดอร์:</Label>
          <div className="flex gap-2">
            {[
              { type: 'dine-in', label: 'ทานที่ร้าน' },
              { type: 'takeaway', label: 'ห่ออาหาร' },
              { type: 'delivery', label: 'เดลิเวอรี่' }
            ].map(({ type, label }) => (
              <Button
                key={type}
                size="default"
                variant={orderType === type ? 'default' : 'outline'}
                onClick={() => setOrderType(type as any)}
                className="h-10 px-4 text-sm font-medium"
              >
                {label}
              </Button>
            ))}
          </div>
        </div>

        {/* Dynamic Fields Based on Order Type */}
        <div className="grid grid-cols-12 gap-4">
          {/* Customer Info for Takeaway */}
          {orderType === 'takeaway' && (
            <>
              <div className="col-span-4">
                <Label className="text-sm font-medium">ชื่อลูกค้า</Label>
                <Input
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="ชื่อลูกค้า"
                  className="h-10 text-sm mt-1"
                />
              </div>
              <div className="col-span-4">
                <Label className="text-sm font-medium">เบอร์โทรศัพท์</Label>
                <Input
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="เบอร์โทรศัพท์"
                  className="h-10 text-sm mt-1"
                />
              </div>
            </>
          )}

          {/* Table Selection for Dine-in */}
          {orderType === 'dine-in' && (
            <div className="col-span-4">
              <Label className="text-sm font-medium">เลือกโต๊ะ</Label>
              <select 
                className="w-full h-10 px-3 border rounded-md text-sm bg-white mt-1"
                value={selectedTable}
                onChange={(e) => setSelectedTable(e.target.value)}
              >
                <option value="">เลือกโต๊ะ</option>
                {tables?.map((table) => (
                  <option key={table.id} value={table.id}>
                    โต๊ะ {table.table_number} ({table.seats} ที่นั่ง) - {getStatusText(table.status)}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Notes */}
          <div className="col-span-4">
            <Label className="text-sm font-medium">หมายเหตุ</Label>
            <Textarea
              value={orderNotes}
              onChange={(e) => setOrderNotes(e.target.value)}
              placeholder="หมายเหตุเพิ่มเติม..."
              rows={2}
              className="text-sm resize-none mt-1"
            />
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex min-h-0">
        {/* Menu Section - 75% width */}
        <div className="flex-1 p-4">
          <Card className="h-full">
            <CardHeader className="p-4 pb-3">
              <CardTitle className="text-xl font-bold">เมนูอาหาร</CardTitle>
            </CardHeader>
            <CardContent className="p-4 pt-0 h-[calc(100%-80px)] overflow-hidden">
              <Tabs defaultValue={menuCategories?.[0]?.id} className="h-full flex flex-col">
                <TabsList className="grid w-full mb-3 h-10" style={{gridTemplateColumns: `repeat(${menuCategories?.length || 1}, 1fr)`}}>
                  {menuCategories?.map((category) => (
                    <TabsTrigger key={category.id} value={category.id} className="text-sm py-2 font-medium">
                      {category.name}
                    </TabsTrigger>
                  ))}
                </TabsList>

                {menuCategories?.map((category) => (
                  <TabsContent key={category.id} value={category.id} className="flex-1 overflow-y-auto mt-0">
                    <div className="grid grid-cols-3 xl:grid-cols-4 gap-3">
                      {category.menu_items?.map((item) => (
                        <Card key={item.id} className="cursor-pointer hover:shadow-lg transition-all duration-200 h-28">
                          <CardContent className="p-3 h-full flex flex-col justify-between">
                            <div className="flex-1">
                              <h3 className="font-semibold text-sm line-clamp-1 mb-1">{item.name}</h3>
                              <p className="text-xs text-gray-600 line-clamp-2">{item.description}</p>
                            </div>
                            <div className="flex justify-between items-center mt-2">
                              <span className="text-sm font-bold text-green-600">
                                ฿{item.price}
                              </span>
                              <Button 
                                size="sm" 
                                onClick={() => addToCart(item)}
                                disabled={!item.is_available}
                                className="bg-green-500 hover:bg-green-600 h-7 w-7 p-0"
                              >
                                <Plus className="h-4 w-4" />
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </TabsContent>
                ))}
              </Tabs>
            </CardContent>
          </Card>
        </div>

        {/* Order Cart Section - 25% width */}
        <div className="w-96 p-4 pl-0">
          <Card className="h-full">
            <CardContent className="p-0 h-full">
              <CartContent />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default OrderSystem;
