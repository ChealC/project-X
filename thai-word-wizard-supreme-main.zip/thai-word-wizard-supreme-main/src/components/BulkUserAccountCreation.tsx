
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { UserPlus, Key, Eye, EyeOff, Copy, Check } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const BulkUserAccountCreation = () => {
  const [isCreating, setIsCreating] = useState(false);
  const [createdAccounts, setCreatedAccounts] = useState<any[]>([]);
  const [showPasswords, setShowPasswords] = useState<{ [key: string]: boolean }>({});
  const [copiedPasswords, setCopiedPasswords] = useState<{ [key: string]: boolean }>({});
  const { toast } = useToast();
  const { hasPermission } = useAuth();
  const queryClient = useQueryClient();

  // ดึงข้อมูลพนักงานที่ยังไม่มีบัญชี
  const { data: staffWithoutAccounts } = useQuery({
    queryKey: ['staff-without-accounts'],
    queryFn: async () => {
      const { data: allStaff, error: staffError } = await supabase
        .from('staff')
        .select('*')
        .eq('is_active', true);
      
      if (staffError) throw staffError;

      const { data: existingAccounts, error: accountError } = await supabase
        .from('user_accounts')
        .select('staff_id')
        .eq('is_active', true);
      
      if (accountError) throw accountError;

      const existingStaffIds = existingAccounts.map(acc => acc.staff_id);
      return allStaff.filter(staff => !existingStaffIds.includes(staff.id));
    }
  });

  // Hash password function (same as in AuthContext)
  const hashPassword = (password: string): string => {
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const binaryString = String.fromCharCode(...data);
    return btoa(binaryString);
  };

  // Generate 16-digit numeric password
  const generateNumericPassword = (): string => {
    let password = '';
    for (let i = 0; i < 16; i++) {
      password += Math.floor(Math.random() * 10).toString();
    }
    return password;
  };

  // Determine role based on position
  const determineRole = (position: string): 'admin' | 'manager' | 'kitchen_staff' | 'service_staff' => {
    const pos = position.toLowerCase();
    if (pos.includes('ผู้จัดการ') || pos.includes('manager')) return 'manager';
    if (pos.includes('ครัว') || pos.includes('chef') || pos.includes('cook')) return 'kitchen_staff';
    return 'service_staff';
  };

  // Generate username
  const generateUsername = (name: string, position: string): string => {
    const nameParts = name.split(' ');
    const firstName = nameParts[0];
    const pos = position.toLowerCase();
    
    if (pos.includes('ครัว')) {
      return `kitchen_${firstName.toLowerCase()}`;
    } else if (pos.includes('ผู้จัดการ')) {
      return `manager_${firstName.toLowerCase()}`;
    } else {
      return `service_${firstName.toLowerCase()}`;
    }
  };

  const createAllAccountsMutation = useMutation({
    mutationFn: async () => {
      if (!staffWithoutAccounts || staffWithoutAccounts.length === 0) {
        throw new Error('ไม่มีพนักงานที่ต้องสร้างบัญชี');
      }

      console.log('=== เริ่มสร้างบัญชีผู้ใช้ทั้งหมด ===');
      const accountsToCreate = [];

      for (const staff of staffWithoutAccounts) {
        const role = determineRole(staff.position);
        const username = generateUsername(staff.name, staff.position);
        const password = generateNumericPassword();
        const passwordHash = hashPassword(password);

        console.log(`สร้างบัญชี: ${staff.name} - Username: ${username} - Password: ${password}`);

        const accountData = {
          staff_id: staff.id,
          username: username,
          password_hash: passwordHash,
          role: role,
          is_active: true
        };

        const { data, error } = await supabase
          .from('user_accounts')
          .insert(accountData)
          .select('*')
          .single();

        if (error) {
          console.error(`Error creating account for ${staff.name}:`, error);
          throw error;
        }

        accountsToCreate.push({
          ...data,
          staff_name: staff.name,
          employee_id: staff.employee_id,
          position: staff.position,
          plain_password: password
        });
      }

      console.log(`=== สร้างบัญชีเสร็จสิ้น: ${accountsToCreate.length} บัญชี ===`);
      return accountsToCreate;
    },
    onSuccess: (accounts) => {
      setCreatedAccounts(accounts);
      toast({
        title: "สร้างบัญชีสำเร็จ! 🎉",
        description: `สร้างบัญชีผู้ใช้ ${accounts.length} บัญชี พร้อมรหัสผ่านตัวเลข 16 หลัก`
      });
      queryClient.invalidateQueries({ queryKey: ['staff-without-accounts'] });
    },
    onError: (error: any) => {
      console.error('Error creating accounts:', error);
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const handleCreateAccounts = () => {
    setIsCreating(true);
    createAllAccountsMutation.mutate();
    setTimeout(() => setIsCreating(false), 2000);
  };

  const togglePasswordVisibility = (accountId: string) => {
    setShowPasswords(prev => ({
      ...prev,
      [accountId]: !prev[accountId]
    }));
  };

  const copyPassword = async (password: string, accountId: string) => {
    try {
      await navigator.clipboard.writeText(password);
      setCopiedPasswords(prev => ({ ...prev, [accountId]: true }));
      toast({
        title: "คัดลอกแล้ว",
        description: "คัดลอกรหัสผ่านเรียบร้อยแล้ว"
      });
      setTimeout(() => {
        setCopiedPasswords(prev => ({ ...prev, [accountId]: false }));
      }, 2000);
    } catch (error) {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: "ไม่สามารถคัดลอกได้",
        variant: "destructive"
      });
    }
  };

  const getRoleLabel = (role: string) => {
    switch (role) {
      case 'admin': return 'ผู้ดูแลระบบ';
      case 'manager': return 'ผู้จัดการ';
      case 'kitchen_staff': return 'พนักงานครัว';
      case 'service_staff': return 'พนักงานบริการ';
      default: return role;
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'admin': return 'bg-red-500';
      case 'manager': return 'bg-blue-500';
      case 'kitchen_staff': return 'bg-green-500';
      case 'service_staff': return 'bg-orange-500';
      default: return 'bg-gray-500';
    }
  };

  if (!hasPermission('staff', 'edit')) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <p className="text-gray-600">ไม่มีสิทธิ์ในการสร้างบัญชีผู้ใช้</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <UserPlus className="w-5 h-5" />
              สร้างบัญชีผู้ใช้ (รหัสผ่านตัวเลข 16 หลัก)
            </CardTitle>
            {staffWithoutAccounts && staffWithoutAccounts.length > 0 && (
              <Button 
                onClick={handleCreateAccounts}
                disabled={isCreating || createAllAccountsMutation.isPending}
                className="bg-green-500 hover:bg-green-600 text-white"
                size="lg"
              >
                <Key className="w-4 h-4 mr-2" />
                {isCreating ? 'กำลังสร้างบัญชี...' : `สร้างบัญชีทั้งหมด (${staffWithoutAccounts.length} คน)`}
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {staffWithoutAccounts && staffWithoutAccounts.length > 0 ? (
            <div className="space-y-4">
              <h3 className="font-semibold text-lg text-blue-600">
                พนักงานที่ยังไม่มีบัญชี ({staffWithoutAccounts.length} คน)
              </h3>
              <div className="grid gap-3">
                {staffWithoutAccounts.map((staff) => (
                  <Card key={staff.id} className="p-3 border border-blue-200 bg-blue-50">
                    <div className="flex justify-between items-center">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <h4 className="font-semibold">{staff.name}</h4>
                          <Badge variant="outline">{staff.position}</Badge>
                          <Badge className={`${getRoleColor(determineRole(staff.position))} text-white`}>
                            {getRoleLabel(determineRole(staff.position))}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600">รหัสพนักงาน: {staff.employee_id}</p>
                        <p className="text-sm text-blue-600">Username: {generateUsername(staff.name, staff.position)}</p>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          ) : (
            <div className="text-center py-8">
              <Check className="w-12 h-12 text-green-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-green-600 mb-2">
                พนักงานทุกคนมีบัญชีแล้ว
              </h3>
              <p className="text-gray-600">ไม่มีพนักงานที่ต้องสร้างบัญชีเพิ่มเติม</p>
            </div>
          )}

          {/* แสดงรายการบัญชีที่สร้างแล้ว */}
          {createdAccounts.length > 0 && (
            <div className="mt-8 space-y-4">
              <h3 className="font-semibold text-lg text-green-600">
                บัญชีที่สร้างใหม่ ({createdAccounts.length} บัญชี)
              </h3>
              
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ชื่อพนักงาน</TableHead>
                      <TableHead>ตำแหน่ง</TableHead>
                      <TableHead>Username</TableHead>
                      <TableHead>Password (16 หลัก)</TableHead>
                      <TableHead>บทบาท</TableHead>
                      <TableHead>การดำเนินการ</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {createdAccounts.map((account) => (
                      <TableRow key={account.id}>
                        <TableCell className="font-medium">{account.staff_name}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{account.position}</Badge>
                        </TableCell>
                        <TableCell>
                          <code className="bg-blue-100 px-2 py-1 rounded text-sm">
                            {account.username}
                          </code>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <code className="bg-red-100 px-2 py-1 rounded text-sm font-mono">
                              {showPasswords[account.id] ? account.plain_password : '••••••••••••••••'}
                            </code>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => togglePasswordVisibility(account.id)}
                            >
                              {showPasswords[account.id] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => copyPassword(account.plain_password, account.id)}
                            >
                              {copiedPasswords[account.id] ? (
                                <Check className="w-4 h-4 text-green-500" />
                              ) : (
                                <Copy className="w-4 h-4" />
                              )}
                            </Button>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={`${getRoleColor(account.role)} text-white`}>
                            {getRoleLabel(account.role)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant="default" className="bg-green-500">
                            ใช้งานได้
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <h3 className="font-semibold text-yellow-800 mb-2">🔐 ข้อมูลสำคัญ:</h3>
                <div className="text-sm text-yellow-700 space-y-1">
                  <p>• รหัสผ่านเป็นตัวเลข 16 หลัก สร้างแบบสุ่ม</p>
                  <p>• กดปุ่มตาเพื่อแสดง/ซ่อนรหัสผ่าน</p>
                  <p>• กดปุ่มคัดลอกเพื่อคัดลอกรหัสผ่าน</p>
                  <p>• แนะนำให้พนักงานเปลี่ยนรหัสผ่านหลังเข้าใช้งานครั้งแรก</p>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default BulkUserAccountCreation;
