
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import CashDrawerShiftManager from './CashDrawerShiftManager';
import { DollarSign, Clock, BarChart3 } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';

const CashDrawerSystem = () => {
  const { data: recentTransactions = [] } = useQuery({
    queryKey: ['recent-cash-transactions'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('cash_drawer_transactions')
        .select(`
          *,
          cash_drawer_shifts (
            shift_date,
            staff (name)
          )
        `)
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) throw error;
      return data || [];
    }
  });

  const { data: shiftsToday = [] } = useQuery({
    queryKey: ['shifts-today'],
    queryFn: async () => {
      const today = new Date().toISOString().split('T')[0];
      const { data, error } = await supabase
        .from('cash_drawer_shifts')
        .select(`
          *,
          staff (name)
        `)
        .eq('shift_date', today)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    }
  });

  const getTransactionTypeLabel = (type: string) => {
    switch (type) {
      case 'opening': return 'เปิดกะ';
      case 'sale': return 'ขาย';
      case 'refund': return 'คืนเงิน';
      case 'expense': return 'ค่าใช้จ่าย';
      default: return type;
    }
  };

  const getTransactionBadgeVariant = (type: string) => {
    switch (type) {
      case 'opening': return 'default';
      case 'sale': return 'default';
      case 'refund': return 'destructive';
      case 'expense': return 'secondary';
      default: return 'outline';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <DollarSign className="h-6 w-6" />
        <h2 className="text-2xl font-bold">ระบบลิ้นชักเงินสด</h2>
      </div>

      <Tabs defaultValue="shift" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="shift" className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            จัดการกะ
          </TabsTrigger>
          <TabsTrigger value="transactions" className="flex items-center gap-2">
            <DollarSign className="h-4 w-4" />
            รายการเงินสด
          </TabsTrigger>
          <TabsTrigger value="summary" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            สรุปประจำวัน
          </TabsTrigger>
        </TabsList>

        <TabsContent value="shift">
          <CashDrawerShiftManager />
        </TabsContent>

        <TabsContent value="transactions">
          <Card>
            <CardHeader>
              <CardTitle>รายการเงินสดล่าสุด</CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="space-y-3">
                  {recentTransactions.map((transaction) => (
                    <div key={transaction.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <Badge variant={getTransactionBadgeVariant(transaction.transaction_type)}>
                            {getTransactionTypeLabel(transaction.transaction_type)}
                          </Badge>
                          <span className="text-sm text-gray-600">
                            {new Date(transaction.created_at).toLocaleString('th-TH')}
                          </span>
                        </div>
                        <div className="text-sm">{transaction.description}</div>
                        {transaction.cash_drawer_shifts?.staff?.name && (
                          <div className="text-xs text-gray-500">
                            โดย: {transaction.cash_drawer_shifts.staff.name}
                          </div>
                        )}
                      </div>
                      <div className={`font-semibold ${
                        transaction.transaction_type === 'refund' || transaction.transaction_type === 'expense'
                          ? 'text-red-600' 
                          : 'text-green-600'
                      }`}>
                        {transaction.transaction_type === 'refund' || transaction.transaction_type === 'expense' 
                          ? '-' 
                          : '+'}฿{transaction.amount?.toFixed(2)}
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="summary">
          <div className="grid gap-4">
            <Card>
              <CardHeader>
                <CardTitle>สรุปกะวันนี้</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {shiftsToday.map((shift) => (
                    <div key={shift.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="space-y-1">
                        <div className="font-medium">{shift.staff?.name}</div>
                        <div className="text-sm text-gray-600">
                          {shift.status === 'open' ? 'กะเปิดอยู่' : 'กะปิดแล้ว'}
                        </div>
                        <div className="text-xs text-gray-500">
                          เปิด: {new Date(shift.created_at).toLocaleTimeString('th-TH')}
                          {shift.closed_at && (
                            <> | ปิด: {new Date(shift.closed_at).toLocaleTimeString('th-TH')}</>
                          )}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold">
                          เริ่มต้น: ฿{shift.opening_amount?.toFixed(2)}
                        </div>
                        {shift.closing_amount && (
                          <div className="text-sm text-gray-600">
                            ปิด: ฿{shift.closing_amount.toFixed(2)}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default CashDrawerSystem;
