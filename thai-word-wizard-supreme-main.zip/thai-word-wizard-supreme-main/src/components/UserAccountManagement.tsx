
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Database, Trash2, UserCheck, Shield } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const UserAccountManagement = () => {
  const [isDeleting, setIsDeleting] = useState(false);
  const [isCreatingAdmin, setIsCreatingAdmin] = useState(false);
  const { toast } = useToast();
  const { hasPermission } = useAuth();

  // Hash function (same as AuthContext)
  const hashPassword = (password: string): string => {
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const binaryString = String.fromCharCode(...data);
    return btoa(binaryString);
  };

  const forceDeleteAllData = async () => {
    setIsDeleting(true);
    
    try {
      console.log('=== เริ่มลบข้อมูลทั้งหมดแบบ FORCE DELETE ===');
      
      // Step 1: ลบการลงเวลาทั้งหมดก่อน (staff_shifts)
      console.log('1. FORCE DELETE ลบการลงเวลาทั้งหมด...');
      const { error: shiftsError } = await supabase
        .from('staff_shifts')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000'); // ลบทุกอัน
      
      if (shiftsError) {
        console.error('Error deleting staff shifts:', shiftsError);
        // ลองอีกครั้งด้วยวิธีอื่น
        const { error: shiftsError2 } = await supabase
          .from('staff_shifts')
          .delete()
          .gte('created_at', '2000-01-01'); // ลบทุกอันที่สร้างหลัง 2000
        
        if (shiftsError2) {
          console.error('Error deleting staff shifts (retry):', shiftsError2);
        }
      } else {
        console.log('✓ ลบการลงเวลาทั้งหมดแล้ว');
      }
      
      // Step 2: ลบ cash drawer shifts
      console.log('2. FORCE DELETE cash_drawer_shifts...');
      const { error: drawerError } = await supabase
        .from('cash_drawer_shifts')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000');
      
      if (drawerError) {
        console.error('Error deleting cash drawer shifts:', drawerError);
      }
      
      // Step 3: ลบ user accounts ที่มี staff_id
      console.log('3. FORCE DELETE user_accounts with staff_id...');
      const { error: userAccountsError } = await supabase
        .from('user_accounts')
        .delete()
        .not('staff_id', 'is', null);
      
      if (userAccountsError) {
        console.error('Error deleting user accounts:', userAccountsError);
      }
      
      // Step 4: ลบ user accounts ทั้งหมดยกเว้น admin
      console.log('4. FORCE DELETE all user_accounts except admin...');
      const { error: allAccountsError } = await supabase
        .from('user_accounts')
        .delete()
        .neq('username', 'admin');
      
      if (allAccountsError) {
        console.error('Error deleting all user accounts:', allAccountsError);
      }
      
      // Step 5: ลบพนักงานทั้งหมด
      console.log('5. FORCE DELETE ALL staff...');
      const { error: staffError } = await supabase
        .from('staff')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000');
      
      if (staffError) {
        console.error('Error deleting staff:', staffError);
      }

      console.log('=== ลบข้อมูลทั้งหมดเสร็จสิ้น ===');

      toast({
        title: "🗑️ ลบข้อมูลสำเร็จ!",
        description: "ลบการลงเวลา พนักงาน และบัญชีทั้งหมดแล้ว กำลังสร้าง admin..."
      });

      // รอสักครู่แล้วสร้าง admin
      await new Promise(resolve => setTimeout(resolve, 1000));
      await createAdminAccount();

    } catch (error) {
      console.error('Error in force delete:', error);
      toast({
        title: "เกิดข้อผิดพลาด",
        description: "ไม่สามารถลบข้อมูลได้",
        variant: "destructive"
      });
    } finally {
      setIsDeleting(false);
    }
  };

  const createAdminAccount = async () => {
    setIsCreatingAdmin(true);
    
    try {
      console.log('=== เริ่มสร้าง Admin ===');
      
      // ลบ admin เก่าก่อน (ถ้ามี)
      await supabase.from('user_accounts').delete().eq('username', 'admin');

      console.log('ลบ admin เก่าแล้ว');

      // สร้าง admin account ใหม่
      const passwordHash = hashPassword('admin123');
      
      const { error } = await supabase
        .from('user_accounts')
        .insert({
          username: 'admin',
          password_hash: passwordHash,
          role: 'admin',
          is_active: true,
          staff_id: null
        });

      if (error) {
        throw error;
      }

      console.log('✓ สร้าง Admin สำเร็จ');
      
      toast({
        title: "✅ สร้าง Admin สำเร็จ!",
        description: "Username: admin | Password: admin123"
      });

    } catch (error) {
      console.error('Error creating admin:', error);
      toast({
        title: "เกิดข้อผิดพลาด",
        description: "ไม่สามารถสร้าง admin ได้",
        variant: "destructive"
      });
    } finally {
      setIsCreatingAdmin(false);
    }
  };

  if (!hasPermission('staff', 'edit')) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <Shield className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600">ไม่มีสิทธิ์ในการจัดการบัญชีผู้ใช้</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="w-5 h-5" />
            การตั้งค่าข้อมูล
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Card className="p-4 border-l-4 border-l-blue-500">
              <div className="flex justify-between items-center">
                <div>
                  <h4 className="font-semibold text-lg">ผู้ดูแลระบบ</h4>
                  <p className="text-sm text-gray-600">ผู้ดูแลระบบ</p>
                  <div className="mt-2 space-y-1">
                    <p className="text-sm font-mono bg-blue-100 px-2 py-1 rounded">
                      <strong>Username:</strong> admin
                    </p>
                    <p className="text-sm font-mono bg-green-100 px-2 py-1 rounded">
                      <strong>Password:</strong> admin123
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="bg-red-100 text-red-800 px-3 py-1 rounded text-sm font-semibold">
                    ผู้ดูแลระบบ
                  </div>
                </div>
              </div>
            </Card>

            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <h3 className="font-semibold text-yellow-800 mb-2">⚠️ การลบข้อมูล</h3>
              <p className="text-sm text-yellow-700 mb-3">
                หากต้องการรีเซ็ตระบบและลบข้อมูลทั้งหมด (การลงเวลา, พนักงาน, บัญชี) 
                กรุณากดปุ่มด้านล่าง การดำเนินการนี้ไม่สามารถยกเลิกได้
              </p>

              <Button 
                onClick={forceDeleteAllData}
                disabled={isDeleting || isCreatingAdmin}
                className="w-full bg-red-500 hover:bg-red-600 text-white"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                {isDeleting ? 'กำลังลบข้อมูล...' : isCreatingAdmin ? 'กำลังสร้าง Admin...' : 'ลบข้อมูลทั้งหมดและรีเซ็ตระบบ'}
              </Button>
            </div>

            <Button 
              onClick={createAdminAccount}
              disabled={isCreatingAdmin || isDeleting}
              className="w-full bg-blue-500 hover:bg-blue-600 text-white"
            >
              <UserCheck className="w-4 h-4 mr-2" />
              {isCreatingAdmin ? 'กำลังสร้าง Admin...' : 'สร้างบัญชี Admin ใหม่'}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default UserAccountManagement;
