
import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/integrations/supabase/client';
import { Shield, Bot, AlertTriangle, CheckCircle, Zap, RefreshCw, Eye, Brain, Lock, FileCheck } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useThreatDetection } from './security/ThreatDetectionService';
import AccessControlManager from './security/AccessControlManager';
import ComplianceMonitor from './security/ComplianceMonitor';

const SecurityBot = () => {
  const [botMode, setBotMode] = useState<'monitoring' | 'analysis' | 'response'>('monitoring');
  const [autoResponseEnabled, setAutoResponseEnabled] = useState(true);
  const [intelligenceLevel, setIntelligenceLevel] = useState<'basic' | 'advanced' | 'ai_powered'>('ai_powered');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const {
    threats,
    isActive,
    setIsActive,
    detectionRules,
    setDetectionRules,
    detectThreats,
    autoRespondToThreat,
    isDetecting,
    isResponding
  } = useThreatDetection();

  // AI Security Analytics
  const { data: securityMetrics } = useQuery({
    queryKey: ['security-metrics'],
    queryFn: async () => {
      return {
        threats_blocked_today: Math.floor(Math.random() * 50) + 10,
        false_positives: Math.floor(Math.random() * 5),
        response_time_avg: '0.1s',
        detection_accuracy: 97.8,
        active_sessions: Math.floor(Math.random() * 20) + 5,
        risk_score: Math.floor(Math.random() * 30) + 15,
        compliance_score: 94.2,
        last_vulnerability_scan: new Date().toISOString()
      };
    }
  });

  // Advanced AI Features
  const runAdvancedAnalysis = useMutation({
    mutationFn: async () => {
      console.log('AI Security Bot: Running advanced threat analysis...');
      
      const analysisResults = {
        behavioral_patterns: [
          'Normal login pattern detected for 95% of users',
          'Anomalous after-hours access by 2 employees',
          'Unusual transaction velocity in evening shift'
        ],
        predictive_threats: [
          'Potential brute force attack expected within 2-3 hours',
          'Increased DDoS likelihood based on network patterns',
          'Possible insider threat developing - monitoring required'
        ],
        vulnerability_assessment: [
          'SSL certificate expires in 30 days',
          'Outdated security patches on 2 terminals',
          'Weak password policy compliance at 78%'
        ],
        recommendations: [
          'Enable additional MFA for admin accounts',
          'Implement zero-trust network architecture',
          'Schedule immediate security awareness training'
        ]
      };

      // Simulate AI processing time
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      return analysisResults;
    },
    onSuccess: (results) => {
      toast({
        title: "🧠 AI Analysis Complete",
        description: `พบแนวโน้มภัยคุกคาม ${results.predictive_threats.length} รายการ`
      });
    }
  });

  const getBotStatusIcon = () => {
    if (!isActive) return <Bot className="h-6 w-6 text-gray-400" />;
    if (isDetecting || runAdvancedAnalysis.isPending) return <RefreshCw className="h-6 w-6 text-blue-500 animate-spin" />;
    if (threats && threats.length > 0) return <AlertTriangle className="h-6 w-6 text-red-500" />;
    return <CheckCircle className="h-6 w-6 text-green-500" />;
  };

  const getBotStatusText = () => {
    if (!isActive) return 'ปิดใช้งาน';
    if (isDetecting) return 'กำลังตรวจจับภัยคุกคาม...';
    if (runAdvancedAnalysis.isPending) return 'กำลังวิเคราะห์ AI...';
    if (threats && threats.length > 0) return 'ตรวจพบภัยคุกคาม';
    return 'ทำงานปกติ';
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bot className="h-5 w-5" />
            AI Security Bot - Advanced Protection System
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="dashboard" className="w-full">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
              <TabsTrigger value="threats">Threat Detection</TabsTrigger>
              <TabsTrigger value="access">Access Control</TabsTrigger>
              <TabsTrigger value="compliance">Compliance</TabsTrigger>
              <TabsTrigger value="analytics">AI Analytics</TabsTrigger>
            </TabsList>

            <TabsContent value="dashboard" className="space-y-6">
              {/* Real-time Status Dashboard */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      {getBotStatusIcon()}
                      <div>
                        <p className="text-sm font-medium">AI Bot Status</p>
                        <p className="text-xs text-gray-600">{getBotStatusText()}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <Shield className="h-6 w-6 text-blue-500" />
                      <div>
                        <p className="text-lg font-bold">{securityMetrics?.threats_blocked_today || 0}</p>
                        <p className="text-xs text-gray-600">ภัยคุกคามที่ปิดกั้น</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <Brain className="h-6 w-6 text-purple-500" />
                      <div>
                        <p className="text-lg font-bold">{securityMetrics?.detection_accuracy || 0}%</p>
                        <p className="text-xs text-gray-600">ความแม่นยำ AI</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <Zap className="h-6 w-6 text-yellow-500" />
                      <div>
                        <p className="text-sm font-medium">{securityMetrics?.response_time_avg || 'N/A'}</p>
                        <p className="text-xs text-gray-600">เวลาตอบสนอง</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Advanced Controls */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">AI Security Controls</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">AI Security Bot</span>
                      <Button
                        variant={isActive ? "default" : "outline"}
                        size="sm"
                        onClick={() => setIsActive(!isActive)}
                      >
                        {isActive ? 'Active' : 'Inactive'}
                      </Button>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-sm">Auto Response</span>
                      <Button
                        variant={autoResponseEnabled ? "default" : "outline"}
                        size="sm"
                        onClick={() => setAutoResponseEnabled(!autoResponseEnabled)}
                        disabled={!isActive}
                      >
                        {autoResponseEnabled ? 'Enabled' : 'Disabled'}
                      </Button>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm">Intelligence Level</label>
                      <select
                        value={intelligenceLevel}
                        onChange={(e) => setIntelligenceLevel(e.target.value as any)}
                        className="w-full px-3 py-2 border rounded-md"
                      >
                        <option value="basic">Basic Detection</option>
                        <option value="advanced">Advanced Analytics</option>
                        <option value="ai_powered">AI-Powered (Recommended)</option>
                      </select>
                    </div>

                    <div className="flex gap-2">
                      <Button
                        onClick={() => detectThreats.mutate()}
                        disabled={isDetecting || !isActive}
                        className="flex-1"
                      >
                        {isDetecting ? 'Scanning...' : 'Run Threat Scan'}
                      </Button>
                      <Button
                        onClick={() => runAdvancedAnalysis.mutate()}
                        disabled={runAdvancedAnalysis.isPending || !isActive}
                        variant="outline"
                        className="flex-1"
                      >
                        {runAdvancedAnalysis.isPending ? 'Analyzing...' : 'AI Analysis'}
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Security Metrics</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span>Active Sessions:</span>
                      <span>{securityMetrics?.active_sessions || 0}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Risk Score:</span>
                      <Badge variant={securityMetrics?.risk_score < 30 ? "default" : "destructive"}>
                        {securityMetrics?.risk_score || 0}/100
                      </Badge>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Compliance Score:</span>
                      <span className="text-green-600">{securityMetrics?.compliance_score || 0}%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>False Positives:</span>
                      <span>{securityMetrics?.false_positives || 0}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Last Vulnerability Scan:</span>
                      <span className="text-xs">
                        {securityMetrics?.last_vulnerability_scan ? 
                          new Date(securityMetrics.last_vulnerability_scan).toLocaleString('th-TH') : 
                          'N/A'
                        }
                      </span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="threats">
              {/* Display detected threats */}
              {threats && threats.length > 0 ? (
                <div className="space-y-3">
                  <h3 className="text-lg font-semibold text-red-600">ภัยคุกคามที่ตรวจพบ</h3>
                  {threats.map((threat) => (
                    <Alert key={threat.id} className="border-red-200">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-3">
                          <AlertTriangle className="h-4 w-4 text-red-500 mt-1" />
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <h4 className="font-semibold">{threat.title}</h4>
                              <Badge className={
                                threat.severity === 'critical' ? 'bg-red-500 text-white' :
                                threat.severity === 'high' ? 'bg-orange-500 text-white' :
                                threat.severity === 'medium' ? 'bg-yellow-500 text-white' :
                                'bg-green-500 text-white'
                              }>
                                {threat.severity === 'critical' ? 'วิกฤต' : 
                                 threat.severity === 'high' ? 'สูง' :
                                 threat.severity === 'medium' ? 'กลาง' : 'ต่ำ'}
                              </Badge>
                            </div>
                            <AlertDescription>{threat.description}</AlertDescription>
                            <p className="text-xs text-gray-500 mt-2">
                              {new Date(threat.created_at).toLocaleString('th-TH')}
                            </p>
                          </div>
                        </div>
                        {!threat.is_resolved && autoResponseEnabled && (
                          <Button
                            size="sm"
                            onClick={() => autoRespondToThreat.mutate(threat.id)}
                            disabled={isResponding}
                          >
                            {isResponding ? 'Responding...' : 'Auto Respond'}
                          </Button>
                        )}
                      </div>
                    </Alert>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Shield className="h-12 w-12 mx-auto mb-4 text-green-500" />
                  <p className="text-gray-600">ไม่พบภัยคุกคาม - ระบบปลอดภัย</p>
                </div>
              )}
            </TabsContent>

            <TabsContent value="access">
              <AccessControlManager />
            </TabsContent>

            <TabsContent value="compliance">
              <ComplianceMonitor />
            </TabsContent>

            <TabsContent value="analytics">
              {runAdvancedAnalysis.data ? (
                <div className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Brain className="h-5 w-5" />
                        AI Behavioral Analysis
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {runAdvancedAnalysis.data.behavioral_patterns.map((pattern, index) => (
                          <div key={index} className="flex items-center gap-2 text-sm">
                            <CheckCircle className="h-4 w-4 text-green-500" />
                            {pattern}
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Eye className="h-5 w-5" />
                        Predictive Threat Intelligence
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {runAdvancedAnalysis.data.predictive_threats.map((threat, index) => (
                          <div key={index} className="flex items-center gap-2 text-sm">
                            <AlertTriangle className="h-4 w-4 text-yellow-500" />
                            {threat}
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Shield className="h-5 w-5" />
                        Security Recommendations
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {runAdvancedAnalysis.data.recommendations.map((rec, index) => (
                          <div key={index} className="flex items-center gap-2 text-sm">
                            <Zap className="h-4 w-4 text-blue-500" />
                            {rec}
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Button
                    onClick={() => runAdvancedAnalysis.mutate()}
                    disabled={runAdvancedAnalysis.isPending}
                    size="lg"
                  >
                    {runAdvancedAnalysis.isPending ? 'กำลังวิเคราะห์...' : 'เริ่มการวิเคราะห์ AI'}
                  </Button>
                  <p className="text-gray-600 mt-2">คลิกเพื่อเริ่มการวิเคราะห์ความปลอดภัยแบบ AI</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default SecurityBot;
