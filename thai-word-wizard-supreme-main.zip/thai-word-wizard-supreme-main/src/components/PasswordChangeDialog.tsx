import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Key, Eye, EyeOff } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const PasswordChangeDialog = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPasswords, setShowPasswords] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();

  // Improved hash function that properly handles Unicode characters
  const hashPassword = (password: string): string => {
    // Convert string to UTF-8 bytes, then to base64
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const binaryString = String.fromCharCode(...data);
    return btoa(binaryString);
  };

  const handlePasswordChange = async () => {
    if (!user) {
      toast({
        title: "ข้อผิดพลาด",
        description: "ไม่พบข้อมูลผู้ใช้",
        variant: "destructive"
      });
      return;
    }

    if (newPassword !== confirmPassword) {
      toast({
        title: "รหัสผ่านไม่ตรงกัน",
        description: "กรุณากรอกรหัสผ่านใหม่ให้ตรงกัน",
        variant: "destructive"
      });
      return;
    }

    if (newPassword.length < 6) {
      toast({
        title: "รหัสผ่านสั้นเกินไป",
        description: "รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร",
        variant: "destructive"
      });
      return;
    }

    try {
      setIsLoading(true);
      const oldPasswordHash = hashPassword(currentPassword);
      const newPasswordHash = hashPassword(newPassword);

      // Use type assertion to call the change_password function
      const { data, error } = await (supabase.rpc as any)('change_password', {
        _user_id: user.id,
        _old_password_hash: oldPasswordHash,
        _new_password_hash: newPasswordHash
      });

      if (error) {
        console.error('Password change error:', error);
        toast({
          title: "เกิดข้อผิดพลาด",
          description: "ไม่สามารถเปลี่ยนรหัสผ่านได้",
          variant: "destructive"
        });
        return;
      }

      if (data === false) {
        toast({
          title: "รหัสผ่านไม่ถูกต้อง",
          description: "รหัสผ่านปัจจุบันไม่ถูกต้อง",
          variant: "destructive"
        });
        return;
      }

      toast({
        title: "เปลี่ยนรหัสผ่านสำเร็จ",
        description: "รหัสผ่านของคุณได้รับการเปลี่ยนแปลงแล้ว"
      });

      // Reset form
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setIsOpen(false);
    } catch (error) {
      console.error('Password change error:', error);
      toast({
        title: "เกิดข้อผิดพลาด",
        description: "ไม่สามารถเปลี่ยนรหัสผ่านได้",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Key className="w-4 h-4 mr-2" />
          เปลี่ยนรหัสผ่าน
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>เปลี่ยนรหัสผ่าน</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 pt-4">
          <div className="space-y-2">
            <Label htmlFor="current-password">รหัสผ่านปัจจุบัน</Label>
            <div className="relative">
              <Input
                id="current-password"
                type={showPasswords ? "text" : "password"}
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder="กรอกรหัสผ่านปัจจุบัน"
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="new-password">รหัสผ่านใหม่</Label>
            <div className="relative">
              <Input
                id="new-password"
                type={showPasswords ? "text" : "password"}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="กรอกรหัสผ่านใหม่"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="confirm-password">ยืนยันรหัสผ่านใหม่</Label>
            <div className="relative">
              <Input
                id="confirm-password"
                type={showPasswords ? "text" : "password"}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="กรอกรหัสผ่านใหม่อีกครั้ง"
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                onClick={() => setShowPasswords(!showPasswords)}
              >
                {showPasswords ? (
                  <EyeOff className="h-4 w-4" />
                ) : (
                  <Eye className="h-4 w-4" />
                )}
              </Button>
            </div>
          </div>

          <div className="flex gap-2 pt-4">
            <Button 
              onClick={handlePasswordChange} 
              className="flex-1"
              disabled={isLoading || !currentPassword || !newPassword || !confirmPassword}
            >
              {isLoading ? 'กำลังเปลี่ยนรหัสผ่าน...' : 'เปลี่ยนรหัสผ่าน'}
            </Button>
            <Button variant="outline" onClick={() => setIsOpen(false)} className="flex-1">
              ยกเลิก
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default PasswordChangeDialog;
