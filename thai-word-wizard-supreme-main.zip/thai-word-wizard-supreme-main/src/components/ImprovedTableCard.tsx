
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Users, ShoppingCart, Calendar, Plus, Eye, CreditCard } from 'lucide-react';
import { Tables } from '@/integrations/supabase/types';

interface ImprovedTableCardProps {
  table: Tables<'tables'>;
  onOpenTable: (table: Tables<'tables'>) => void;
  onReserveTable: (table: Tables<'tables'>) => void;
  onUpdateStatus: (id: string, status: string) => void;
  onAddToOrder?: (table: Tables<'tables'>) => void;
  onViewTableDetails?: (table: Tables<'tables'>) => void;
  onPayment?: (table: Tables<'tables'>) => void;
  isUpdating: boolean;
}

const ImprovedTableCard = ({ 
  table, 
  onOpenTable, 
  onReserveTable, 
  onUpdateStatus, 
  onAddToOrder,
  onViewTableDetails,
  onPayment,
  isUpdating 
}: ImprovedTableCardProps) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return 'bg-green-500 text-white';
      case 'occupied': return 'bg-red-500 text-white';
      case 'reserved': return 'bg-yellow-500 text-white';
      case 'cleaning': return 'bg-blue-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'available': return 'ว่าง';
      case 'occupied': return 'มีลูกค้า';
      case 'reserved': return 'จอง';
      case 'cleaning': return 'ทำความสะอาด';
      default: return status;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'available': return '✅';
      case 'occupied': return '🍽️';
      case 'reserved': return '📅';
      case 'cleaning': return '🧹';
      default: return '❓';
    }
  };

  const getBorderColor = (status: string) => {
    switch (status) {
      case 'available': return 'border-green-200 shadow-green-100';
      case 'occupied': return 'border-red-200 shadow-red-100';
      case 'reserved': return 'border-yellow-200 shadow-yellow-100';
      case 'cleaning': return 'border-blue-200 shadow-blue-100';
      default: return 'border-gray-200';
    }
  };

  return (
    <Card className={`cursor-pointer border-2 hover:shadow-lg transition-all duration-200 ${getBorderColor(table.status)}`}>
      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-3">
          <div className="flex items-center gap-2">
            <span className="text-2xl">{getStatusIcon(table.status)}</span>
            <h3 className="text-xl font-bold">โต๊ะ {table.table_number}</h3>
          </div>
          <Badge className={`${getStatusColor(table.status)} px-3 py-1`}>
            {getStatusText(table.status)}
          </Badge>
        </div>
        
        <div className="flex items-center gap-2 mb-4">
          <Users className="h-4 w-4 text-gray-500" />
          <span className="text-sm font-medium">{table.seats} ที่นั่ง</span>
        </div>

        <div className="space-y-2">
          {table.status === 'available' && (
            <>
              <Button 
                size="sm" 
                onClick={() => onOpenTable(table)}
                className="w-full bg-green-500 hover:bg-green-600 text-white"
              >
                <ShoppingCart className="h-4 w-4 mr-2" />
                เปิดโต๊ะ/สั่งอาหาร
              </Button>
              <Button 
                size="sm" 
                variant="outline"
                onClick={() => onReserveTable(table)}
                className="w-full"
              >
                <Calendar className="h-4 w-4 mr-2" />
                จองโต๊ะ
              </Button>
            </>
          )}
          
          {table.status === 'occupied' && (
            <>
              {onAddToOrder && (
                <Button 
                  size="sm" 
                  onClick={() => onAddToOrder(table)}
                  className="w-full bg-blue-500 hover:bg-blue-600 text-white"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  สั่งอาหารเพิ่ม
                </Button>
              )}
              {onViewTableDetails && (
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => onViewTableDetails(table)}
                  className="w-full"
                >
                  <Eye className="h-4 w-4 mr-2" />
                  ดูรายละเอียด
                </Button>
              )}
              {onPayment && (
                <Button 
                  size="sm" 
                  onClick={() => onPayment(table)}
                  className="w-full bg-green-500 hover:bg-green-600 text-white"
                  disabled={isUpdating}
                >
                  <CreditCard className="h-4 w-4 mr-2" />
                  ชำระเงิน
                </Button>
              )}
            </>
          )}
          
          {table.status === 'cleaning' && (
            <Button 
              size="sm" 
              variant="outline"
              onClick={() => onUpdateStatus(table.id, 'available')}
              disabled={isUpdating}
              className="w-full bg-blue-50 hover:bg-blue-100"
            >
              ✨ เสร็จแล้ว
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default ImprovedTableCard;
