
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Printer } from 'lucide-react';
import PrintReceiptDialog from './PrintReceiptDialog';

interface PrintButtonProps {
  order: any;
  variant?: 'default' | 'outline' | 'ghost';
  size?: 'sm' | 'default' | 'lg';
  className?: string;
}

const PrintButton = ({ order, variant = 'outline', size = 'sm', className }: PrintButtonProps) => {
  const [showPrintDialog, setShowPrintDialog] = useState(false);

  return (
    <>
      <Button
        variant={variant}
        size={size}
        onClick={() => setShowPrintDialog(true)}
        className={className}
      >
        <Printer className="h-4 w-4 mr-1" />
        ปริ้นต์
      </Button>

      <PrintReceiptDialog
        order={order}
        open={showPrintDialog}
        onOpenChange={setShowPrintDialog}
      />
    </>
  );
};

export default PrintButton;
