
import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Printer, Download, Wifi } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useEpsonPrinter } from '@/hooks/useEpsonPrinter';
import ReceiptTemplate from './ReceiptTemplate';
import EpsonPrintSystem from './EpsonPrintSystem';

interface PrintReceiptDialogProps {
  order: any;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const PrintReceiptDialog = ({ order, open, onOpenChange }: PrintReceiptDialogProps) => {
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const { status, printReceipt, isPrinting } = useEpsonPrinter();

  const handleEpsonPrint = async () => {
    const receiptContent = document.getElementById('receipt-content');
    if (!receiptContent) {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: "ไม่พบเนื้อหาใบเสร็จ",
        variant: "destructive"
      });
      return;
    }

    const success = await printReceipt(receiptContent.innerHTML, order.order_number);
    if (success) {
      onOpenChange(false);
    }
  };

  const handleBrowserPrint = async () => {
    setIsLoading(true);
    try {
      const printWindow = window.open('', '_blank', 'width=302,height=600');
      if (!printWindow) {
        throw new Error('ไม่สามารถเปิดหน้าต่างปริ้นต์ได้');
      }

      const receiptContent = document.getElementById('receipt-content');
      if (!receiptContent) {
        throw new Error('ไม่พบเนื้อหาใบเสร็จ');
      }

      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <title>ใบเสร็จ - ${order.order_number}</title>
          <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { font-family: 'Courier New', monospace; font-size: 12px; line-height: 1.2; width: 80mm; margin: 0; padding: 8px; background: white; }
            .receipt { width: 100%; }
            .header { text-align: center; margin-bottom: 8px; border-bottom: 1px dashed #000; padding-bottom: 8px; }
            .shop-name { font-size: 16px; font-weight: bold; margin-bottom: 4px; }
            .order-info { margin: 8px 0; font-size: 11px; }
            .items { margin: 8px 0; }
            .item { display: flex; justify-content: space-between; margin: 2px 0; font-size: 11px; }
            .item-name { flex: 1; padding-right: 8px; }
            .item-qty { min-width: 20px; text-align: center; }
            .item-price { min-width: 40px; text-align: right; }
            .separator { border-top: 1px dashed #000; margin: 8px 0; }
            .total { display: flex; justify-content: space-between; font-weight: bold; font-size: 14px; margin: 4px 0; }
            .footer { text-align: center; margin-top: 8px; padding-top: 8px; border-top: 1px dashed #000; font-size: 10px; }
            @media print { body { margin: 0; padding: 4px; width: 80mm; } .no-print { display: none; } }
          </style>
        </head>
        <body>
          ${receiptContent.innerHTML}
        </body>
        </html>
      `);

      printWindow.document.close();
      
      setTimeout(() => {
        printWindow.print();
        printWindow.close();
      }, 250);

      toast({
        title: "เปิดหน้าต่างปริ้นต์สำเร็จ",
        description: "กรุณาเลือกเครื่องปริ้นต์และตั้งค่าขนาดกระดาษ 80mm"
      });
      
    } catch (error: any) {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownloadReceipt = () => {
    const receiptContent = document.getElementById('receipt-content');
    if (!receiptContent) return;

    const printContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>ใบเสร็จ - ${order.order_number}</title>
        <style>
          body { font-family: 'Courier New', monospace; font-size: 12px; width: 80mm; margin: 0; padding: 8px; }
          .receipt { width: 100%; }
          .header { text-align: center; margin-bottom: 8px; border-bottom: 1px dashed #000; padding-bottom: 8px; }
          .shop-name { font-size: 16px; font-weight: bold; margin-bottom: 4px; }
          .order-info { margin: 8px 0; font-size: 11px; }
          .items { margin: 8px 0; }
          .item { display: flex; justify-content: space-between; margin: 2px 0; font-size: 11px; }
          .item-name { flex: 1; padding-right: 8px; }
          .item-qty { min-width: 20px; text-align: center; }
          .item-price { min-width: 40px; text-align: right; }
          .separator { border-top: 1px dashed #000; margin: 8px 0; }
          .total { display: flex; justify-content: space-between; font-weight: bold; font-size: 14px; margin: 4px 0; }
          .footer { text-align: center; margin-top: 8px; padding-top: 8px; border-top: 1px dashed #000; font-size: 10px; }
        </style>
      </head>
      <body>
        ${receiptContent.innerHTML}
      </body>
      </html>
    `;

    const blob = new Blob([printContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `receipt-${order.order_number}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    toast({
      title: "ดาวน์โหลดสำเร็จ",
      description: "ไฟล์ใบเสร็จถูกดาวน์โหลดแล้ว สามารถเปิดและปริ้นต์ได้"
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>ระบบปริ้นต์ใบเสร็จ - {order.order_number}</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="epson" className="space-y-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="epson" className="flex items-center gap-2">
              <Wifi className="h-4 w-4" />
              Epson TMT82
            </TabsTrigger>
            <TabsTrigger value="browser" className="flex items-center gap-2">
              <Printer className="h-4 w-4" />
              เบราว์เซอร์
            </TabsTrigger>
            <TabsTrigger value="preview" className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              ตัวอย่าง
            </TabsTrigger>
          </TabsList>

          <TabsContent value="epson" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <div>
                <h3 className="text-lg font-medium mb-4">เครื่องปริ้นต์ Epson TMT82</h3>
                <EpsonPrintSystem order={order} />
              </div>
              <div>
                <h3 className="text-lg font-medium mb-4">ตัวอย่างใบเสร็จ</h3>
                <div className="border rounded-lg p-4 bg-gray-50 max-h-96 overflow-y-auto">
                  <ReceiptTemplate order={order} />
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="browser" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">การปริ้นต์ผ่านเบราว์เซอร์</h3>
                
                <Button 
                  onClick={handleBrowserPrint}
                  disabled={isLoading}
                  className="w-full flex items-center gap-2"
                  size="lg"
                >
                  <Printer className="h-5 w-5" />
                  {isLoading ? 'กำลังเตรียม...' : 'ปริ้นต์ผ่านเบราว์เซอร์'}
                </Button>

                <div className="text-sm text-gray-600 bg-blue-50 p-4 rounded-lg">
                  <p className="font-medium mb-2">💡 วิธีใช้งาน:</p>
                  <ul className="space-y-1 text-xs">
                    <li>• คลิก "ปริ้นต์ผ่านเบราว์เซอร์" เพื่อเปิดหน้าต่างปริ้นต์</li>
                    <li>• เลือกเครื่องปริ้นต์ที่ต้องการ</li>
                    <li>• ตั้งค่าขนาดกระดาษเป็น 80mm หรือ Custom</li>
                    <li>• ปิด header/footer ในการตั้งค่าปริ้นต์</li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-4">ตัวอย่างใบเสร็จ</h3>
                <div className="border rounded-lg p-4 bg-gray-50 max-h-96 overflow-y-auto">
                  <ReceiptTemplate order={order} />
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="preview" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">ดาวน์โหลดใบเสร็จ</h3>
                
                <Button 
                  variant="outline"
                  onClick={handleDownloadReceipt}
                  className="w-full flex items-center gap-2"
                  size="lg"
                >
                  <Download className="h-5 w-5" />
                  ดาวน์โหลดไฟล์ HTML
                </Button>

                <div className="text-sm text-gray-600 bg-green-50 p-4 rounded-lg">
                  <p className="font-medium mb-2">📄 ข้อมูลไฟล์:</p>
                  <ul className="space-y-1 text-xs">
                    <li>• ไฟล์ HTML พร้อมใช้งาน</li>
                    <li>• รองรับการปริ้นต์ขนาด 80mm</li>
                    <li>• เปิดได้ด้วยเบราว์เซอร์</li>
                    <li>• สามารถปริ้นต์หรือแชร์ได้</li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-4">ตัวอย่างใบเสร็จ</h3>
                <div className="border rounded-lg p-4 bg-gray-50 max-h-96 overflow-y-auto">
                  <ReceiptTemplate order={order} />
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};

export default PrintReceiptDialog;
