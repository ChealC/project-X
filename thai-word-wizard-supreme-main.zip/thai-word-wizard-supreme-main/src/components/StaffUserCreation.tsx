import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Users, UserPlus, Shield, Check, X } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

type StaffRole = 'admin' | 'manager' | 'kitchen_staff' | 'service_staff';

interface StaffWithAccount {
  id: string;
  name: string;
  position: string;
  employee_id: string;
  is_active: boolean;
  user_account?: {
    id: string;
    username: string;
    role: StaffRole;
    is_active: boolean;
  } | null;
}

const StaffUserCreation = () => {
  const [creatingAccounts, setCreatingAccounts] = useState<string[]>([]);
  const [createdAccounts, setCreatedAccounts] = useState<any[]>([]);
  const [autoCreateTriggered, setAutoCreateTriggered] = useState(false);
  const { toast } = useToast();
  const { hasPermission } = useAuth();
  const queryClient = useQueryClient();

  const { data: staffList, isLoading } = useQuery({
    queryKey: ['staff-with-accounts'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('staff')
        .select(`
          *,
          user_accounts (
            id,
            username,
            role,
            is_active
          )
        `)
        .eq('is_active', true)
        .order('name');
      
      if (error) throw error;
      return data as StaffWithAccount[];
    }
  });

  // Hash password function (same as in AuthContext)
  const hashPassword = (password: string): string => {
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const binaryString = String.fromCharCode(...data);
    return btoa(binaryString);
  };

  // Determine role based on position
  const determineRole = (position: string): StaffRole => {
    const pos = position.toLowerCase();
    if (pos.includes('ผู้จัดการ') || pos.includes('manager')) return 'manager';
    if (pos.includes('ครัว') || pos.includes('chef') || pos.includes('cook')) return 'kitchen_staff';
    if (pos.includes('เสิร์ฟ') || pos.includes('service') || pos.includes('cashier') || pos.includes('แคชเชียร์')) return 'service_staff';
    return 'service_staff'; // Default
  };

  // Generate username based on name and position
  const generateUsername = (name: string, position: string): string => {
    const nameParts = name.split(' ');
    const firstName = nameParts[0];
    const pos = position.toLowerCase();
    
    if (pos.includes('ครัว') || pos.includes('chef')) {
      return `chef_${firstName.toLowerCase()}`;
    } else if (pos.includes('แคชเชียร์') || pos.includes('cashier')) {
      return `cashier_${firstName.toLowerCase()}`;
    } else if (pos.includes('ผู้จัดการ') || pos.includes('manager')) {
      return `manager_${firstName.toLowerCase()}`;
    } else {
      return `service_${firstName.toLowerCase()}`;
    }
  };

  // Generate default password
  const generatePassword = (role: StaffRole): string => {
    switch (role) {
      case 'manager': return 'manager123';
      case 'kitchen_staff': return 'kitchen123';
      case 'service_staff': return 'service123';
      default: return 'staff123';
    }
  };

  const createAllAccountsMutation = useMutation({
    mutationFn: async () => {
      const staffWithoutAccounts = staffList?.filter(staff => !staff.user_account) || [];
      const results = [];

      console.log('=== เริ่มสร้างบัญชีทั้งหมด ===');
      console.log(`จำนวนพนักงานที่ต้องสร้างบัญชี: ${staffWithoutAccounts.length} คน`);

      for (const staff of staffWithoutAccounts) {
        try {
          const role = determineRole(staff.position);
          const username = generateUsername(staff.name, staff.position);
          const password = generatePassword(role);
          const passwordHash = hashPassword(password);

          console.log(`สร้างบัญชี: ${staff.name} - Username: ${username}`);

          // Remove created_at and updated_at from the insert
          const { data, error } = await supabase
            .from('user_accounts')
            .insert({
              staff_id: staff.id,
              username: username,
              password_hash: passwordHash,
              role: role,
              is_active: true
            })
            .select('*')
            .single();

          if (error) {
            console.error(`Error creating account for ${staff.name}:`, error);
            throw error;
          }
          
          const accountInfo = { 
            staff: staff.name, 
            username, 
            password, 
            role,
            staff_id: staff.id,
            employee_id: staff.employee_id,
            position: staff.position
          };
          
          results.push(accountInfo);
          console.log(`✓ สร้างบัญชีสำเร็จ: ${staff.name}`);
          
        } catch (error) {
          console.error(`❌ ไม่สามารถสร้างบัญชีสำหรับ ${staff.name}:`, error);
        }
      }

      console.log(`=== เสร็จสิ้น: สร้างบัญชี ${results.length}/${staffWithoutAccounts.length} บัญชี ===`);
      return results;
    },
    onSuccess: (results) => {
      setCreatedAccounts(results);
      toast({
        title: "สร้างบัญชีทั้งหมดสำเร็จ! 🎉",
        description: `สร้างบัญชีสำหรับพนักงาน ${results.length} คน เรียบร้อยแล้ว`
      });
      queryClient.invalidateQueries({ queryKey: ['staff-with-accounts'] });
    },
    onError: (error) => {
      console.error('Error creating all accounts:', error);
      toast({
        title: "เกิดข้อผิดพลาด",
        description: "ไม่สามารถสร้างบัญชีทั้งหมดได้",
        variant: "destructive"
      });
    }
  });

  const createAccountMutation = useMutation({
    mutationFn: async (staff: StaffWithAccount) => {
      const role = determineRole(staff.position);
      const username = generateUsername(staff.name, staff.position);
      const password = generatePassword(role);
      const passwordHash = hashPassword(password);

      console.log(`สร้างบัญชีเดี่ยว: ${staff.name} - Username: ${username}`);

      // Remove created_at and updated_at from the insert
      const { data, error } = await supabase
        .from('user_accounts')
        .insert({
          staff_id: staff.id,
          username: username,
          password_hash: passwordHash,
          role: role,
          is_active: true
        })
        .select('*')
        .single();

      if (error) throw error;
      
      return { username, password, role, staff_name: staff.name };
    },
    onSuccess: (data, staff) => {
      toast({
        title: "สร้างบัญชีสำเร็จ",
        description: `สร้างบัญชีสำหรับ ${staff.name} เรียบร้อยแล้ว\nUsername: ${data.username}\nPassword: ${data.password}`
      });
      queryClient.invalidateQueries({ queryKey: ['staff-with-accounts'] });
      setCreatingAccounts(prev => prev.filter(id => id !== staff.id));
    },
    onError: (error, staff) => {
      console.error('Error creating account:', error);
      toast({
        title: "เกิดข้อผิดพลาด",
        description: `ไม่สามารถสร้างบัญชีสำหรับ ${staff.name} ได้`,
        variant: "destructive"
      });
      setCreatingAccounts(prev => prev.filter(id => id !== staff.id));
    }
  });

  // Auto-trigger account creation when data loads and there are staff without accounts
  useEffect(() => {
    if (staffList && !autoCreateTriggered && !isLoading) {
      const staffWithoutAccounts = staffList.filter(staff => !staff.user_account);
      if (staffWithoutAccounts.length > 0) {
        setAutoCreateTriggered(true);
        console.log('🚀 Auto-triggering account creation for all staff without accounts');
        handleCreateAllAccounts();
      }
    }
  }, [staffList, autoCreateTriggered, isLoading]);

  const handleCreateAccount = (staff: StaffWithAccount) => {
    setCreatingAccounts(prev => [...prev, staff.id]);
    createAccountMutation.mutate(staff);
  };

  const handleCreateAllAccounts = () => {
    createAllAccountsMutation.mutate();
  };

  const getRoleLabel = (role: StaffRole) => {
    switch (role) {
      case 'admin': return 'ผู้ดูแลระบบ';
      case 'manager': return 'ผู้จัดการ';
      case 'kitchen_staff': return 'พนักงานครัว';
      case 'service_staff': return 'พนักงานเสิร์ฟ';
      default: return role;
    }
  };

  const getRoleColor = (role: StaffRole) => {
    switch (role) {
      case 'admin': return 'bg-red-500';
      case 'manager': return 'bg-blue-500';
      case 'kitchen_staff': return 'bg-green-500';
      case 'service_staff': return 'bg-orange-500';
      default: return 'bg-gray-500';
    }
  };

  if (!hasPermission('staff', 'edit')) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <Shield className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600">ไม่มีสิทธิ์ในการสร้างบัญชีผู้ใช้</p>
        </CardContent>
      </Card>
    );
  }

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-600">กำลังโหลดข้อมูลพนักงาน...</p>
        </CardContent>
      </Card>
    );
  }

  const staffWithoutAccounts = staffList?.filter(staff => !staff.user_account) || [];
  const staffWithAccounts = staffList?.filter(staff => staff.user_account) || [];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <UserPlus className="w-5 h-5" />
              สร้างบัญชีผู้ใช้สำหรับพนักงาน
            </CardTitle>
            {staffWithoutAccounts.length > 0 && (
              <Button 
                onClick={handleCreateAllAccounts}
                disabled={createAllAccountsMutation.isPending}
                className="bg-green-500 hover:bg-green-600 text-white font-semibold"
                size="lg"
              >
                <Users className="w-4 h-4 mr-2" />
                {createAllAccountsMutation.isPending ? 'กำลังสร้างบัญชีทั้งหมด...' : `สร้างบัญชีทั้งหมด (${staffWithoutAccounts.length} คน)`}
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {/* Auto-creation status */}
          {createAllAccountsMutation.isPending && (
            <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-500"></div>
                <div>
                  <h3 className="font-semibold text-blue-800">🚀 กำลังสร้างบัญชีทั้งหมดโดยอัตโนมัติ</h3>
                  <p className="text-blue-700 text-sm">กรุณารอสักครู่ ระบบกำลังสร้างบัญชีสำหรับพนักงานทั้งหมด...</p>
                </div>
              </div>
            </div>
          )}

          {staffWithoutAccounts.length > 0 ? (
            <div className="space-y-4">
              <h3 className="font-semibold text-lg text-red-600">
                พนักงานที่ยังไม่มีบัญชี ({staffWithoutAccounts.length} คน)
              </h3>
              <div className="grid gap-4">
                {staffWithoutAccounts.map((staff) => {
                  const suggestedRole = determineRole(staff.position);
                  const suggestedUsername = generateUsername(staff.name, staff.position);
                  const isCreating = creatingAccounts.includes(staff.id);

                  return (
                    <Card key={staff.id} className="p-4 border border-red-200 bg-red-50">
                      <div className="flex justify-between items-center">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <h4 className="font-semibold">{staff.name}</h4>
                            <Badge variant="outline">{staff.position}</Badge>
                            <Badge className={`${getRoleColor(suggestedRole)} text-white`}>
                              {getRoleLabel(suggestedRole)}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600">รหัสพนักงาน: {staff.employee_id}</p>
                          <p className="text-sm text-blue-600">Username: {suggestedUsername}</p>
                        </div>
                        <Button
                          onClick={() => handleCreateAccount(staff)}
                          disabled={isCreating}
                          className="bg-blue-500 hover:bg-blue-600"
                        >
                          {isCreating ? (
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
                          ) : (
                            <>
                              <UserPlus className="w-4 h-4 mr-2" />
                              สร้างบัญชี
                            </>
                          )}
                        </Button>
                      </div>
                    </Card>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="text-center py-8">
              <Check className="w-12 h-12 text-green-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-green-600 mb-2">
                พนักงานทุกคนมีบัญชีแล้ว
              </h3>
              <p className="text-gray-600">พนักงานทั้งหมดได้รับการสร้างบัญชีผู้ใช้เรียบร้อยแล้ว</p>
            </div>
          )}

          {/* แสดงรายการบัญชีที่สร้างใหม่ */}
          {createdAccounts.length > 0 && (
            <div className="mt-8 space-y-4">
              <h3 className="font-semibold text-lg text-green-600">
                บัญชีที่สร้างใหม่ ({createdAccounts.length} บัญชี)
              </h3>
              <div className="grid gap-3">
                {createdAccounts.map((account, index) => (
                  <Card key={index} className="p-4 border border-green-200 bg-green-50">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <h4 className="font-semibold">{account.staff}</h4>
                        <Badge variant="outline">{account.position}</Badge>
                        <Badge className={`${getRoleColor(account.role)} text-white`}>
                          {getRoleLabel(account.role)}
                        </Badge>
                      </div>
                      <div className="text-sm space-y-1">
                        <p><strong>Username:</strong> <code className="bg-blue-100 px-2 py-1 rounded">{account.username}</code></p>
                        <p><strong>Password:</strong> <code className="bg-red-100 px-2 py-1 rounded">{account.password}</code></p>
                        <p className="text-gray-600">รหัสพนักงาน: {account.employee_id}</p>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {staffWithAccounts.length > 0 && (
            <div className="mt-8 space-y-4">
              <h3 className="font-semibold text-lg text-green-600">
                พนักงานที่มีบัญชีแล้ว ({staffWithAccounts.length} คน)
              </h3>
              <div className="grid gap-3">
                {staffWithAccounts.map((staff) => (
                  <Card key={staff.id} className="p-3 border border-green-200 bg-green-50">
                    <div className="flex justify-between items-center">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <h4 className="font-semibold">{staff.name}</h4>
                          <Badge variant="outline">{staff.position}</Badge>
                          {staff.user_account && (
                            <Badge className={`${getRoleColor(staff.user_account.role)} text-white`}>
                              {getRoleLabel(staff.user_account.role)}
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-gray-600">
                          Username: {staff.user_account?.username}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="w-5 h-5 text-green-500" />
                        <Badge variant="secondary">มีบัญชีแล้ว</Badge>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5" />
            การแยกสิทธิตามตำแหน่ง
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
              <h3 className="font-semibold text-blue-800 mb-2">ผู้จัดการ (Manager)</h3>
              <ul className="text-sm text-blue-700 space-y-1">
                <li>• เข้าถึงได้เกือบทุกระบบ</li>
                <li>• จัดการโต๊ะและคำสั่งซื้อ</li>
                <li>• ดูรายงานการขาย</li>
                <li>• จัดการสต็อก</li>
              </ul>
            </div>
            
            <div className="bg-green-50 p-4 rounded-lg border border-green-200">
              <h3 className="font-semibold text-green-800 mb-2">พนักงานครัว (Chef/Cook)</h3>
              <ul className="text-sm text-green-700 space-y-1">
                <li>• ระบบครัวและคิว</li>
                <li>• ดูคำสั่งซื้อ (อ่านอย่างเดียว)</li>
                <li>• ดูเมนู (อ่านอย่างเดียว)</li>
                <li>• เช็คชื่อเข้า-ออกงาน</li>
              </ul>
            </div>
            
            <div className="bg-orange-50 p-4 rounded-lg border border-orange-200">
              <h3 className="font-semibold text-orange-800 mb-2">พนักงานเสิร์ฟ (Service)</h3>
              <ul className="text-sm text-orange-700 space-y-1">
                <li>• จัดการโต๊ะและคำสั่งซื้อ</li>
                <li>• ระบบชำระเงิน</li>
                <li>• ดูเมนู (อ่านอย่างเดียว)</li>
                <li>• เช็คชื่อเข้า-ออกงาน</li>
              </ul>
            </div>
            
            <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
              <h3 className="font-semibold text-purple-800 mb-2">แคชเชียร์ (Cashier)</h3>
              <ul className="text-sm text-purple-700 space-y-1">
                <li>• ระบบชำระเงิน</li>
                <li>• จัดการโต๊ะ</li>
                <li>• ดูคำสั่งซื้อและเมนู</li>
                <li>• เช็คชื่อเข้า-ออกงาน</li>
              </ul>
            </div>
          </div>

          <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <h3 className="font-semibold text-yellow-800 mb-2">รหัสผ่านเริ่มต้น</h3>
            <div className="text-sm text-yellow-700 grid grid-cols-1 md:grid-cols-2 gap-2">
              <div><strong>ผู้จัดการ:</strong> <code>manager123</code></div>
              <div><strong>พนักงานครัว:</strong> <code>kitchen123</code></div>
              <div><strong>พนักงานเสิร์ฟ:</strong> <code>service123</code></div>
              <div><strong>แคชเชียร์:</strong> <code>service123</code></div>
            </div>
            <p className="text-sm text-yellow-700 mt-2">
              <strong>หมายเหตุ:</strong> แนะนำให้พนักงานเปลี่ยนรหัสผ่านหลังจากเข้าสู่ระบบครั้งแรก
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default StaffUserCreation;
