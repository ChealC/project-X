import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { supabase } from '@/integrations/supabase/client';
import { Package, Plus, Minus, AlertTriangle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import InventoryForm from './InventoryForm';

const StockManagement = () => {
  const [selectedItem, setSelectedItem] = useState<string>('');
  const [transactionType, setTransactionType] = useState<'in' | 'out'>('in');
  const [quantity, setQuantity] = useState<number>(0);
  const [notes, setNotes] = useState<string>('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: inventoryItems } = useQuery({
    queryKey: ['inventory-items'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('inventory_items')
        .select('*')
        .order('name');
      
      if (error) throw error;
      return data;
    }
  });

  const { data: stockTransactions } = useQuery({
    queryKey: ['stock-transactions'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('stock_transactions')
        .select(`
          *,
          inventory_items(name),
          staff(name)
        `)
        .order('transaction_date', { ascending: false })
        .limit(20);
      
      if (error) throw error;
      return data;
    }
  });

  const updateStock = useMutation({
    mutationFn: async ({ itemId, quantity, type, notes }: { 
      itemId: string; 
      quantity: number; 
      type: 'in' | 'out'; 
      notes: string; 
    }) => {
      // Create transaction record
      const { error: transactionError } = await supabase
        .from('stock_transactions')
        .insert({
          inventory_item_id: itemId,
          transaction_type: type,
          quantity: quantity,
          notes: notes
        });

      if (transactionError) throw transactionError;

      // Update current stock
      const item = inventoryItems?.find(i => i.id === itemId);
      if (!item) throw new Error('Item not found');

      const newStock = type === 'in' 
        ? item.current_stock + quantity 
        : item.current_stock - quantity;

      const { error: updateError } = await supabase
        .from('inventory_items')
        .update({ 
          current_stock: Math.max(0, newStock),
          updated_at: new Date().toISOString()
        })
        .eq('id', itemId);

      if (updateError) throw updateError;
    },
    onSuccess: () => {
      setSelectedItem('');
      setQuantity(0);
      setNotes('');
      queryClient.invalidateQueries({ queryKey: ['inventory-items'] });
      queryClient.invalidateQueries({ queryKey: ['stock-transactions'] });
      toast({
        title: "อัปเดตสต็อกสำเร็จ",
        description: "สต็อกสินค้าได้รับการอัปเดตแล้ว"
      });
    }
  });

  const getStockStatus = (current: number, min: number) => {
    if (current <= 0) return { label: 'หมด', color: 'bg-red-500' };
    if (current <= min) return { label: 'ใกล้หมด', color: 'bg-yellow-500' };
    return { label: 'ปกติ', color: 'bg-green-500' };
  };

  return (
    <div className="space-y-6">
      <InventoryForm />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Inventory List */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Package className="h-5 w-5" />
              รายการสต็อค
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {inventoryItems?.map((item) => {
                const status = getStockStatus(item.current_stock || 0, item.min_stock || 0);
                return (
                  <Card key={item.id} className="p-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <h3 className="font-semibold">{item.name}</h3>
                        <p className="text-sm text-gray-600">
                          {item.current_stock} {item.unit} 
                          {item.min_stock && ` (ขั้นต่ำ: ${item.min_stock})`}
                        </p>
                        {item.cost_per_unit && (
                          <p className="text-sm text-gray-600">
                            ราคาต้นทุน: ฿{item.cost_per_unit}/{item.unit}
                          </p>
                        )}
                      </div>
                      <div className="flex items-center gap-3">
                        <Badge className={`${status.color} text-white`}>
                          {status.label}
                        </Badge>
                        <div className="flex gap-1">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => {
                                  setSelectedItem(item.id);
                                  setTransactionType('in');
                                }}
                              >
                                <Plus className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>เพิ่มสต็อค - {item.name}</DialogTitle>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div>
                                  <label className="text-sm font-medium mb-2 block">จำนวน ({item.unit})</label>
                                  <Input
                                    type="number"
                                    value={quantity || ''}
                                    onChange={(e) => setQuantity(Number(e.target.value))}
                                    placeholder="จำนวนที่ต้องการเพิ่ม"
                                  />
                                </div>
                                <div>
                                  <label className="text-sm font-medium mb-2 block">หมายเหตุ</label>
                                  <Input
                                    value={notes}
                                    onChange={(e) => setNotes(e.target.value)}
                                    placeholder="เช่น ซื้อเพิ่ม, รับคืน"
                                  />
                                </div>
                                <Button
                                  className="w-full"
                                  onClick={() => updateStock.mutate({
                                    itemId: item.id,
                                    quantity,
                                    type: 'in',
                                    notes
                                  })}
                                  disabled={updateStock.isPending || quantity <= 0}
                                >
                                  เพิ่มสต็อค
                                </Button>
                              </div>
                            </DialogContent>
                          </Dialog>

                          <Dialog>
                            <DialogTrigger asChild>
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => {
                                  setSelectedItem(item.id);
                                  setTransactionType('out');
                                }}
                              >
                                <Minus className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>เบิกสต็อค - {item.name}</DialogTitle>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div>
                                  <label className="text-sm font-medium mb-2 block">จำนวน ({item.unit})</label>
                                  <Input
                                    type="number"
                                    value={quantity || ''}
                                    onChange={(e) => setQuantity(Number(e.target.value))}
                                    placeholder="จำนวนที่ต้องการเบิก"
                                    max={item.current_stock}
                                  />
                                  <p className="text-sm text-gray-600 mt-1">
                                    คงเหลือ: {item.current_stock} {item.unit}
                                  </p>
                                </div>
                                <div>
                                  <label className="text-sm font-medium mb-2 block">หมายเหตุ</label>
                                  <Input
                                    value={notes}
                                    onChange={(e) => setNotes(e.target.value)}
                                    placeholder="เช่น ใช้ในครัว, เสียหาย"
                                  />
                                </div>
                                <Button
                                  className="w-full"
                                  onClick={() => updateStock.mutate({
                                    itemId: item.id,
                                    quantity,
                                    type: 'out',
                                    notes
                                  })}
                                  disabled={updateStock.isPending || quantity <= 0 || quantity > (item.current_stock || 0)}
                                >
                                  เบิกสต็อค
                                </Button>
                              </div>
                            </DialogContent>
                          </Dialog>
                        </div>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Recent Transactions */}
        <Card>
          <CardHeader>
            <CardTitle>ประวัติการเคลื่อนไหวสต็อค</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {stockTransactions?.map((transaction) => (
                <div key={transaction.id} className="flex justify-between items-center p-3 border rounded">
                  <div>
                    <h4 className="font-medium">{transaction.inventory_items?.name}</h4>
                    <p className="text-sm text-gray-600">
                      {new Date(transaction.transaction_date).toLocaleDateString('th-TH')} {' '}
                      {new Date(transaction.transaction_date).toLocaleTimeString('th-TH')}
                    </p>
                    {transaction.notes && (
                      <p className="text-sm text-gray-500">{transaction.notes}</p>
                    )}
                  </div>
                  <div className="text-right">
                    <span className={`font-bold ${
                      transaction.transaction_type === 'in' ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {transaction.transaction_type === 'in' ? '+' : '-'}{transaction.quantity}
                    </span>
                    <p className="text-sm text-gray-600">
                      {transaction.transaction_type === 'in' ? 'เพิ่ม' : 'เบิก'}
                    </p>
                  </div>
                </div>
              ))}

              {!stockTransactions?.length && (
                <p className="text-center text-gray-500 py-8">ไม่มีประวัติการเคลื่อนไหวสต็อค</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default StockManagement;
