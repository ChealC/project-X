
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { Plus, Edit, Trash2, RefreshCw } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const MenuManagement = () => {
  const [newItem, setNewItem] = useState({
    name: '',
    description: '',
    price: 0,
    category_id: '',
    preparation_time: 15,
    is_available: true
  });
  const [editingItem, setEditingItem] = useState<any>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch menu categories
  const { data: categories } = useQuery({
    queryKey: ['menu-categories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('menu_categories')
        .select('*')
        .order('sort_order');
      
      if (error) throw error;
      return data;
    }
  });

  // Fetch menu items
  const { data: menuItems, refetch: refetchMenuItems } = useQuery({
    queryKey: ['menu-items'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('menu_items')
        .select('*, menu_categories(name)')
        .order('name');
      
      if (error) throw error;
      return data;
    }
  });

  // Add menu item mutation
  const addMenuItem = useMutation({
    mutationFn: async (item: any) => {
      const { error } = await supabase
        .from('menu_items')
        .insert(item);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['menu-items'] });
      setNewItem({
        name: '',
        description: '',
        price: 0,
        category_id: '',
        preparation_time: 15,
        is_available: true
      });
      toast({
        title: "เพิ่มเมนูสำเร็จ",
        description: "เมนูใหม่ได้ถูกเพิ่มแล้ว"
      });
    }
  });

  // Update menu item mutation
  const updateMenuItem = useMutation({
    mutationFn: async ({ id, ...updates }: any) => {
      const { error } = await supabase
        .from('menu_items')
        .update(updates)
        .eq('id', id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['menu-items'] });
      setEditingItem(null);
      toast({
        title: "อัปเดตสำเร็จ",
        description: "ข้อมูลเมนูได้ถูกอัปเดตแล้ว"
      });
    }
  });

  // Delete menu item mutation
  const deleteMenuItem = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('menu_items')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['menu-items'] });
      toast({
        title: "ลบสำเร็จ",
        description: "เมนูได้ถูกลบแล้ว"
      });
    }
  });

  // Add sample menu items mutation
  const addSampleMenuItems = useMutation({
    mutationFn: async () => {
      // Get category IDs first
      const { data: categoriesData } = await supabase
        .from('menu_categories')
        .select('id, name');

      if (!categoriesData || categoriesData.length === 0) {
        throw new Error('ไม่พบหมวดหมู่เมนู กรุณาเพิ่มหมวดหมู่ก่อน');
      }

      const categoryMap = categoriesData.reduce((acc: any, cat: any) => {
        acc[cat.name] = cat.id;
        return acc;
      }, {});

      const sampleMenuItems = [
        // อาหารจานเดียว
        { name: 'ข้าวผัดกุ้ง', description: 'ข้าวผัดกุ้งสดใส่ไข่', price: 80, category_name: 'อาหารจานเดียว' },
        { name: 'ข้าวผัดปู', description: 'ข้าวผัดเนื้อปูแท้', price: 120, category_name: 'อาหารจานเดียว' },
        { name: 'ข้าวผัดหมู', description: 'ข้าวผัดหมูใส่ไข่', price: 60, category_name: 'อาหารจานเดียว' },
        { name: 'ข้าวผัดไก่', description: 'ข้าวผัดไก่ใส่ไข่', price: 60, category_name: 'อาหารจานเดียว' },
        { name: 'ข้าวผัดแหนม', description: 'ข้าวผัดแหนมใส่ไข่', price: 70, category_name: 'อาหารจานเดียว' },
        { name: 'ข้าวผัดปลาเค็ม', description: 'ข้าวผัดปลาเค็มใส่ไข่', price: 70, category_name: 'อาหารจานเดียว' },
        { name: 'ข้าวคลุกกะปิ', description: 'ข้าวคลุกกะปิพร้อมเครื่องเคียง', price: 80, category_name: 'อาหารจานเดียว' },
        { name: 'ข้าวผัดต้มยำกุ้ง', description: 'ข้าวผัดรสต้มยำกุ้ง', price: 90, category_name: 'อาหารจานเดียว' },
        { name: 'ข้าวผัดสับปะรด', description: 'ข้าวผัดสับปะรดใส่กุ้ง', price: 100, category_name: 'อาหารจานเดียว' },
        { name: 'ข้าวผัดกะเพรา', description: 'ข้าวผัดกะเพราไก่ใส่ไข่ดาว', price: 65, category_name: 'อาหารจานเดียว' },

        // ผัดไทย และก๋วยเตี๋ยว
        { name: 'ผัดไทยกุ้งสด', description: 'ผัดไทยกุ้งสดรสชาติดั้งเดิม', price: 80, category_name: 'ผัดไทย และก๋วยเตี๋ยว' },
        { name: 'ผัดไทยหมู', description: 'ผัดไทยหมูสับ', price: 60, category_name: 'ผัดไทย และก๋วยเตี๋ยว' },
        { name: 'ผัดไทยไก่', description: 'ผัดไทยไก่สับ', price: 60, category_name: 'ผัดไทย และก๋วยเตี๋ยว' },
        { name: 'ผัดไทยทะเล', description: 'ผัดไทยอาหารทะเลรวม', price: 120, category_name: 'ผัดไทย และก๋วยเตี๋ยว' },
        { name: 'ผัดซีอิ๊ว', description: 'เส้นใหญ่ผัดซีอิ๊วดำ', price: 60, category_name: 'ผัดไทย และก๋วยเตี๋ยว' },
        { name: 'ผัดขี้เมา', description: 'เส้นใหญ่ผัดขี้เมาใส่กะเพรา', price: 70, category_name: 'ผัดไทย และก๋วยเตี๋ยว' },
        { name: 'ราดหน้า', description: 'เส้นใหญ่ราดหน้าหมูและคะน้า', price: 70, category_name: 'ผัดไทย และก๋วยเตี๋ยว' },
        { name: 'ก๋วยเตี๋ยวน้ำใส', description: 'ก๋วยเตี๋ยวน้ำใสหมูหรือไก่', price: 50, category_name: 'ผัดไทย และก๋วยเตี๋ยว' },
        { name: 'ก๋วยเตี๋ยวต้มยำ', description: 'ก๋วยเตี๋ยวต้มยำกุ้ง', price: 70, category_name: 'ผัดไทย และก๋วยเตี๋ยว' },
        { name: 'ก๋วยเตี๋ยวเรือ', description: 'ก๋วยเตี๋ยวเรือน้ำตก', price: 60, category_name: 'ผัดไทย และก๋วยเตี๋ยว' },

        // ของหวาน
        { name: 'ข้าวเหนียวมะม่วง', description: 'ข้าวเหนียวมะม่วงสุกหวาน', price: 60, category_name: 'ของหวาน' },
        { name: 'ทับทิมกรอบ', description: 'ทับทิมกรอบน้ำกะทิ', price: 40, category_name: 'ของหวาน' },
        { name: 'บัวลอย', description: 'บัวลอยน้ำกะทิ', price: 35, category_name: 'ของหวาน' },
        { name: 'ข้าวต้มมัด', description: 'ข้าวต้มมัดใส่กะทิ', price: 30, category_name: 'ของหวาน' },
        { name: 'ฟักทองแกง', description: 'ฟักทองแกงน้ำกะทิ', price: 40, category_name: 'ของหวาน' },
        { name: 'ไอศกรีมกะทิ', description: 'ไอศกรีมกะทิโฮมเมด', price: 35, category_name: 'ของหวาน' },
        { name: 'ลอดช่อง', description: 'ลอดช่องน้ำกะทิ', price: 40, category_name: 'ของหวาน' },
        { name: 'ขนมครก', description: 'ขนมครกร้อนๆ', price: 25, category_name: 'ของหวาน' },
        { name: 'มันเทศแกง', description: 'มันเทศแกงน้ำกะทิ', price: 35, category_name: 'ของหวาน' },

        // เครื่องดื่ม
        { name: 'ชาเย็น', description: 'ชาเย็นหวานมัน', price: 25, category_name: 'เครื่องดื่ม' },
        { name: 'ชาร้อน', description: 'ชาร้อนหอมๆ', price: 20, category_name: 'เครื่องดื่ม' },
        { name: 'กาแฟเย็น', description: 'กาแฟเย็นหวานมัน', price: 30, category_name: 'เครื่องดื่ม' },
        { name: 'กาแฟร้อน', description: 'กาแฟร้อนเข้มข้น', price: 25, category_name: 'เครื่องดื่ม' },
        { name: 'น้ำส้ม', description: 'น้ำส้มคั้นสด', price: 35, category_name: 'เครื่องดื่ม' },
        { name: 'น้ำมะนาว', description: 'น้ำมะนาวคั้นสด', price: 30, category_name: 'เครื่องดื่ม' },
        { name: 'น้ำแก้วมังกร', description: 'น้ำแก้วมังกรสดชื่น', price: 40, category_name: 'เครื่องดื่ม' },
        { name: 'โอวัลติน', description: 'โอวัลตินเย็นหรือร้อน', price: 35, category_name: 'เครื่องดื่ม' },
        { name: 'นมสด', description: 'นมสดเย็นหรือร้อน', price: 25, category_name: 'เครื่องดื่ม' },
        { name: 'น้ำเปล่า', description: 'น้ำเปล่าขวด', price: 10, category_name: 'เครื่องดื่ม' },

        // อาหารตามสั่ง
        { name: 'กะเพราไก่', description: 'กะเพราไก่ใส่ไข่ดาว', price: 60, category_name: 'อาหารตามสั่ง' },
        { name: 'กะเพราหมู', description: 'กะเพราหมูใส่ไข่ดาว', price: 60, category_name: 'อาหารตามสั่ง' },
        { name: 'กะเพราเนื้อ', description: 'กะเพราเนื้อใส่ไข่ดาว', price: 80, category_name: 'อาหารตามสั่ง' },
        { name: 'กะเพรากุ้ง', description: 'กะเพรากุ้งสดใส่ไข่ดาว', price: 90, category_name: 'อาหารตามสั่ง' },
        { name: 'กะเพราปลาหมึก', description: 'กะเพราปลาหมึกใส่ไข่ดาว', price: 85, category_name: 'อาหารตามสั่ง' },
        { name: 'ผัดพริกแกงไก่', description: 'ผัดพริกแกงไก่ใส่ใบมะกรูด', price: 70, category_name: 'อาหารตามสั่ง' },
        { name: 'ผัดพริกแกงหมู', description: 'ผัดพริกแกงหมูใส่ใบมะกรูด', price: 70, category_name: 'อาหารตามสั่ง' },
        { name: 'ผัดเปรี้ยวหวานไก่', description: 'ผัดเปรี้ยวหวานไก่สับปะรด', price: 75, category_name: 'อาหารตามสั่ง' },
        { name: 'ผัดเปรี้ยวหวานหมู', description: 'ผัดเปรี้ยวหวานหมูสับปะรด', price: 75, category_name: 'อาหารตามสั่ง' },
        { name: 'ผัดขิงไก่', description: 'ผัดขิงไก่ใส่เห็ดหูหนู', price: 70, category_name: 'อาหารตามสั่ง' },
        { name: 'ผัดขิงหมู', description: 'ผัดขิงหมูใส่เห็ดหูหนู', price: 70, category_name: 'อาหารตามสั่ง' },
        { name: 'ผัดผักรวม', description: 'ผัดผักรวมใส่เต้าหู้', price: 50, category_name: 'อาหารตามสั่ง' },
        { name: 'ผัดผักบุ้งไฟแดง', description: 'ผัดผักบุ้งไฟแดง', price: 50, category_name: 'อาหารตามสั่ง' },
        { name: 'ต้มยำกุ้ง', description: 'ต้มยำกุ้งน้ำใส', price: 120, category_name: 'อาหารตามสั่ง' },
        { name: 'ต้มยำไก่', description: 'ต้มยำไก่น้ำใส', price: 80, category_name: 'อาหารตามสั่ง' },
        { name: 'ต้มขาหมู', description: 'ต้มขาหมูยาจีน', price: 150, category_name: 'อาหารตามสั่ง' },
        { name: 'แกงจืดเต้าหู้หมูสับ', description: 'แกงจืดเต้าหู้หมูสับใส่ต้นหอม', price: 60, category_name: 'อาหารตามสั่ง' },
        { name: 'แกงจืดฟักเต้าหู้', description: 'แกงจืดฟักเต้าหู้ใส่หมูสับ', price: 60, category_name: 'อาหารตามสั่ง' },
        { name: 'ไข่เจียว', description: 'ไข่เจียวฟู', price: 40, category_name: 'อาหารตามสั่ง' },
        { name: 'ไข่ดาว', description: 'ไข่ดาวใส่น้ำมันเยอะ', price: 30, category_name: 'อาหารตามสั่ง' },
        { name: 'ไข่ต้ม', description: 'ไข่ต้มสุกกำลังดี', price: 20, category_name: 'อาหารตามสั่ง' }
      ];

      // Add menu items to database
      const itemsToInsert = sampleMenuItems
        .filter(item => categoryMap[item.category_name])
        .map(item => ({
          name: item.name,
          description: item.description,
          price: item.price,
          category_id: categoryMap[item.category_name],
          preparation_time: 15,
          is_available: true
        }));

      if (itemsToInsert.length === 0) {
        throw new Error('ไม่พบหมวดหมู่ที่ตรงกัน');
      }

      const { error } = await supabase
        .from('menu_items')
        .insert(itemsToInsert);

      if (error) throw error;
      
      return itemsToInsert.length;
    },
    onSuccess: (count) => {
      queryClient.invalidateQueries({ queryKey: ['menu-items'] });
      toast({
        title: "เพิ่มเมนูสำเร็จ",
        description: `เพิ่มเมนูแล้ว ${count} รายการ`
      });
    },
    onError: (error) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItem.name || !newItem.category_id) return;
    
    addMenuItem.mutate(newItem);
  };

  const handleEdit = (item: any) => {
    setEditingItem({ ...item });
  };

  const handleUpdate = () => {
    if (!editingItem) return;
    updateMenuItem.mutate(editingItem);
  };

  return (
    <div className="space-y-6">
      {/* Add New Menu Item */}
      <Card>
        <CardHeader>
          <CardTitle>เพิ่มเมนูใหม่</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>ชื่อเมนู</Label>
              <Input
                value={newItem.name}
                onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
                placeholder="ชื่อเมนู"
                required
              />
            </div>
            <div>
              <Label>หมวดหมู่</Label>
              <Select value={newItem.category_id} onValueChange={(value) => setNewItem({ ...newItem, category_id: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="เลือกหมวดหมู่" />
                </SelectTrigger>
                <SelectContent>
                  {categories?.map((category) => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>ราคา (บาท)</Label>
              <Input
                type="number"
                value={newItem.price}
                onChange={(e) => setNewItem({ ...newItem, price: parseFloat(e.target.value) || 0 })}
                placeholder="ราคา"
                min="0"
                step="0.01"
              />
            </div>
            <div>
              <Label>เวลาเตรียม (นาที)</Label>
              <Input
                type="number"
                value={newItem.preparation_time}
                onChange={(e) => setNewItem({ ...newItem, preparation_time: parseInt(e.target.value) || 15 })}
                placeholder="15"
                min="1"
              />
            </div>
            <div className="md:col-span-2">
              <Label>คำอธิบาย</Label>
              <Textarea
                value={newItem.description}
                onChange={(e) => setNewItem({ ...newItem, description: e.target.value })}
                placeholder="คำอธิบายเมนู"
                rows={2}
              />
            </div>
            <div className="md:col-span-2 flex gap-2">
              <Button type="submit" disabled={addMenuItem.isPending}>
                <Plus className="h-4 w-4 mr-2" />
                {addMenuItem.isPending ? 'กำลังเพิ่ม...' : 'เพิ่มเมนู'}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => addSampleMenuItems.mutate()}
                disabled={addSampleMenuItems.isPending}
              >
                {addSampleMenuItems.isPending ? 'กำลังเพิ่มเมนูทั้งหมด...' : 'เพิ่มเมนูทั้งหมด'}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => refetchMenuItems()}
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                รีเฟรช
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Menu Items List */}
      <Card>
        <CardHeader>
          <CardTitle>รายการเมนูทั้งหมด ({menuItems?.length || 0} รายการ)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {menuItems?.map((item) => (
              <Card key={item.id} className="p-4">
                <div className="space-y-2">
                  <div className="flex justify-between items-start">
                    <h3 className="font-semibold text-lg">{item.name}</h3>
                    <Badge variant={item.is_available ? "default" : "secondary"}>
                      {item.is_available ? "พร้อมขาย" : "ไม่พร้อมขาย"}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600">{item.description}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-lg font-bold text-green-600">฿{item.price}</span>
                    <span className="text-sm text-gray-500">{item.preparation_time} นาที</span>
                  </div>
                  <div className="text-sm text-blue-600">
                    {item.menu_categories?.name}
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleEdit(item)}
                    >
                      <Edit className="h-3 w-3" />
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => deleteMenuItem.mutate(item.id)}
                      disabled={deleteMenuItem.isPending}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Edit Modal */}
      {editingItem && (
        <Card className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <CardContent className="bg-white p-6 rounded-lg max-w-md w-full mx-4 space-y-4">
            <h3 className="text-lg font-semibold">แก้ไขเมนู</h3>
            <div>
              <Label>ชื่อเมนู</Label>
              <Input
                value={editingItem.name}
                onChange={(e) => setEditingItem({ ...editingItem, name: e.target.value })}
              />
            </div>
            <div>
              <Label>ราคา</Label>
              <Input
                type="number"
                value={editingItem.price}
                onChange={(e) => setEditingItem({ ...editingItem, price: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div>
              <Label>คำอธิบาย</Label>
              <Textarea
                value={editingItem.description}
                onChange={(e) => setEditingItem({ ...editingItem, description: e.target.value })}
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleUpdate} disabled={updateMenuItem.isPending}>
                {updateMenuItem.isPending ? 'กำลังบันทึก...' : 'บันทึก'}
              </Button>
              <Button variant="outline" onClick={() => setEditingItem(null)}>
                ยกเลิก
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default MenuManagement;
