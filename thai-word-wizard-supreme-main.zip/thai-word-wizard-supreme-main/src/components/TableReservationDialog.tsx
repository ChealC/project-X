
import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { supabase } from '@/integrations/supabase/client';
import { Tables } from '@/integrations/supabase/types';
import { useToast } from '@/hooks/use-toast';

interface TableReservationDialogProps {
  table: Tables<'tables'>;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const TableReservationDialog = ({ table, open, onOpenChange }: TableReservationDialogProps) => {
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [reservationDate, setReservationDate] = useState('');
  const [reservationTime, setReservationTime] = useState('');
  const [partySize, setPartySize] = useState(1);
  const [notes, setNotes] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createReservation = useMutation({
    mutationFn: async () => {
      const { data, error } = await supabase
        .from('table_reservations')
        .insert({
          table_id: table.id,
          customer_name: customerName,
          customer_phone: customerPhone,
          reservation_date: reservationDate,
          reservation_time: reservationTime,
          party_size: partySize,
          notes: notes
        })
        .select()
        .single();

      if (error) throw error;

      // Update table status to reserved
      const { error: tableError } = await supabase
        .from('tables')
        .update({ status: 'reserved' })
        .eq('id', table.id);

      if (tableError) throw tableError;

      return data;
    },
    onSuccess: () => {
      setCustomerName('');
      setCustomerPhone('');
      setReservationDate('');
      setReservationTime('');
      setPartySize(1);
      setNotes('');
      onOpenChange(false);
      queryClient.invalidateQueries({ queryKey: ['tables'] });
      toast({
        title: "จองโต๊ะสำเร็จ",
        description: `จองโต๊ะ ${table.table_number} สำหรับ ${customerName} แล้ว`
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerPhone || !reservationDate || !reservationTime) {
      toast({
        title: "ข้อมูลไม่ครบถ้วน",
        description: "กรุณากรอกข้อมูลให้ครบถ้วน",
        variant: "destructive"
      });
      return;
    }
    createReservation.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>จองโต๊ะ {table.table_number}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="customerName">ชื่อลูกค้า</Label>
            <Input
              id="customerName"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              placeholder="ชื่อลูกค้า"
              required
            />
          </div>

          <div>
            <Label htmlFor="customerPhone">เบอร์โทรศัพท์</Label>
            <Input
              id="customerPhone"
              value={customerPhone}
              onChange={(e) => setCustomerPhone(e.target.value)}
              placeholder="เบอร์โทรศัพท์"
              required
            />
          </div>

          <div>
            <Label htmlFor="reservationDate">วันที่จอง</Label>
            <Input
              id="reservationDate"
              type="date"
              value={reservationDate}
              onChange={(e) => setReservationDate(e.target.value)}
              required
            />
          </div>

          <div>
            <Label htmlFor="reservationTime">เวลาจอง</Label>
            <Input
              id="reservationTime"
              type="time"
              value={reservationTime}
              onChange={(e) => setReservationTime(e.target.value)}
              required
            />
          </div>

          <div>
            <Label htmlFor="partySize">จำนวนคน</Label>
            <Input
              id="partySize"
              type="number"
              value={partySize}
              onChange={(e) => setPartySize(parseInt(e.target.value) || 1)}
              min={1}
              max={table.seats}
              required
            />
          </div>

          <div>
            <Label htmlFor="notes">หมายเหตุ</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="หมายเหตุเพิ่มเติม..."
              rows={3}
            />
          </div>

          <div className="flex gap-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="flex-1">
              ยกเลิก
            </Button>
            <Button type="submit" disabled={createReservation.isPending} className="flex-1">
              {createReservation.isPending ? 'กำลังจอง...' : 'จองโต๊ะ'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default TableReservationDialog;
