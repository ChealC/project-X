
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useEpsonPrinter } from '@/hooks/useEpsonPrinter';
import { 
  Printer, 
  Wifi, 
  WifiOff, 
  RotateCcw, 
  Settings,
  CheckCircle,
  AlertCircle
} from 'lucide-react';

interface EpsonPrintSystemProps {
  order?: any;
  onClose?: () => void;
}

const EpsonPrintSystem = ({ order, onClose }: EpsonPrintSystemProps) => {
  const {
    status,
    isConnecting,
    isPrinting,
    connectToPrinter,
    printReceipt,
    disconnectPrinter
  } = useEpsonPrinter();

  const [testPrintContent] = useState(`
    <div class="receipt">
      <div class="header">
        <div class="shop-name">ร้านอาหารของเรา</div>
        <div>123 ถนนสุขุมวิท กรุงเทพฯ 10110</div>
        <div>โทร: 02-123-4567</div>
      </div>
      <div class="separator"></div>
      <div class="content">
        <div><strong>ทดสอบระบบปริ้นต์</strong></div>
        <div>Epson TMT82 Network Printer</div>
        <div>IP: 192.168.1.127</div>
        <div>วันที่: ${new Date().toLocaleString('th-TH')}</div>
      </div>
      <div class="separator"></div>
      <div class="footer">
        <div>ระบบปริ้นต์ทำงานปกติ ✓</div>
      </div>
    </div>
  `);

  const handleTestPrint = () => {
    printReceipt(testPrintContent, 'TEST-001');
  };

  const handlePrintOrder = () => {
    if (order) {
      const receiptContent = document.getElementById('receipt-content');
      if (receiptContent) {
        printReceipt(receiptContent.innerHTML, order.order_number);
      }
    }
  };

  return (
    <div className="space-y-4">
      {/* Printer Status Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Printer className="h-5 w-5" />
            ระบบปริ้นต์ Epson TMT82
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Connection Status */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {status.connected ? (
                <Wifi className="h-4 w-4 text-green-600" />
              ) : (
                <WifiOff className="h-4 w-4 text-red-600" />
              )}
              <span className="font-medium">สถานะการเชื่อมต่อ:</span>
            </div>
            <Badge variant={status.connected ? "default" : "destructive"}>
              {status.connected ? "เชื่อมต่อแล้ว" : "ไม่ได้เชื่อมต่อ"}
            </Badge>
          </div>

          {/* Printer Details */}
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span>IP Address:</span>
              <span className="font-mono">{status.ip}</span>
            </div>
            <div className="flex justify-between">
              <span>Port:</span>
              <span className="font-mono">{status.port}</span>
            </div>
            {status.lastConnectionAttempt && (
              <div className="flex justify-between">
                <span>การเชื่อมต่อล่าสุด:</span>
                <span className="text-xs">
                  {status.lastConnectionAttempt.toLocaleTimeString('th-TH')}
                </span>
              </div>
            )}
          </div>

          <Separator />

          {/* Control Buttons */}
          <div className="grid grid-cols-2 gap-2">
            <Button
              variant={status.connected ? "outline" : "default"}
              onClick={connectToPrinter}
              disabled={isConnecting}
              className="flex items-center gap-2"
            >
              <RotateCcw className={`h-4 w-4 ${isConnecting ? 'animate-spin' : ''}`} />
              {isConnecting ? 'กำลังเชื่อมต่อ...' : 'เชื่อมต่อ'}
            </Button>
            
            <Button
              variant="outline"
              onClick={disconnectPrinter}
              disabled={!status.connected || isConnecting}
              className="flex items-center gap-2"
            >
              <WifiOff className="h-4 w-4" />
              ตัดการเชื่อมต่อ
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Print Actions Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            การควบคุมการปริ้นต์
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {/* Test Print */}
          <Button
            onClick={handleTestPrint}
            disabled={!status.connected || isPrinting}
            className="w-full flex items-center gap-2"
            variant="outline"
          >
            <CheckCircle className="h-4 w-4" />
            {isPrinting ? 'กำลังปริ้นต์...' : 'ทดสอบการปริ้นต์'}
          </Button>

          {/* Print Order Receipt */}
          {order && (
            <Button
              onClick={handlePrintOrder}
              disabled={!status.connected || isPrinting}
              className="w-full flex items-center gap-2"
            >
              <Printer className="h-4 w-4" />
              {isPrinting ? 'กำลังปริ้นต์...' : `ปริ้นต์ใบเสร็จ ${order.order_number}`}
            </Button>
          )}

          {/* Status Messages */}
          {!status.connected && (
            <div className="flex items-center gap-2 p-3 bg-orange-50 rounded-lg border border-orange-200">
              <AlertCircle className="h-4 w-4 text-orange-600" />
              <span className="text-sm text-orange-700">
                กรุณาตรวจสอบการเชื่อมต่อเครื่องปริ้นต์ Epson TMT82
              </span>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Instructions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm">🔧 วิธีใช้งาน</CardTitle>
        </CardHeader>
        <CardContent className="text-xs space-y-1">
          <div>• ตรวจสอบว่าเครื่องปริ้นต์ Epson TMT82 เปิดอยู่</div>
          <div>• ตรวจสอบการเชื่อมต่อเครือข่าย IP: 192.168.1.127</div>
          <div>• คลิก "เชื่อมต่อ" เพื่อเชื่อมต่อกับเครื่องปริ้นต์</div>
          <div>• ใช้ "ทดสอบการปริ้นต์" เพื่อตรวจสอบการทำงาน</div>
          <div>• ปริ้นต์ใบเสร็จโดยใช้ปุ่ม "ปริ้นต์ใบเสร็จ"</div>
        </CardContent>
      </Card>

      {onClose && (
        <Button variant="outline" onClick={onClose} className="w-full">
          ปิด
        </Button>
      )}
    </div>
  );
};

export default EpsonPrintSystem;
