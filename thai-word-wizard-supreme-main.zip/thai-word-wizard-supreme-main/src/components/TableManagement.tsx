
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { Tables } from '@/integrations/supabase/types';
import ImprovedTableCard from './ImprovedTableCard';
import TableOrderDialog from './TableOrderDialog';
import TableReservationDialog from './TableReservationDialog';
import AddOrderDialog from './AddOrderDialog';
import TableDetailsDialog from './TableDetailsDialog';
import PaymentSystemWrapper from './PaymentSystemWrapper';
import { useToast } from '@/hooks/use-toast';

const TableManagement = () => {
  const [selectedTable, setSelectedTable] = useState<Tables<'tables'> | null>(null);
  const [reservationTable, setReservationTable] = useState<Tables<'tables'> | null>(null);
  const [addOrderTable, setAddOrderTable] = useState<Tables<'tables'> | null>(null);
  const [detailsTable, setDetailsTable] = useState<Tables<'tables'> | null>(null);
  const [paymentTable, setPaymentTable] = useState<Tables<'tables'> | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: tables, isLoading } = useQuery({
    queryKey: ['tables'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('tables')
        .select('*')
        .order('table_number');
      
      if (error) throw error;
      return data as Tables<'tables'>[];
    }
  });

  const updateTableStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await supabase
        .from('tables')
        .update({ status, updated_at: new Date().toISOString() })
        .eq('id', id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tables'] });
      toast({
        title: "อัปเดตสถานะโต๊ะสำเร็จ",
        description: "สถานะโต๊ะได้รับการอัปเดตแล้ว"
      });
    }
  });

  const handleOpenTable = (table: Tables<'tables'>) => {
    setSelectedTable(table);
  };

  const handleReserveTable = (table: Tables<'tables'>) => {
    setReservationTable(table);
  };

  const handleAddToOrder = (table: Tables<'tables'>) => {
    setAddOrderTable(table);
  };

  const handleViewTableDetails = (table: Tables<'tables'>) => {
    setDetailsTable(table);
  };

  const handlePayment = (table: Tables<'tables'>) => {
    setPaymentTable(table);
  };

  const handleUpdateStatus = (id: string, status: string) => {
    updateTableStatus.mutate({ id, status });
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center">กำลังโหลดข้อมูลโต๊ะ...</div>
        </CardContent>
      </Card>
    );
  }

  const occupiedTables = tables?.filter(table => table.status === 'occupied') || [];
  const availableTables = tables?.filter(table => table.status === 'available') || [];
  const reservedTables = tables?.filter(table => table.status === 'reserved') || [];
  const cleaningTables = tables?.filter(table => table.status === 'cleaning') || [];

  return (
    <div className="space-y-6">
      {/* Occupied Tables - Moved to top */}
      {occupiedTables.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-red-600">โต๊ะมีลูกค้า ({occupiedTables.length} โต๊ะ)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {occupiedTables.map((table) => (
                <ImprovedTableCard
                  key={table.id}
                  table={table}
                  onOpenTable={handleOpenTable}
                  onReserveTable={handleReserveTable}
                  onUpdateStatus={handleUpdateStatus}
                  onAddToOrder={handleAddToOrder}
                  onViewTableDetails={handleViewTableDetails}
                  onPayment={handlePayment}
                  isUpdating={updateTableStatus.isPending}
                />
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Available Tables */}
      {availableTables.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-green-600">โต๊ะว่าง ({availableTables.length} โต๊ะ)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {availableTables.map((table) => (
                <ImprovedTableCard
                  key={table.id}
                  table={table}
                  onOpenTable={handleOpenTable}
                  onReserveTable={handleReserveTable}
                  onUpdateStatus={handleUpdateStatus}
                  onViewTableDetails={handleViewTableDetails}
                  isUpdating={updateTableStatus.isPending}
                />
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Reserved Tables */}
      {reservedTables.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-yellow-600">โต๊ะจอง ({reservedTables.length} โต๊ะ)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {reservedTables.map((table) => (
                <ImprovedTableCard
                  key={table.id}
                  table={table}
                  onOpenTable={handleOpenTable}
                  onReserveTable={handleReserveTable}
                  onUpdateStatus={handleUpdateStatus}
                  onViewTableDetails={handleViewTableDetails}
                  isUpdating={updateTableStatus.isPending}
                />
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Cleaning Tables */}
      {cleaningTables.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-blue-600">โต๊ะทำความสะอาด ({cleaningTables.length} โต๊ะ)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {cleaningTables.map((table) => (
                <ImprovedTableCard
                  key={table.id}
                  table={table}
                  onOpenTable={handleOpenTable}
                  onReserveTable={handleReserveTable}
                  onUpdateStatus={handleUpdateStatus}
                  onViewTableDetails={handleViewTableDetails}
                  isUpdating={updateTableStatus.isPending}
                />
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Dialogs */}
      {selectedTable && (
        <TableOrderDialog
          table={selectedTable}
          open={!!selectedTable}
          onOpenChange={() => setSelectedTable(null)}
        />
      )}

      {reservationTable && (
        <TableReservationDialog
          table={reservationTable}
          open={!!reservationTable}
          onOpenChange={() => setReservationTable(null)}
        />
      )}

      {addOrderTable && (
        <AddOrderDialog
          table={addOrderTable}
          open={!!addOrderTable}
          onOpenChange={() => setAddOrderTable(null)}
        />
      )}

      {detailsTable && (
        <TableDetailsDialog
          table={detailsTable}
          open={!!detailsTable}
          onOpenChange={() => setDetailsTable(null)}
        />
      )}

      {paymentTable && (
        <PaymentSystemWrapper 
          selectedTable={paymentTable}
          open={!!paymentTable}
          onOpenChange={() => setPaymentTable(null)}
        />
      )}
    </div>
  );
};

export default TableManagement;
