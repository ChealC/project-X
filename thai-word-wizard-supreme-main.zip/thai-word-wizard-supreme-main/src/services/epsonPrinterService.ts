
interface EpsonPrintJob {
  content: string;
  copies?: number;
  cutPaper?: boolean;
}

interface EpsonPrinterConfig {
  ip: string;
  port: number;
  timeout: number;
}

class EpsonPrinterService {
  private config: EpsonPrinterConfig;
  private isConnected: boolean = false;

  constructor(config: EpsonPrinterConfig) {
    this.config = config;
  }

  async connect(): Promise<boolean> {
    try {
      console.log(`Attempting to connect to Epson TMT82 at ${this.config.ip}:${this.config.port}`);
      
      // Test connection using fetch with timeout
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), this.config.timeout);
      
      try {
        // Try to ping the printer's web interface or status endpoint
        const response = await fetch(`http://${this.config.ip}:${this.config.port}/status`, {
          method: 'GET',
          signal: controller.signal,
          mode: 'no-cors' // Handle CORS for direct IP access
        });
        
        clearTimeout(timeoutId);
        this.isConnected = true;
        console.log('Successfully connected to Epson TMT82');
        return true;
      } catch (fetchError) {
        clearTimeout(timeoutId);
        console.log('Direct HTTP connection failed, trying alternative connection method...');
        
        // Alternative: Use WebSocket if available
        return this.tryWebSocketConnection();
      }
    } catch (error) {
      console.error('Failed to connect to Epson TMT82:', error);
      this.isConnected = false;
      return false;
    }
  }

  private async tryWebSocketConnection(): Promise<boolean> {
    return new Promise((resolve) => {
      try {
        const ws = new WebSocket(`ws://${this.config.ip}:${this.config.port}`);
        
        ws.onopen = () => {
          console.log('WebSocket connection to Epson TMT82 established');
          this.isConnected = true;
          ws.close();
          resolve(true);
        };
        
        ws.onerror = () => {
          console.log('WebSocket connection failed');
          this.isConnected = false;
          resolve(false);
        };
        
        ws.onclose = () => {
          console.log('WebSocket connection closed');
        };
        
        // Timeout for WebSocket connection
        setTimeout(() => {
          if (ws.readyState === WebSocket.CONNECTING) {
            ws.close();
            resolve(false);
          }
        }, 3000);
      } catch (error) {
        console.error('WebSocket connection error:', error);
        resolve(false);
      }
    });
  }

  async printReceipt(job: EpsonPrintJob): Promise<boolean> {
    if (!this.isConnected) {
      const connected = await this.connect();
      if (!connected) {
        throw new Error('Cannot connect to Epson TMT82 printer');
      }
    }

    try {
      console.log('Sending print job to Epson TMT82...');
      
      // Convert content to ESC/POS commands for Epson TMT82
      const escPosCommands = this.convertToEscPos(job.content);
      
      // Try multiple methods to send print data
      const printSuccess = await this.sendPrintData(escPosCommands, job);
      
      if (printSuccess) {
        console.log('Print job sent successfully to Epson TMT82');
        return true;
      } else {
        throw new Error('Failed to send print data to printer');
      }
    } catch (error) {
      console.error('Print job failed:', error);
      throw error;
    }
  }

  private convertToEscPos(htmlContent: string): Uint8Array {
    // ESC/POS command constants for Epson TMT82
    const ESC = 0x1B;
    const GS = 0x1D;
    const LF = 0x0A;
    const CR = 0x0D;
    
    // Initialize printer
    const commands: number[] = [ESC, 0x40]; // ESC @ (Initialize)
    
    // Set character encoding to UTF-8
    commands.push(ESC, 0x74, 0x20); // ESC t (Select character code table)
    
    // Parse HTML content and convert to ESC/POS
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlContent, 'text/html');
    
    // Extract text content and apply formatting
    this.processNode(doc.body, commands);
    
    // Cut paper if specified
    commands.push(GS, 0x56, 0x00); // GS V (Cut paper)
    
    return new Uint8Array(commands);
  }

  private processNode(node: Node, commands: number[]): void {
    if (node.nodeType === Node.TEXT_NODE) {
      const text = node.textContent?.trim();
      if (text) {
        // Convert text to bytes (UTF-8)
        const encoder = new TextEncoder();
        const textBytes = encoder.encode(text);
        commands.push(...Array.from(textBytes));
      }
    } else if (node.nodeType === Node.ELEMENT_NODE) {
      const element = node as Element;
      
      // Handle different HTML elements
      switch (element.tagName.toLowerCase()) {
        case 'div':
        case 'p':
          // Add line break before and after
          commands.push(0x0A);
          break;
        case 'strong':
        case 'b':
          // Bold on
          commands.push(0x1B, 0x45, 0x01);
          break;
        case 'br':
          commands.push(0x0A);
          return;
      }
      
      // Process child nodes
      for (let i = 0; i < node.childNodes.length; i++) {
        this.processNode(node.childNodes[i], commands);
      }
      
      // Handle closing tags
      switch (element.tagName.toLowerCase()) {
        case 'div':
        case 'p':
          commands.push(0x0A);
          break;
        case 'strong':
        case 'b':
          // Bold off
          commands.push(0x1B, 0x45, 0x00);
          break;
      }
    }
  }

  private async sendPrintData(data: Uint8Array, job: EpsonPrintJob): Promise<boolean> {
    try {
      // Method 1: Try using fetch with POST request
      const response = await fetch(`http://${this.config.ip}:${this.config.port}/print`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/octet-stream',
          'Content-Length': data.length.toString()
        },
        body: data,
        mode: 'no-cors'
      });
      
      console.log('Print data sent via HTTP POST');
      return true;
    } catch (httpError) {
      console.log('HTTP POST failed, trying raw TCP simulation...');
      
      // Method 2: Use browser printing as fallback
      return this.fallbackBrowserPrint(job.content);
    }
  }

  private async fallbackBrowserPrint(content: string): Promise<boolean> {
    try {
      console.log('Using browser print as fallback for Epson TMT82');
      
      const printWindow = window.open('', '_blank', 'width=302,height=600');
      if (!printWindow) {
        throw new Error('Could not open print window');
      }

      const printHTML = `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <title>Epson TMT82 Print</title>
          <style>
            @page {
              size: 80mm auto;
              margin: 0;
            }
            body {
              font-family: 'Courier New', monospace;
              font-size: 12px;
              line-height: 1.2;
              width: 80mm;
              margin: 0;
              padding: 4px;
              background: white;
            }
            .receipt {
              width: 100%;
            }
            @media print {
              body {
                margin: 0 !important;
                padding: 2px !important;
                width: 80mm !important;
              }
            }
          </style>
        </head>
        <body onload="window.print(); window.close();">
          ${content}
        </body>
        </html>
      `;

      printWindow.document.write(printHTML);
      printWindow.document.close();
      
      return true;
    } catch (error) {
      console.error('Fallback browser print failed:', error);
      return false;
    }
  }

  getStatus(): { connected: boolean; ip: string; port: number } {
    return {
      connected: this.isConnected,
      ip: this.config.ip,
      port: this.config.port
    };
  }

  disconnect(): void {
    this.isConnected = false;
    console.log('Disconnected from Epson TMT82');
  }
}

// Create singleton instance for Epson TMT82
export const epsonPrinter = new EpsonPrinterService({
  ip: '192.168.1.127',
  port: 9100, // Standard ESC/POS port
  timeout: 5000
});

export default EpsonPrinterService;
