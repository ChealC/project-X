
import { useState, useEffect, useCallback } from 'react';
import { epsonPrinter } from '@/services/epsonPrinterService';
import { useToast } from '@/hooks/use-toast';

interface PrinterStatus {
  connected: boolean;
  ip: string;
  port: number;
  lastConnectionAttempt?: Date;
}

export const useEpsonPrinter = () => {
  const [status, setStatus] = useState<PrinterStatus>({
    connected: false,
    ip: '192.168.1.127',
    port: 9100
  });
  const [isConnecting, setIsConnecting] = useState(false);
  const [isPrinting, setIsPrinting] = useState(false);
  const { toast } = useToast();

  const updateStatus = useCallback(() => {
    const printerStatus = epsonPrinter.getStatus();
    setStatus(prev => ({
      ...prev,
      connected: printerStatus.connected,
      ip: printerStatus.ip,
      port: printerStatus.port
    }));
  }, []);

  const connectToPrinter = useCallback(async () => {
    if (isConnecting) return;
    
    setIsConnecting(true);
    try {
      console.log('Attempting to connect to Epson TMT82...');
      const connected = await epsonPrinter.connect();
      
      setStatus(prev => ({
        ...prev,
        connected,
        lastConnectionAttempt: new Date()
      }));

      if (connected) {
        toast({
          title: "🖨️ เชื่อมต่อสำเร็จ",
          description: "เชื่อมต่อกับเครื่องปริ้นต์ Epson TMT82 แล้ว",
        });
      } else {
        toast({
          title: "⚠️ ไม่สามารถเชื่อมต่อได้",
          description: "กรุณาตรวจสอบ IP และการเชื่อมต่อเครื่องปริ้นต์",
          variant: "destructive"
        });
      }
    } catch (error: any) {
      console.error('Connection failed:', error);
      setStatus(prev => ({
        ...prev,
        connected: false,
        lastConnectionAttempt: new Date()
      }));
      
      toast({
        title: "❌ เกิดข้อผิดพลาด",
        description: error.message || "ไม่สามารถเชื่อมต่อเครื่องปริ้นต์ได้",
        variant: "destructive"
      });
    } finally {
      setIsConnecting(false);
    }
  }, [isConnecting, toast]);

  const printReceipt = useCallback(async (content: string, orderNumber?: string) => {
    if (isPrinting) return false;
    
    setIsPrinting(true);
    try {
      console.log('Starting print job for Epson TMT82...');
      
      await epsonPrinter.printReceipt({
        content,
        copies: 1,
        cutPaper: true
      });

      toast({
        title: "🖨️ ปริ้นต์สำเร็จ",
        description: orderNumber 
          ? `ปริ้นต์ใบเสร็จ ${orderNumber} สำเร็จ`
          : "ปริ้นต์เอกสารสำเร็จ"
      });

      return true;
    } catch (error: any) {
      console.error('Print failed:', error);
      
      toast({
        title: "🖨️ ปริ้นต์ไม่สำเร็จ",
        description: error.message || "เกิดข้อผิดพลาดในการปริ้นต์",
        variant: "destructive"
      });

      return false;
    } finally {
      setIsPrinting(false);
    }
  }, [isPrinting, toast]);

  const disconnectPrinter = useCallback(() => {
    epsonPrinter.disconnect();
    updateStatus();
    
    toast({
      title: "🔌 ตัดการเชื่อมต่อ",
      description: "ตัดการเชื่อมต่อกับเครื่องปริ้นต์แล้ว"
    });
  }, [updateStatus, toast]);

  // Auto-connect on mount
  useEffect(() => {
    connectToPrinter();
  }, []);

  // Update status periodically
  useEffect(() => {
    const interval = setInterval(updateStatus, 10000); // Check every 10 seconds
    return () => clearInterval(interval);
  }, [updateStatus]);

  return {
    status,
    isConnecting,
    isPrinting,
    connectToPrinter,
    printReceipt,
    disconnectPrinter,
    updateStatus
  };
};
