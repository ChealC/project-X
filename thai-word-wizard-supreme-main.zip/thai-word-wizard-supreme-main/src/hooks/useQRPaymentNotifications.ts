
import { useState, useEffect } from 'react';

interface PendingQRPayment {
  orderId: string;
  orderNumber: string;
  amount: number;
  slipData: string;
  status: string;
  timestamp: number;
  tableNumber?: string;
  customerName?: string;
}

export const useQRPaymentNotifications = () => {
  const [pendingCount, setPendingCount] = useState(0);
  const [pendingPayments, setPendingPayments] = useState<Record<string, PendingQRPayment>>({});

  const loadPendingPayments = () => {
    const stored = localStorage.getItem('pendingQRPayments');
    if (stored) {
      const parsed = JSON.parse(stored);
      const pending = Object.values(parsed).filter(
        (payment: any) => payment.status === 'slip_uploaded'
      );
      setPendingCount(pending.length);
      setPendingPayments(parsed);
      return parsed;
    }
    setPendingCount(0);
    setPendingPayments({});
    return {};
  };

  useEffect(() => {
    // Load initially
    loadPendingPayments();

    // Check every 3 seconds for updates
    const interval = setInterval(() => {
      loadPendingPayments();
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return {
    pendingCount,
    pendingPayments,
    refreshNotifications: loadPendingPayments
  };
};
