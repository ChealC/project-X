
import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { useEpsonPrinter } from '@/hooks/useEpsonPrinter';

export const usePrinter = () => {
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const { status: epsonStatus, printReceipt: epsonPrint } = useEpsonPrinter();

  const printReceipt = async (receiptContent: string, orderNumber: string) => {
    setIsLoading(true);
    try {
      // Try Epson printer first if connected
      if (epsonStatus.connected) {
        console.log('Using Epson TMT82 for printing...');
        const success = await epsonPrint(receiptContent, orderNumber);
        if (success) {
          return true;
        }
        console.log('Epson print failed, falling back to browser print...');
      }

      // Fallback to browser printing
      console.log('Using browser print as fallback...');
      if (!window.print) {
        throw new Error('เบราว์เซอร์ไม่รองรับการปริ้นต์');
      }

      const printWindow = window.open('', '_blank', 'width=302,height=600');
      if (!printWindow) {
        throw new Error('ไม่สามารถเปิดหน้าต่างปริ้นต์ได้ กรุณาอนุญาต popup');
      }

      const printHTML = `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <title>ใบเสร็จ - ${orderNumber}</title>
          <style>
            @page { size: 80mm auto; margin: 0; }
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { font-family: 'Courier New', monospace; font-size: 11px; line-height: 1.3; width: 80mm; margin: 0; padding: 6px; background: white; color: black; }
            .receipt { width: 100%; }
            .header { text-align: center; margin-bottom: 6px; border-bottom: 1px dashed #000; padding-bottom: 6px; }
            .shop-name { font-size: 14px; font-weight: bold; margin-bottom: 2px; }
            .order-info { margin: 6px 0; font-size: 10px; }
            .items { margin: 6px 0; }
            .item { display: flex; justify-content: space-between; margin: 1px 0; font-size: 10px; }
            .item-name { flex: 1; padding-right: 6px; }
            .item-qty { min-width: 18px; text-align: center; }
            .item-price { min-width: 35px; text-align: right; }
            .separator { border-top: 1px dashed #000; margin: 6px 0; }
            .total { display: flex; justify-content: space-between; font-weight: bold; font-size: 12px; margin: 3px 0; }
            .footer { text-align: center; margin-top: 6px; padding-top: 6px; border-top: 1px dashed #000; font-size: 9px; }
            @media print { body { margin: 0 !important; padding: 4px !important; width: 80mm !important; } .no-print { display: none !important; } * { -webkit-print-color-adjust: exact !important; color-adjust: exact !important; } }
          </style>
        </head>
        <body onload="window.print(); window.close();">
          ${receiptContent}
        </body>
        </html>
      `;

      printWindow.document.write(printHTML);
      printWindow.document.close();

      toast({
        title: "เปิดหน้าต่างปริ้นต์สำเร็จ",
        description: epsonStatus.connected 
          ? "ระบบใช้การปริ้นต์สำรองหลังจาก Epson TMT82 ไม่พร้อมใช้งาน"
          : "กรุณาเชื่อมต่อ Epson TMT82 สำหรับการปริ้นต์อัตโนมัติ"
      });

      return true;
    } catch (error: any) {
      toast({
        title: "เกิดข้อผิดพลาดในการปริ้นต์",
        description: error.message,
        variant: "destructive"
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const checkPrinterConnection = async () => {
    try {
      // Check Epson printer connection first
      if (epsonStatus.connected) {
        return { 
          available: true, 
          type: 'epson',
          details: `Epson TMT82 (${epsonStatus.ip}:${epsonStatus.port})`
        };
      }

      // Check browser print capability
      if ('navigator' in window && 'permissions' in navigator) {
        return { 
          available: true, 
          type: 'browser',
          details: 'Browser printing available'
        };
      }
      
      return { 
        available: window.print !== undefined, 
        type: 'basic',
        details: 'Basic print function available'
      };
    } catch (error) {
      return { 
        available: false, 
        type: 'none',
        details: 'No printing method available'
      };
    }
  };

  return {
    printReceipt,
    checkPrinterConnection,
    isLoading,
    epsonStatus
  };
};
