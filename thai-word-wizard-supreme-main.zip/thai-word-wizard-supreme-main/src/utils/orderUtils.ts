
export const generateOrderNumber = (tableNumber?: string, orderType?: string): string => {
  const now = new Date();
  const timestamp = now.getTime();
  const random = Math.floor(Math.random() * 999999999).toString().padStart(9, '0');
  const microseconds = (performance.now() % 1000).toString().split('.')[1]?.padStart(3, '0') || '000';
  const nanoTime = performance.now().toString().replace('.', '');
  
  // Create ultra-unique identifier
  const uniquePart = `${timestamp}${microseconds}${random}${nanoTime.slice(-6)}`;
  
  if (orderType === 'dine-in' && tableNumber) {
    return `TBL${tableNumber}-${uniquePart}`;
  } else if (orderType === 'takeaway') {
    return `TAK-${uniquePart}`;
  } else if (orderType === 'delivery') {
    return `DEL-${uniquePart}`;
  } else {
    return `ORD-${uniquePart}`;
  }
};

export const formatOrderTime = (createdAt: string): string => {
  const date = new Date(createdAt);
  const now = new Date();
  const diffMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
  
  if (diffMinutes < 1) {
    return 'เพิ่งสั่ง';
  } else if (diffMinutes < 60) {
    return `${diffMinutes} นาทีที่แล้ว`;
  } else {
    const hours = Math.floor(diffMinutes / 60);
    return `${hours} ชั่วโมงที่แล้ว`;
  }
};

// Global submission tracker to prevent duplicates across all components
const globalSubmissionTracker = {
  lastSubmissionTime: 0,
  lastOrderNumber: '',
  isSubmitting: false,
  submissionCount: 0
};

export const checkOrderNumberExists = async (orderNumber: string): Promise<boolean> => {
  const { supabase } = await import('@/integrations/supabase/client');
  const { data } = await supabase
    .from('orders')
    .select('id')
    .eq('order_number', orderNumber)
    .maybeSingle();
  
  return !!data;
};

export const generateUniqueOrderNumber = async (tableNumber?: string, orderType?: string): Promise<string> => {
  let attempts = 0;
  const maxAttempts = 100;
  
  while (attempts < maxAttempts) {
    if (attempts > 0) {
      await new Promise(resolve => setTimeout(resolve, 200 + (attempts * 100)));
    }
    
    const baseOrderNumber = generateOrderNumber(tableNumber, orderType);
    const orderNumber = attempts > 0 ? `${baseOrderNumber}-R${attempts}` : baseOrderNumber;
    
    console.log(`Checking order number uniqueness (attempt ${attempts + 1}):`, orderNumber);
    
    const exists = await checkOrderNumberExists(orderNumber);
    
    if (!exists) {
      console.log('Unique order number generated:', orderNumber);
      return orderNumber;
    }
    
    console.log('Order number collision detected, retrying...');
    attempts++;
  }
  
  // Ultimate fallback
  const timestamp = Date.now();
  const processId = Math.floor(Math.random() * 999999).toString().padStart(6, '0');
  const uuid = `${timestamp}-${processId}-${Math.random().toString(36).substr(2, 15)}`;
  const fallbackNumber = orderType === 'dine-in' && tableNumber 
    ? `TBL${tableNumber}-EMERGENCY-${uuid}`
    : `ORD-EMERGENCY-${uuid}`;
    
  console.log('Using emergency fallback order number:', fallbackNumber);
  return fallbackNumber;
};

export const canSubmitOrder = (): boolean => {
  const now = Date.now();
  
  // Prevent submission if already submitting
  if (globalSubmissionTracker.isSubmitting) {
    console.log('Submission blocked: already submitting');
    return false;
  }
  
  // Prevent rapid successive submissions
  if (now - globalSubmissionTracker.lastSubmissionTime < 10000) { // 10 seconds minimum
    console.log('Submission blocked: too soon after last submission');
    return false;
  }
  
  return true;
};

export const markSubmissionStart = () => {
  globalSubmissionTracker.isSubmitting = true;
  globalSubmissionTracker.lastSubmissionTime = Date.now();
  globalSubmissionTracker.submissionCount++;
  console.log('Submission started, count:', globalSubmissionTracker.submissionCount);
};

export const markSubmissionEnd = () => {
  globalSubmissionTracker.isSubmitting = false;
  console.log('Submission ended');
};

export const resetSubmissionTracker = () => {
  globalSubmissionTracker.lastSubmissionTime = 0;
  globalSubmissionTracker.lastOrderNumber = '';
  globalSubmissionTracker.isSubmitting = false;
  globalSubmissionTracker.submissionCount = 0;
  console.log('Submission tracker reset');
};
